function [rd] = rdprojm(x)
% RDPROJM  calc robust distances of rows in x by Rousseeuw's method
%         
%          [rd] = rdprojm(x)
%
%          x is a matrix and rd is a vector of robust distances.

if nargin ~= 1
  error('Wrong number of arguments.');
  end

[n p] = size(x);
if (n < 3) | (p < 3)
  error('Too small matrix.');
end

md = median(x);					% Medians of the Observation
cf = 1 + 15 / (n-1);				% Correction Factor
h = floor(n/2)+1;				% Half Position
v = x - md(ones(1,n),:);
y = (x * v')';					% Projection of all x on v
s_y = sort(y);					% Sorts y
half = s_y(h:n,:) - s_y(1:n-h+1,:);
[s ix] = min(s_y(h:n,:) - s_y(1:n-h+1,:));      % Calculates the Shortest Half
s = s * cf;					% Scatter
for i=1:n
  l(i) = (s_y(ix(i)+h-1,i) + s_y(ix(i),i)) / 2;	% Location
end
z = abs(y - l(ones(1,n),:)) ./ s(ones(1,n),:);	% Standardization
rd = max(z')';					% Robust Distances as Maximums
end
