function [resid, lev, student_r, cook_d]=mlr_diag(acal,ccal,atst,ctst,wv_idx,intcept)
% MLR_DIAG -- calc statistical diagnostics for MLR regression.
% 
%>inputs
% acal:      set of calibration spectra.
% ccal:      set of calibration concentrations.
% atst:      set of test spectra. (set to [] if none)
% ctst:      set of test concentrations. (set to [] if none)
% intcept:   calculates bo when intcept = 1 ,does not 
%            calculate bo when intcept = 0.
% wv_idx:    selected wavelength index.
%
%>outputs
% resid:     error between c and c_hat.  
% lev:       leverage of each of the concentration points.
% student_r: student residuals for the concentration points. 
% cook_d:    Cook's distance for the concentration points.
%
% See also: MLR MLR_CAL  STEP_MLR  MLR_DIAG  BOOT_MLR
%
% [resid, lev, student_r, cook_d]=mlr_diag(acal,ccal,atst,ctst,wv_idx,intcept);

% augment acal w/ col of ones.
if nargin ~= 6,
	error('MLR_DIAG - not enough input parameters');
end;

if isempty(atst),   % test for empty test set
    no_test = 1;
    atst = acal(1,:);   % give dummy test set if none
    ctst = ccal(1,:);
else
    no_test = 0;
end;

k = length(wv_idx);
[sccal,sccal2]=size(ccal);
[sctst,sctst2]=size(ctst);
if intcept==1,
    x = [ones(sccal,1) acal(:,wv_idx)];
    x2 = [ones(sctst,1) atst(:,wv_idx)];
else
    x = [acal(:,wv_idx)];
    x2 = [atst(:,wv_idx)];
end

for i=1:sccal2,
	
	% rename vars for convenient presentation
	y = ccal(:,i);
	y2 = ctst(:,i);
	n = length(y);    
    
	b_hat(:,i) = x \ y;
	y_hat = x * b_hat(:,i);
	y2_hat = x2 * b_hat(:,i);
	
	y_mean = mean(y);
	
	nparam = length(b_hat);
	df = n - nparam;
	
	% Calculate the concentration residuals for component i:
	y_err = y_hat - y;
	y2_err = y2_hat - y2;
	
	% Calculate the standard error of calibration and prediction.
	
	fprintf(1,'\nCalculations for Component (%g)',(i))
	fprintf(1,'\n')
	sec(:,i) = sqrt(sum(y_err.^2)/df);
	fprintf(1,'     Standard Error of Calibration  %g\n',sec(:,i));
	
	% Calculate the standard error of prediction.
	if no_test,
        sep(:,i) = nan;
	else
		sep(:,i) = sqrt(sum(y2_err.^2)/sctst);
		fprintf(1,'     Standard Error of Prediction  %g\n',sep(:,i));
	end;

	% Plot calibration points    
    if no_test,
        figure(1); plot(y,y_hat,'xb');
	else
        figure(1); plot(y,y_hat,'xb'); hold on; plot(y2,y2_hat,'og'); hold off;
	end
    title('Plot of predicted value vs. actual value, component 1.  X=cal O=test.');
	ylabel('predicted value'); xlabel('actual value');
	
	% Plot residuals
    if no_test,
        figure(2); plot(y_hat,y_hat-y,'xb');
	else
        figure(2); plot(y_hat,y_hat-y,'xb'); hold on; plot(y2_hat,y2_hat-y2,'og'); hold off;
	end
    title('Plot of residual vs predicted value.  X=cal O=test.');
	xlabel('predicted value'); ylabel('residual value');
	
	
	% Calculate regression diagnostics 
	
	ss_tot = sum((y - y_mean).^2);
	ss_regr = sum((y_hat - y_mean).^2);
	ss_resid = sum((y_hat - y).^2);
	
	if intcept == 1,
		msq_tot = ss_tot/(n-1);  % intercept is included
		msq_regr = ss_regr/(k);
		msq_resid = ss_resid/(n-k-1);
	else
		msq_tot = ss_tot/(n);		% no intercept!
		msq_regr = ss_regr/(k);
		msq_resid = ss_resid/(n-k);
	end;
	R_squared = (ss_tot - ss_resid) / ss_tot;
	R_sq_adj = (msq_tot - msq_resid) / msq_tot;
	
	F_ratio = msq_regr / msq_resid;
	s_y = sqrt(msq_resid);
	
	se_b = s_y * sqrt(diag(inv(x'*x)));
	t = b_hat(:,i) ./ se_b;
	
	if intcept == 1, 
		idxv = 0:k; 
	else 
		idxv = 1:k; 
	end;

	fprintf(1,'\n')
	fprintf(1,'___________________________________________________________\n')
	fprintf(1,'  Source of           Sum  of        Degrees          Mean\n')
	fprintf(1,'  Variation           Squares      of  Freedom       Square\n')
	fprintf(1,'___________________________________________________________\n')
	fprintf(1,'Regression         %11.4f       %4.0f        %10.4f\n',ss_regr,k,msq_regr);
	fprintf(1,'Residual           %11.4f       %4.0f        %10.4f\n',ss_resid,df,msq_resid);
	fprintf(1,'Total              %11.4f\n',ss_tot);
	fprintf(1,'___________________________________________________________\n')
	fprintf(1,'\n');
	fprintf(1,'F-ratio = %g/%g = %g',msq_regr,msq_resid,F_ratio);
	fprintf(1,'\n\n');
	fprintf(1,'     Standard dev %g\n',s_y);
	fprintf(1,'        R squared %g\n',R_squared)
	fprintf(1,'  R squared (adj) %g\n',R_sq_adj)
	
	fprintf(1,'\n\n')
	fprintf(1,'___________________________________________________________\n')
	fprintf(1,'  Variable      Coefficient    s.e. of Coeff      t-ratio\n')
	fprintf(1,'___________________________________________________________\n') 
	fprintf(1,'    b(%g)      %11.4f     %11.4f      %10.4f\n',[idxv',b_hat(:,i),se_b,t]');
	fprintf(1,'___________________________________________________________\n')
	
	% Calculate leverages 
	resid(:,i) = y - y_hat;
	lev(:,i) = diag(x*inv(x'*x)*x');
	student_r(:,i) = (1/s_y) * resid(:,i) ./ sqrt(1 - lev(:,i));
	cook_d(:,i) = student_r(:,i).^2 .* ((lev(:,i) * s_y.^2) ./ ((1-lev(:,i)) * s_y.^2))/nparam;
	fprintf(1,'\n')
	fprintf(1,'___________________________________________________________________________\n')
	fprintf(1,'                                                       Student      Cook''s\n')
	fprintf(1,'spl     actual    predicted     resid.     leverage     resid.       dist.\n')
	fprintf(1,'___________________________________________________________________________\n')
	fprintf(1,'%4g %10.4f  %10.4f  %10.4f  %10.4f  %10.4f  %10.4f\n',[(1:n)' y y_hat resid(:,i) lev(:,i) student_r(:,i) cook_d(:,i)]');
	fprintf(1,'____________________________________________________________________________\n')
    
    if no_test,
        resid3(:,i)=[resid(:,i)];
        lev3(:,i)=[lev(:,i)];
        student_r3(:,i)=[student_r(:,i)];
        cook_d3(:,i)=[cook_d(:,i)];
	else

        % Calculate leverages for test set 
        s_y2 = sqrt((sum((y2-y2_hat).^2))/(sctst));
        resid2(:,i) = y2-y2_hat;
        lev2(:,i) = diag(x2*inv(x'*x)*x2');
        student_r2(:,i) = (1/s_y) * resid2(:,i) ./ sqrt(1 - lev2(:,i));
        cook_d2(:,i) =student_r2(:,i).^2 .* ((lev2(:,i) * s_y.^2) ./ ((1-lev2(:,i)) * s_y.^2))/nparam;
        fprintf(1,'\n')
        fprintf(1,'\nCalculations for test set of Component (%g)',(i))
        fprintf(1,'\n')
        fprintf(1,'___________________________________________________________________________\n')
        fprintf(1,'                                                       Student      Cook''s\n')
        fprintf(1,'spl     actual    predicted     resid.     leverage     resid.       dist.\n')
        fprintf(1,'___________________________________________________________________________\n')
        fprintf(1,'%4g %10.4f  %10.4f  %10.4f  %10.4f  %10.4f  %10.4f\n',[(1:sctst)' y2 y2_hat resid2(:,i) lev2(:,i) student_r2(:,i) cook_d2(:,i)]');
        fprintf(1,'____________________________________________________________________________\n')
        
        resid3(:,i)=[resid(:,i);resid2(:,i)];
        lev3(:,i)=[lev(:,i);lev2(:,i)];
        student_r3(:,i)=[student_r(:,i);student_r2(:,i)];
        cook_d3(:,i)=[cook_d(:,i);cook_d2(:,i)];
	end
end;

resid=resid3;
lev=lev3;
student_r=student_r3;
cook_d=cook_d3;
