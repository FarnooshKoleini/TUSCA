function [nm,dt,sz]=dirl(fn);
% dirl --- list contents of a directory, one per line.
%
% [nm,dt,sz]=dir('dir name');  ('dir_name') is optional

if nargin < 1,
    d=dir;
else
    d=dir(fn);
end;

nm=char(d.name);
dt=char(d.date);
sz=[d.bytes];
