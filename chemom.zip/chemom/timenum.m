function [n] = timenum(str);
%TIMENUM Serial date number.
%   N = TIMENUM(S) converts the string S into a time number 
%   (seconds elapsed since midnight).
%
%   Examples:
%       N = timenum('3:14:10.12 AM');
%       n = timenum('3:14:10.12 PM');
%       n = timenum('15:15:10.2');
%       n = timenum('3:14:10 PM');
%       n = timenum('3:14 PM');
%       n = timenum('3 PM');

% copyright, 2001.  Paul J. Gempeline, East Carolina University.

s = str;  % get user string in temp var

% parse digits between ':'
idx = findstr(s,':');

if isempty(idx),                % special case, just hours, no mins, secs.           
    hr = sscanf(s,'%g');
    n = hr * 3600;  
else
    idx = [0 idx length(s)+1];  % depending on length of string, parse hours, mins, seconds.
    for i = 1:length(idx)-1;
        num = sscanf(s(idx(i)+1:idx(i+1)-1),'%g');  % convert string segment to decimal number
        switch i
        case 1,
            hr = num; n = hr * 3600;        % hours
        case 2,
            n = n + num * 60;               % minutes
        case 3,
            n = n + num;                    % seconds, including fractional part
        end;
    end;
end;
   
if findstr(s,'PM') > 0 & hr < 12,                   % check for PM
    hr = hr + 12;
    n = n + 12 * 3600;
end;

