
%
% FDISTRIBUTION -- Scriipt roduces a family of curves for the F distribution 
% at m=3 and n=k with k=3 to 10.
% The distribution curves are plotted.
pr = [0.90 0.95 0.975 0.99 ];
x = zeros(4,20,24);
for k = 1:length(pr);
   for i = 1:20
      for j = [1:20 30 40 60 120]
         x(k,i,j)=f_crit(1-pr(k),i,j);
      end;
   end;
end;

