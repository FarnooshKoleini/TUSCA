function [wv,x,nm,time]=read_cdi(fname,n);
%READ_CDI -- Read multiple CDI data files
%
% [wv,x,name,time]=read_cdi(fname);
%           or
% [wv,x,name,time]=read_cdi; (interactive form)
%
% Function to read sequentially numbered files from CDI's text file 
% format.  Files must be named in sequential order with a root name of 
% up to 8 characters.
%
% Example: spec.001, spec.002,...
%
% fname: root file name (optional)
%
% See also READ_CD for reading single files
%
%  Copyright Paul J. Gemperline, 2000
%  gemperlinep@mail.ecu.edu

if nargin==0,
	[fname,pt]=uigetfile('*.*','Select FIRST CDI text file...');
end;
dot = findstr(fname,'.');		% find location of '.' in the file name.
rootnm = fname(1:dot-1); 		% get first part of the file name

% get the list of files
fnm = fullfile(pt,rootnm);
fnm = sprintf('%s.*',fnm);
d = dir(fnm);	% read the disk directory to find find just the files we want
fnm = char(d.name);  % convert the structure to an array of names.
[fnm,idx] = sortrows(fnm);   % sort the file names in alphabetical order
n = length(d);

if n < 1,
	error(sprintf('READ_CDI -- Error, file %s not found.',fname));
end;

% read the first file to determine length of spectra
fprintf(1,'Reading %s.\n',fnm(1,:));
fn = fullfile(pt,fnm(1,:));
[wv,x1,nm1,t1] =  read_cd(fn);
if t1 == -1,		% returns -1 for all vars if file is not found.
	error(sprintf('READ_CDI -- Error reading file %s.',d(1).name));
end;
npts = length(wv);	% determine the length of the spectra

% allocate storage for spectra, etc.
x = zeros(n,npts);  x(1,:) = x1;
nm = {nm1};
time = zeros(n,1);  time(1) = t1;

% read the remaining files
for i = 2:n
	fprintf(1,'Reading %s.\n',fnm(i,:));
	fn = fullfile(pt,fnm(i,:));
	[wv,x(i,:),nm{i},time(i)] =  read_cd(fn);
	if time(i) == -1,		% returns -1 for all vars if file is not found.
		error(sprintf('READ_CDI -- Error reading file %s.',fnm(i,:)));
	end;
end;
nm = char(nm);

% PRIVATE FUNCTION

function [wv,x,nm,time]=read_cd(fname);
%READ_CD -- Read CDI text file export format
% [wv,x,name,time]=read_cd(fname);
%
%  Copyright Paul J. Gemperline, 2000
%  gemperlinep@mail.ecu.edu

% open the file for read-only access 
[fid,err_msg]=fopen(fname,'r');

if fid < 0,		% return -1 for all vars if file is not found.
	wv = fid; x=fid; nm=fid; time=fid;
	error(sprintf('\n\nREAD_CDI -- could not open file %s',fname));   
end;



s = fgetl(fid); 	% read first line

if ~isempty(findstr(s,'Header'));  % is it a header?
	nm = fgetl(fid); 	% get file name
	s = fgetl(fid);		% skip a line
	d = fgetl(fid);		% get date stamp
	t = fgetl(fid);		% get time stamp
	nm = sprintf('%s  %s  %s',nm,d,t); % add the date stamp
	t1=str2num(t(:,1:2));			% get hours
	t2=str2num(t(:,4:5));			% get minutes
	t3=str2num(t(:,7:8));			% get seconds
	time = ((3600*t1) + (60*t2) + t3)/60;
	
	for i=1:11;  	% skip the rest of the header lines
		s = fgetl(fid);
	end;
else
	frewind(fid);
	nm = sprintf('%s  unk_date  unk_time',fname);
	time = nan;
end

[s,count] = fscanf(fid,'%g');		% read the remaining part of the file
wv = s(1:2:count)';					% get the wavenumbers
x = s(2:2:count)';					% get the intensity data
fclose(fid);
