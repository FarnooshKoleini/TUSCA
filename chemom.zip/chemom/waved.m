function [d,pr,idx] = waved(a_trn,a_test,opt);
% WAVED -- Calc max wavelength distance and probability.
% 
% [d,pr,idx] = waved(v,vt,opt);
%
% Function to calculate the maximum wavelength distance of samples, given v 
% where v is a matrix of column-wise variables.  The training set, v, is 
% used to estimate distances for the test set, vt. This function should only
% be used when v and vt are 2nd derivative spectra otherwise use waved.
%
% opt = 1 returns the maximum distances sorted from low to high.
%
% The samples' maximum wavelength distances are returned in d.  The 
% probability density (Student's t distribution) for the distance is
% given in pr.
 
% COPYRIGHT, 1994.  Un-authorized use prohibited.
% Paul J. Gemperline
% Department of Chemistry
% East Carolina University
% Greenville, NC 27858
% 919-757-6767

[r_test,c_test]=size(a_test);

[y_trn,mn_trn,sd_trn]=autoscal(a_trn);
[y_test]=scale(a_test,mn_trn,sd_trn);
[d]=max(abs(y_test'))';          % calculate distance of max. deviation

[rtrn,ctrn] = size(a_trn);

[f] = [rtrn - 1];

if opt == 1,                    % sort 'em
  [d,idx] = sort(d);
end; 

[t] = d * sqrt(rtrn/(rtrn + 1));

[pr1_ou]=t_dist(f,t);            % one-tailed prob. dist is a reject

[pr1_o] = 1 - [(1 - pr1_ou).* 2];  % two-tailed prob. dist is a reject 

[pr_o]=pr1_o.^c_test;           % probability sample is a reject
[pr]=1 - pr_o;                  % probability sample is not a reject



