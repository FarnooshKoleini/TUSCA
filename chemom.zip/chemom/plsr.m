% [c1h,c2h,SEC,SEP,b] = plsr(a1,c1,a2,c2,nuse,mean_corr,var_scale,nfac);
%
% PLS calibration.  Algorithm by Lorber, Wangen and Kowalski in
% J. Chemometrics 1, 19-31, 1987.
%
% 9/25/97 notes: validated this algorithm w/ meohwat.dat, 3 factors.
% This pgm produced same sec and sep values as Sijmen DeJong's simpls1.m
%
% The matrices a1 and a2 contain the calibration spectra and
% test spectra respectively in rows. PLS is performed for one 
% through up to 18 factors.  The matrices c1 and c2 contain the conc
% data.  The predicted concentrations are returned in c1p and c2p.
% The variables mean_cor and var_scale are 1/0 parameters used 
% to indicate preprocessing steps.  The user specifies the number of 
% factors to be used in the parameter, nuse.  For the final 
% model, the matrix b  contains the PCR regression coefficients 
% for the nuse model:cp=a*b.  

function [chat,ctesthat,SEC,SEP,b] = plsr(a,c,atest,ctest,nuse,mean_correct,variance_scale,nfac);
power=1;
if nargin == 7,
  nfac=18;
elseif nargin ~= 8,
  error ('PLS - Wrong number of parameters.');
end
%
% get df
%
[ar,ac]=size(a);
[art,act]=size(atest);
[cr,ncomp]=size(c);
%
% autoscale a, atest, c and ctest
%
if mean_correct == 0, 
  amean = zeros(1,ac); 
  cmean = zeros(1,ncomp);
else 
  amean = mean(a);
  cmean = mean(c);
end
cstd = ones(1,ncomp);
if variance_scale == 0,
  astd = ones(1,ac);
else
  astd = std(a);
end
cmn = mean(c);
a = scale(a,amean,astd);
if ~isempty(atest), atest = scale(atest,amean,astd); end;
cd = scale(c,cmean,cstd);
%if ~isempty(ctest), ctestd = scale(ctest,cmean,cstd); end;
%
% get max num factors
%
if mean_correct == 0,
  if ar < nfac,
    nfac = ar;
  end
  if ac < nfac,
    nfac = ac;
  end
else
  if ar-1 < nfac,
    nfac = ar-1;
  end
  if ac-1 < nfac,
    nfac = ac-1;
  end
end;
if nuse > nfac,
  nuse = nfac;
end;

%
% Calculate SEC, SEP for 18 components or r components which ever
% is less.
%
SEC=zeros(nfac,ncomp);
if ~isempty(ctest), SEP=zeros(nfac,ncomp); end;
Ii=eye(ar);
Ik = eye(art);
clear bsave;
for n = 1:ncomp
  ResidMatrix=a;
  clear p;
  clear t;
  clear b;
  for i = 1:nfac
    str=sprintf('Calculating PLS factor %g',i);
    disp(str);
    if ac > ar,
      [v,s,u] = svd(ResidMatrix',0);
    else
      [u,s,v] = svd(ResidMatrix,0);
    end;
    a_cor = u' * cd(:,n);
    p(:,i) = v * s.^power * a_cor;
    p(:,i) = p(:,i) / norm(p(:,i));
    t(:,i) = u * (s'.^(2*power)) * a_cor;
    t(:,i) = t(:,i) / norm(t(:,i));
    ResidMatrix = (Ii-(t(:,i)*t(:,i)')) * (ResidMatrix - (ResidMatrix *p(:,i))*p(:,i)');
    q = t' * a * p;
    [uq,sq,vq]=svd(q);
    [u,s,v]=trim(i,u,s,v);
    b(:,n) = p * vq * inv(sq) * (t * uq)' * cd(:,n);
    if i == nuse,
       bsave(:,n) = b(:,n);
    end;
    chat(:,n) = a * b(:,n);
    chat(:,n) = unscale(chat(:,n), cmean(n), cstd(n));
    if mean_correct == 1,
      df = ar - i - 1;
    else
      df = ar - i;
    end;
    if df == 0,
      SEC(i,n)=nan;
    else
      SEC(i,n) = sqrt(sum((c(:,n) - chat(:,n)).^2) / df);
    end;
    if ~isempty(ctest),
        ctesthat(:,n) = atest * b(:,n);
        ctesthat(:,n) = unscale(ctesthat(:,n), cmean(n), cstd(n));
        SEP(i,n)=sqrt(sum((ctest(:,n) - ctesthat(:,n)).^2) / art);
    end;
  end;
%
% Dump relative error
%
  l=ones(nfac,1);
  str=sprintf('No. factors   SEC for component %g',n);
  disp(str);
  disp([(1:nfac)' SEC(:,n)]);
  if ~isempty(ctest), 
    str=sprintf('No. factors   SEP for component %g',n);
    disp(str);
    disp([(1:nfac)' SEP(:,n)]);
  end;
  clear l;
%
%
% Trim model using number of parameters set by caller
%
  b=bsave;
  [t,q,p]=trim(nuse,t,q,p);
  ResidMatrix = (Ii-(t*t'))*(a-(a*p)*p');
  chat(:,n) = a * b(:,n);
  chat(:,n) = unscale(chat(:,n), cmean(n), cstd(n));
  if ~isempty(ctest),
      tt = atest * p;
      for i=1:nuse,
          tt(:,i) = tt(:,i) / norm(tt(:,i));
      end;
      TestResidMatrix = (Ik-(tt*tt'))*(atest-(atest*p)*p');
      ctesthat(:,n) = atest * b(:,n);
      ctesthat(:,n) = unscale(ctesthat(:,n), cmean(n), cstd(n));
  end
end;

for i=1:ncomp
%
% Plot the results for each component.
%
  disp('Paused, hit <return> for plot.');
  pause
  semilogy(100*SEC(:,i)/cmn(i));
  hold on;
  semilogy(100*SEC(:,i)/cmn(i),'x');
  if ~isempty(ctest)
    semilogy(100*SEP(:,i)/cmn(i),'g');
    semilogy(100*SEP(:,i)/cmn(i),'og');
  end;
  hold off;
  if ~isempty(ctest)
    title(sprintf('Plot of SEC (x) and SEP (o) for component %g',i));
  else
    title(sprintf('Plot of SEC for component %g',i));
  end
  xlabel('Number of factors');
  ylabel('%Error')
%
% Plot the regression coefficients
%
    pause
    plot(b(:,i));
    title(sprintf('Plot of regression coefficients for component %g',i));
    ylabel('Magnitude');
    xlabel('Wavelength vars.');
end; 
%
%  Plot calibration curves
%
for i = 1:ncomp
    pause
    if ~isempty(ctest)
       plot(c(:,i),chat(:,i),'x',ctest(:,i),ctesthat(:,i),'o');
       caption(c(:,i),chat(:,i),'  ');
       caption(ctest(:,i),ctesthat(:,i),'  ');
       title(sprintf('Results for component %g.  (x) calibr. (o) test.',i));
    else
       plot(c(:,i),chat(:,i),'x');
       caption(c(:,i),chat(:,i),'-');
       title(sprintf('Results for component %g.  (x) calibration',i));
    end;
    ylabel('Estimated concentration');
    xlabel('Actual concentration');
end
for i=1:ncomp
%
%  Plot component residuals
%
    pause
    if ~isempty(ctest)
       plot(chat(:,i),c(:,i)-chat(:,i),'x',ctesthat(:,i),ctest(:,i)-ctesthat(:,i),'o');
       caption(chat(:,i),c(:,i)-chat(:,i),'  ');
       caption(ctesthat(:,i),ctest(:,i)-ctesthat(:,i),'  ');
       t=sprintf('Plot of residuals for component %g.  (x) calibr. (o) test.',i);
    else
       plot(chat(:,i),c(:,i)-chat(:,i),'x');
       caption(chat(:,i),c(:,i)-chat(:,i),'-');
       t=sprintf('Plot of residuals for component %g.  (x) calibration',i);
    end
    title(t);
    xlabel(sprintf('Predicted concentration of component %g',i));
    ylabel(sprintf('Residuals for component %g',i));
end

