function [a,spl_name]=read_fda(fn);
% READ_FDA -- read NIR NSAS data files.
%
%  [a,spl_name]=read_fda('filename');
%        or
%  [a,spl_name]=read_da;
%
%  read_fda is  matlab fucntion for reading NSAS data files.
%  Modified 03/18/93 for full VIS/NIR range.
%  Works for spectra transferred from pc to rs/6000 via binary ftp.
%
%  See read_da for NIR range.

%  Copyright Paul J. Gemperline, 2000
%  gemperlinep@mail.ecu.edu

if nargin==0,
   [fn,pt]=uigetfile('*.da','Select NSAS *.da file');
   fn = fullfile(pt,fn);
end

inp=fopen(fn,'r','ieee-le');

nspec=0;
k=fread(inp,128,'char');
fseek(inp,4352,-1);
%
% loop for reading sample names
%
while ~feof(inp)
  nspec=nspec+1;
  da=k(65)+k(66)*256;
  mo=k(67)+k(68)*256;
  yr=k(69)+k(70)*256;
  hr=k(71)+k(72)*256;
  mi=k(73)+k(74)*256;
  se=k(75)+k(76)*256;
  spl_name(nspec,1:30)=[setstr(k(5:14))' sprintf(' %2g:%2g:%2g %2g-%2g-%4g',hr,mi,se,mo,da,yr)];
  k=fread(inp,128,'char');
  fseek(inp,(nspec+1)*4352,-1);
end;

frewind(inp);
a=zeros(nspec,1050);
for i=1:nspec
  k=fread(inp,4352./4,'float');
  a(i,:)=k(33:1082)';
end;
fclose(inp);
