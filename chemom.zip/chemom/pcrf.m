function [chat,ctesthat,SEC,SEP,b] = pcrf(a,c,atest,ctest,nuse,mean_correct,variance_scale);
% PCRF - pcr calibr. w/ train & opt. test data, non-interactive vers.
%
% [c1p,c2p,SEC,SEP,b]=pcrf(a1,c1,a2,c2,nuse,mean_cor,var_scale);
%
% The matrices a1 and a2 contain the calibration spectra and
% test spectra respectively in rows. PCR is performed for one 
% through up to 18 factors.  The matrices c1 and c2 contain the conc
% data.  The predicted concentrations are returned in c1p and c2p.
%
% If c2 is not known, just use c2=[] and SEP will be null...
%
% The variables mean_cor and var_scale are 1/0 parameters used 
% to indicate preprocessing steps.  The user specifies the number of 
% factors to be used in the parameter, nuse.  For the final 
% model, the matrix b  contains the PCR regression coefficients 
% for the nuse model:cp=a*b.  
%
if nargin ~= 7,
	error ('PCR - Wrong number of parameters.');
end
echo on
%
% get df
%
[ar,ac]=size(a);
[art,act]=size(atest);
[cr,ncomp]=size(c);
%
% autoscale a, atest, c and ctest
%
if mean_correct == 0, 
	amean = zeros(1,ac); 
	cmean = zeros(1,ncomp);
else 
	amean = mean(a);
	cmean = mean(c);
end
cstd = ones(1,ncomp);
if variance_scale == 0,
	astd = ones(1,ac);
else
	astd = std(a);
end
cmn = mean(c);
a = scale(a,amean,astd);
cd = scale(c,cmean,cstd);
if ~isempty(ctest), 
	atest = scale(atest,amean,astd);
	ctestd = scale(ctest,cmean,cstd); 
end;
%
% calculate principal components and RE
%
[v,s,u]=svd(a',0); % conserve memory when very long spectra are used

%
% get max num factors
%
nfac = 18;
if mean_correct == 0,
	if ar < nfac,
		nfac = ar;
	end
	if ac < nfac,
		nfac = ac;
	end
else
	if ar-1 < nfac-1,
		nfac = ar-1;
	end
	if ac-1 < nfac,
		nfac = ac-1;
	end
end;
if nuse > nfac,
	nuse = nfac;
end;
%
% Calculate SEC, SEP for 18 components or r components which ever
% is less.
%
[u,s,v]=trim(nfac,u,s,v);
SEC=zeros(nfac,ncomp);
if ~isempty(ctest), SEP=zeros(nfac,ncomp); end;
	for i = nfac:-1:1
		[ud,sd,vd] = trim(i,u,s,v);
		b = (vd/sd) * ud' * cd;
		chat = a * b;
		chat = unscale(chat, cmean, cstd);
		if mean_correct == 1,
			df = ar - i - 1;
		else
			df = ar - i;
		end;
		if df == 0,
			SEC(i,:)=[];
		else
			SEC(i,:) = sqrt(sum((c - chat).^2) / df);
		end
		if ~isempty(ctest), 
			ctesthat = atest * b;
			ctesthat = unscale(ctesthat, cmean, cstd);
			SEP(i,:)=sqrt(sum((ctest - ctesthat).^2) / art);
		end;
	end;

	t=ones(nfac,1);
	[nr,nc]=size(SEC);
	%
	% Recalc model using number of parameters set by caller
	%
	[u,s,v] = trim(nuse,u,s,v);
	b = (v/s) * u' * cd;
	chat = a * b;
	chat = unscale(chat, cmean, cstd);
	if ~isempty(ctest), 
		ctesthat = atest * b;
		ctesthat = unscale(ctesthat, cmean, cstd);
	end

	if mean_correct == 1,
		df1 = nuse + 1;
		df2 = ar - nuse - 1;
	else
		df1 = nuse;
		df2 = ar - nuse;
	end;
	
