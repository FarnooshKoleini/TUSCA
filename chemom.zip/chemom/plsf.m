function [chat,ctesthat,SEC,SEP,b] = plsf(a,c,atest,ctest,nuse,mean_correct,variance_scale,nfac);
% PLSF -- non-interactive vers. of PLSR.
%
% PLS calibration.  Algorithm by Lorber, Wangen and Kowalski in
% J. Chemometrics 1, 19-31, 1987.
%
% The matrices a and atest contain the calibration spectra and
% test spectra respectively in rows. PLS is performed for one 
% through ten factors.  The variables, 
% mean_corr and  var_scale are 1/0 parameters used to 
% indicate preprocessing steps.  The variable nfac limits the max no.
% factors to calculate. If omited the default value is 18.
%
%        SEC, SEP are calculated for each
% of the nfac models.  The user specifies the number of 
% factors to be used in the parameter, nuse.  For the final 
% model, the matrix b  contains the PLS regression coefficients 
% for the nuse model:chat=a*b. 
%
% [c1h,c2h,SEC,SEP,b] = plsf(a1,c1,a2,c2,nuse,mean_corr,var_scale,nfac);

power=1;
if nargin == 7,
  nfac=18;
elseif nargin ~= 8,
  error ('PLS - Wrong number of parameters.');
end
echo on
%
% get df
%
[ar,ac]=size(a);
[art,act]=size(atest);
[cr,ncomp]=size(c);
%
% autoscale a, atest, c and ctest
%
if mean_correct == 0, 
  amean = zeros(1,ac); 
  cmean = zeros(1,ncomp);
else 
  amean = mean(a);
  cmean = mean(c);
end
cstd = ones(1,ncomp);
if variance_scale == 0,
  astd = ones(1,ac);
else
  astd = std(a);
end
cmn = mean(c);
a = scale(a,amean,astd);
atest = scale(atest,amean,astd);
cd = scale(c,cmean,cstd);
if ~isempty(ctest),
   ctestd = scale(ctest,cmean,cstd);
end;
%
% get max num factors
%
if ar < nfac+2,
  nfac = ar - 2;
end
if ac < nfac
  nfac = ac;
end;
if nuse > nfac
  nuse = nfac;
end;
%
% Calculate SEC, SEP for 10 components or r components which ever
% is less.
%
SEC=zeros(nfac,ncomp);
SEP=zeros(nfac,ncomp);
Ii=eye(ar);
Ik = eye(art);
clear bsave;
for n = 1:ncomp
  ResidMatrix=a;
  clear p;
  clear t;
  clear b;
  for i = 1:nfac
    if ac > ar,
      [v,s,u] = svd(ResidMatrix',0);
    else
      [u,s,v] = svd(ResidMatrix,0);
    end;
    a_cor = u' * c(:,n);
    p(:,i) = v * s.^power * a_cor;
    p(:,i) = p(:,i) / norm(p(:,i));
    t(:,i) = u * (s'.^(2*power)) * a_cor;
    t(:,i) = t(:,i) / norm(t(:,i));
    ResidMatrix = (Ii-(t(:,i)*t(:,i)')) * (ResidMatrix - (ResidMatrix *p(:,i))*p(:,i)');
    q = t' * a * p;
    [uq,sq,vq]=svd(q);
    [u,s,v]=trim(i,u,s,v);
    b(:,n) = p * vq * inv(sq) * (t * uq)' * c(:,n);
    if i == nuse,
       bsave(:,n) = b(:,n);
    end;
    chat(:,n) = a * b(:,n);
    ctesthat(:,n) = atest * b(:,n);
    chat(:,n) = unscale(chat(:,n), cmean(n), cstd(n));
    if mean_correct == 1,
      df = ar - i - 1;
    else
      df = ar - i;
    end;
    SEC(i,n) = sqrt(sum((c(:,n) - chat(:,n)).^2) / df);
    ctesthat(:,n) = unscale(ctesthat(:,n), cmean(n), cstd(n));
    if ~isempty(ctest),
       SEP(i,n)=sqrt(sum((ctest(:,n) - ctesthat(:,n)).^2) / art);
    end
 end;

%
% Trim model using number of parameters set by caller
%
  b=bsave;
  [t,q,p]=trim(nuse,t,q,p);
  ResidMatrix = (Ii-(t*t'))*(a-(a*p)*p');
  tt = atest * p;
  for i=1:nuse,
    tt(:,i) = tt(:,i) / norm(tt(:,i));
  end;
  TestResidMatrix = (Ik-(tt*tt'))*(atest-(atest*p)*p');
  chat(:,n) = a * b(:,n);
  chat(:,n) = unscale(chat(:,n), cmean(n), cstd(n));
  ctesthat(:,n) = atest * b(:,n);
  ctesthat(:,n) = unscale(ctesthat(:,n), cmean(n), cstd(n));
end;
