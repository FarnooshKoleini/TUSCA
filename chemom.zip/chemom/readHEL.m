function [t,sp,flowrate]=read_HEL(hfn,lfn);
% readsHEL -- read HEL data files.
%
%  [t,sp,flowrate]=readHEL('HEL filename.dat','log filename.txt');
%        or
%  [t,sp,flowrate]=readHEL;
%
%  log file name is needed to sync Intelliform data with HEL data. Skip otherwise.
%
%  x is a structured variable w/ stepwise data
%  d is the whole data array
%  stp_idx is the location of new steps
%  y is structured variable w/ intelliform data

%  Copyright Paul J. Gemperline, 2001
%  gemperlinep@mail.ecu.edu

true = 1;
false = 0;
x.nsteps = 0;
read_step = false;
read_data = false;

%
% open HEL file for reading
%
if nargin == 0,
   [hfn,pt] = uigetfile('*.dat','Select HEL *.dat file');
   if hfn == 0,
       return;
   end;
   hfn = fullfile(pt,hfn);
end
inp=fopen(hfn,'rt');  % open for read-only access, text mode

%
% open Log file for reading (skip)
%
skip_log = true;
x.file_time = 0;
x.start_time = 0;

%
% read header and get file description
%
for i=1:11  % read header
    l(i) = {fgetl(inp)};
end;
%
% parse date and time
%
s=char(l(4));
idx1=findstr(s,'Date : ')+7;
idx2=findstr(s,'.')-1;
x.file_date = datenum(s(idx1:idx2));

idx = findstr(s,'Time : ')+7;
s=s(idx:end);
x.stop_time = timenum(s);
x.file_descr = [char(l(2)) '   Time : ',x.file_time,' to ' s];

%
% read one line at a time, watch for step start/stop
%
while ~feof(inp),
    l = fgetl(inp);
    %
    % start reading next step
    %
    if ~isempty(findstr(l,'Step Name')) | ~isempty(findstr(l,'Time (mins)|')),
       read_step = true;
       x.nsteps = x.nsteps + 1;
       st = x.nsteps;
       x.step(st).name = l(16:end);
%
% if there are not multiple steps, then process header line early
%
       if ~isempty(findstr(l,'Time (mins)|')),
          x.step(st).name = 'None';
          read_data = true;
          row = 0;
          idx=[0 findstr(l,'|') length(l)];
          x.ncols = length(idx)-2;
          for j = 1:x.ncols;
             x.col_label(j) = {l(idx(j)+1:idx(j+1)-1)};
          end;
       end;
       
    end;
    %
    % start reading data block of next step
    %
    while read_step == true,
        while read_data == false,
            l = fgetl(inp);
            if ~isempty(findstr(l,'Time (mins)|')),
                read_data = true;
                row = 0;
                idx=[0 findstr(l,'|') length(l)];
                x.ncols = length(idx)-2;
                for j = 1:x.ncols;
                    x.col_label(j) = {l(idx(j)+1:idx(j+1)-1)};
                end;
            end;
        end;
        %
        % read data rows
        %
        while read_data == true
           
            y = fscanf(inp,'%g',x.ncols);
            if ~isempty(y),
                row = row + 1;
                x.step(st).dat(row,:) = y;
            else
                read_data = false;
                read_step = false;
            end;
        end;
    end;
end;
fclose(inp);

d = [];
stp_idx(1) = 1;
for i = 1:x.nsteps
    d = [d; x.step(i).dat];
    [r,c] = size(d);
    stp_idx(i+1) = r+1;
end;

% adjust inteliform time and HEL time
[fn,pt] = uigetfile('*.mat','Select spectral file *.mat file');
if fn == 0,
   y=[];
   return;
end;
fn = fullfile(pt,fn);
y = load(fn);  % read the file

%
% test to make sure the intelliform export was specified.
%
if ~isfield(y,'t')
    warning('readHEL -- %s does not contain varaible "t".',fn)
    return
end;
if ~isfield(y,'sp')
    warning('readHEL -- %s does not contain variable "sp".',fn)
    return
end;

%
% interactive section to match up zero times
%

done_flag = 0;

while done_flag == 0,
    
    w = hel_mark(y.t,y.sp);        % make figure for selecting spectra t0
    if ~isstruct(w), return; end;  % check if user cancelled
    t_sp = w.t-w.t0;
    
    z = hel_mark(d(:,1),d(:,3:end));    % make figure for selecting HEL t0
    if ~isstruct(z), return; end;           % check if user cancelled
    t_hel = z.t-z.t0;
    
    %make overlay plots
    h2 = figure;
    plot(t_sp,y.sp);
    ax=axis;
    flow = z.d(:,7);
    minf = min(flow);
    maxf = max(flow);
    mins = min(min(y.sp));
    maxs = max(max(y.sp));
    hold on;
    plot(t_hel,(flow-minf+mins)*(maxs-mins)/(maxf-minf),'linew',1.5);
    axis(ax);
    hold off;
    ht1 = uicontrol('Style', 'pushbutton', 'String', 'Try again',...
        'Units','Normalized','Position', [.14 .93 .1 .05], 'Callback', 'set(gcf,''userdata'',0);uiresume(gcf)');
    ht2 = uicontrol('Style', 'pushbutton', 'String', 'Done',...
        'Units','Normalized','Position', [.25 .93 .15 .05], 'Callback', 'set(gcf,''userdata'',1);uiresume(gcf)');
    uiwait(h2);
    done_flag = get(h2,'userdata');
    close(h2);
end;

[tflow,dflow] = dy_dt(t_hel,d(:,9));  % calc flowrate from total flow
flowrate = interp1(tflow,dflow,t_sp); % interpolate flowrate to match spectral acquisition times


plot(t_sp,flowrate);
hold on;
plot(t_hel,d(:,9),'r')
plot(t_sp,cumtrapz(t_sp,flowrate),'b:');
hold off;
legend('computed flow rate','measured total flow','integral of comp. total flow',2)

t = t_sp;
sp = y.sp;

%--------------------------------------------------------------------------

function z = hel_mark(t,d);
ht = figure('numbertitle','off','name','Reaction temperature data',...
    'tag','kinfit','renderer','painter');
%set(ht,'CloseRequestFcn','kin_closereq');

plot(t,d);                % plot reactor temperature vs time
axis('tight');
z.t=t; z.d=d;
set(ht,'userdata',z);   % save data in user area of figure

ht1 = uicontrol('Style', 'pushbutton', 'String', 'Cancel',...
    'Units','Normalized','Position', [.14 .93 .1 .05], 'Callback', 'set(gcf,''userdata'',nan);uiresume(gcf)');
ht2 = uicontrol('Style', 'pushbutton', 'String', 'Mark time = 0',...
    'Units','Normalized','Position', [.25 .93 .15 .05], 'Callback', 'markHEL');
ht3 = uicontrol('Style', 'pushbutton', 'String', 'Done',...
    'Units','Normalized','Position', [.41 .93 .1 .05], 'Callback', 'uiresume(gcf)');
ht4 = uicontrol('Style', 'text', 'String', 'Zoom feature is enabled',...
    'Units','Normalized','Position', [.53 .93 .3 .05], 'Callback', '');

zoom(ht,'reset'); % remember current zoom state
zoom(ht,'on');

uiwait(ht);
z = get(ht,'userdata');
close(ht);

