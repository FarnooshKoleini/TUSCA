%
% FDISTRIBUTION -- Scriipt roduces a family of curves for the F distribution 
% at m=3 and n=k with k=3 to 10.
% The distribution curves are plotted.
clear x;
clear y;
x=0.005:0.005:5;
x=x';
for k=5:10;
m=k;
n=5;
y(:,k)=(gamma((m+n)/2).*(m/n)^m/2.*x.^(m/2-1))./(gamma(m/2).*gamma(n/2).*(1+m/n*x).^(m+n/2));
end;
plot(x,y);
