function [out,xaxis]=spcload(filename,subs,wlrange);
% SPCLOAD -- BROKEN? loads an SPC single file, multi-file, or some portion thereof
%
% [wv,x]=spcload;
%           or
% [x,wv]=spcload(fname);
% [x,wv]=spcload(fname,subs);
% [x,wv]=spcload(fname,subs,wv_idx);
%
%  Without subs, all subfiles are read; 
%  With subs, only those specified are read.  Examples: [1 3 6 8], 1:5, etc.
%  If subs=0 then number of subfiles and points per spectrum are reported
%  wv_idx is index of wavenumber range to be read in.  Examples: 1:1024, 1:4:1023, etc.
% 
% See also LOADSPC, READ_SP, READ_SPC READ_FP, READ_FSP 

if nargin==0,
   [fn,pt]=uigetfile('*.spc','Select GRAMS/32 *.spc file');
   filename = fullfile(pt,fn);
end

if isempty(findstr(filename,'.spc')) & isempty(findstr(filename,'.SPC')),
   filename = strcat(filename,'.spc');
end;

% open the file in binary format, read-only, little-endian IEEE machine format 
[f,MESSAGE]=fopen(filename,'r','n');

if f==-1;
   disp([MESSAGE]);
   disp(['Current folder: ' pwd]);
   error(['File does not exist or some other similar error (check directory)']);
end;

ftflgs=fread(f,1,'char');    %   BYTE   ftflgs; /* Flag bits defined below */
fversn=fread(f,1,'char');    %   BYTE   fversn; /* 4Bh=> new LSB 1st, 4Ch=> new MSB 1st, 4Dh=> old format */

if fversn~=75;
   fclose(f);
   error(['Wrong/Old File Type (' num2str(fversn) ')! Read file into Grams and save as a new file']);
end;

fexper=fread(f,1,'uint8');    %   BYTE   fexper; /* Reserved for internal use (experiment-1) */
fexp=  fread(f,1,'schar');    %   char   fexp;   /* Fraction scaling exponent integer (80h=>float) */
fnpts= fread(f,1,'uint16');   %   DWORD  fnpts;  /* Integer number of points (or TXYXYS directory position) */
fread(f,1,'uint16');
ffirst=fread(f,1,'float64');   %   double ffirst; /* Floating X coordinate of first point */
flast= fread(f,1,'float64');   %   double flast;  /* Floating X coordinate of last point */
fnsub= fread(f,1,'uint16');    %   DWORD  fnsub;  /* Integer number of subfiles (1 if not TMULTI) */
% 1 1 1 1 2 2 8 8 2 = 26 bytes read to this point

fread(f,(512-26),'char');  % Read to end of header

fstep=((flast-ffirst)/(fnpts-1));
xaxis=ffirst:fstep:flast;

if nargin<3;
   wlrange=1:fnpts;
end;

if nargin<2; 
   subs=1:fnsub;
else
   if isinf(subs); 
      subs=1:fnsub;
   end;
   if max(subs)>fnsub; 
      error(['Not that many subfiles']); 
   end;
end;

if subs==0; 
   %Tell user how many are in the file
   disp(['subfiles: ' num2str(fnsub) '  points: ' num2str(fnpts)]);
   out=[]; xaxis=[];
   return; 
end

totalsubs=length(subs); index=0; oldpercent=0;
totalwls=length(wlrange);

out=zeros(totalwls,totalsubs);   %set up output array (i.e. check memory)

for j=1:(max(subs));
   subhead=fread(f,32,'schar');            % Read sub-header (32 bytes)
   
   if subhead(2)~=-128; 
      currentframe=fread(f,fnpts,'int32');   %Read current subfile (IBM SPC format)
   else
      currentframe=fread(f,fnpts,'float32');   %Read current subfile (float format)
   end   
   if subhead(2)==-128; 
      subhead(2)=32; 
   end    		%no adjustments for floating format
   if any(j==subs);                           %user wants this one?
      index=index+1;
      out(:,index)=currentframe(wlrange,:)*(2^subhead(2))/(2^32);  %then store it
      %after adjusting for scaling denoted by subhead(2)
   end;
   %   if fix(j/max(subs)*100)>oldpercent;
   %       disp([   'searched: ' num2str(fix(j/max(subs)*100)) '%' ...
   %             '  retrieved: ' num2str(fix(index/totalsubs*100)) '%']);
   %       oldpercent=fix(j/max(subs)*100);
   %   end;
end;
xaxis = xaxis(wlrange);
fclose(f);

