function [idx,ss_min] = step_mlr(x,y,pr_ent,pr_del);
% STEP_MLR -- step-wise variable selection for MLR
%
% x: predictors (n x m)
% y: predicted variable (n x 1)
%
% For convergence, pr_del > pr_ent
%
% pr_del: prob. level for variable deletion steps (0.05 = default)
% pr_ent: prob. level for variable addition steps (0.01 = default)
%
% To select more vars try .05,.10
%
% See also: MLR MLR_CAL  STEP_MLR  MLR_DIAG  BOOT_MLR
%
% [idx,ss_min] = step_mlr(x,y,pr_ent,pr_del);

% -- error checking --

if nargin < 4,
	pr_del = 0.05;
end;
if nargin < 3,
	pr_ent = 0.01;
end;
if nargin < 2,
	error('STEP_MLR: At least 2 input variables are requied.')
end

[nx,mx]=size(x);
[ny,my]=size(y);

if nx ~= ny,
	error('STEP_MLR: x and y must have same number of rows.');
end;
if my ~= 1,
	error('STEP_MLR: y must have one column.');
end;
if mx < 2,
	error('STEP_MLR: x must have at least two columns.');
end;

%-- initialization --

idx = [];
add = 0;
del = 0;
ssr = zeros(my,1);
ss_min = ssr;
xm = meancorr(x); ym = meancorr(y);  % mean correct for non-zero intercept
fprintf('\n   SSR          variables');

%-- find ssr about mean --

step = 1;
ssr(step) = sum(ym.^2);	% get ssr about the mean.
fprintf('\n%10g      ',ssr(step)); fprintf('Ini  '); fprintf('%g ',idx);

%-- find first var --

[ix_tmp,ssr(step+1)] = find_first(xm,ym); % get first var & ssr
if pr_ent > f_val(ssr(step)-ssr(step+1),ssr(step+1),1,ny-step-1),	% keep it ?
	ss_min = ssr(step+1);		% yes
	step = step + 1;
	idx = ix_tmp;
	add = 1;
	fprintf('\n%10g      ',ssr(step)); fprintf('Add  '); fprintf('%g ',idx);
% 	fprintf('\nb = %g %g %g %g %g %g %g %g\n',xm(:,idx) \ ym);
else
	add = 0;					% no
	return;
end;

%-- main loop --

while (add | del),	% loop as long as vars added or deleted in last step
	
	% -- try to add another var --
	
	[ix_tmp,ssr(step+1)] = add_best(xm,ym,idx); % get next var & ssr
	if pr_ent > f_val(ssr(step)-ssr(step+1),ssr(step+1),1,ny-step-1),	% keep it ?
		ss_min = ssr(step+1);	% yes
		step = step + 1;
		idx = ix_tmp;
		add = 1;
      fprintf('\n%10g      ',ssr(step)); fprintf('Add  '); fprintf('%g ',idx);
%       fprintf('\nb = %g %g %g %g %g %g %g %g',xm(:,idx) \ ym);
	else
		add = 0;				% no
	end;
    if length(idx) > ny - 3, add = 0; end;

	% -- try to replace one var --
	[ix_tmp,ssr_del] = delete_worst(xm,ym,idx); % delete worst var
	if ssr_del < ssr(step-1),   % replace it?
		ss_min = ssr_del;		% yes
		step = step - 1;		% yes
		ssr(step) = ssr_del;
		idx = ix_tmp;
		add = 1;				% make sure we try another addition
		fprintf('\n%10g      ',ssr(step)); fprintf('Del  '); fprintf('%g ',idx);
%       fprintf('\nb = %g %g %g %g %g %g %g %g',xm(:,idx) \ ym);
	else

		% -- try to delete one var --
		if pr_del < f_val(ssr_del,ssr(step),1,ny-step-1), % delete it?
			ss_min = ssr_del;		% yes
			step = step - 1;		% yes
			idx = ix_tmp;
			del = 1;
			fprintf('\n%10g      ',ssr(step)); fprintf('Del2 '); fprintf('%g ',idx);
% 			fprintf('\nb = %g %g %g %g %g %g %g %g',xm(:,idx) \ ym);
		else
			del = 0;
		end;
	end
end
fprintf('\n');

%--------------------------------------------------------------------------
function [pr] = f_val(ssr1,ssr2,n,p);
%F = (ssr1 - ssr2) * (n-p-2) / ssr2;
F = (ssr1 * p) / (ssr2 * n);
pr = 1-f_dist(n,p,sqrt(F));
% print some debugging info
% fprintf('\n (pr=%g) F= %g = (%g*%g)/(%g*%g)\n',pr,F,ssr1,p,ssr2,n);

%--------------------------------------------------------------------------
function [idx,rmin]=find_first(xm,ym);
% FIND_FIRST - finds the best variable in a for L-S cabliration of c.
%
% USE:
%[idx,rmin]=find_first(xm,ym);
[n,m]=size(xm);
r = zeros(m,1);	% allocate storage for residuals
for i = 1:m		
	b = xm(:,i) \ ym;		% calc regr coef for each col in a
	y_hat = xm(:,i) * b;	% prediction
	r(i) = sum((ym - y_hat).^2); % calc sum squared error
end
[rmin,idx] = min(r);

%--------------------------------------------------------------------------
function [idx,rmin] = add_best(xm,ym,idx_sel);
% ADD_BEST - finds the next best variable in a for L-S cabliration of c.
%
% USE:
%[idx,rmin]=add_best(xm,ym,idx);

[n,m]=size(xm);
r = zeros(m,1);	% allocate storage for residuals
for i = 1:m
	if any(idx_sel==i)  % skip ones already selected...
		r(i) = sum(ym.^2);	% skip ones already selected, make r big
	else
		b = xm(:,[idx_sel,i]) \ ym;		% calc regr coef for each col in a
		y_hat = xm(:,[idx_sel,i]) * b;	% prediction
		r(i) = sum((ym - y_hat).^2); % calc sum squared error
	end
end
[rmin,idx] = min(r);	% find best one
idx = [idx_sel idx];	% add it to the index of selected vars

%--------------------------------------------------------------------------
function [idx,rmin] = delete_worst(xm,ym,idx_sel);
% DELETE_WORST - deletes the worst variable in a(:,idx) for L-S cabliration of c.
%
% USE:
%[idx,rmin]=delete_worst(xm,ym,idx);
[n,m]=size(xm);
k = length(idx_sel);
r = zeros(k,1);	% allocate storage for residuals
for i = 1:k
	idx = idx_sel;	% initialize index of vars
	idx(i) = [];	% delete k-th index
	b = xm(:,idx) \ ym;		% calc regr coef
	y_hat = xm(:,idx) * b;	% prediction
	r(i) = sum((ym - y_hat).^2); % calc sum squared error
end

% display some diagnostic info for debugging
% [idx_sel; r']

[rmin,ridx] = min(r);	% find best regression
idx = idx_sel;
idx(ridx) = [];			% delete it
