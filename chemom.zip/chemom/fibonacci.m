function [fib]=fibonacci(k)
% FIBONACCI -- compute the Fibonacci sequence to k
%
% [f]=fibonacci(k);

% initialize storage
fib=zeros(k,1);
fib(1)=1;
fib(2)=1;

for i = 3:k
  fib(i) = fib(i-1) + fib(i-2);
end;

fprintf(1,'%20.0f %3g\n',[fib (1:k)']');
