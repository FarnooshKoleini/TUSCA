function [ix]=lvgspl2(D,n);
% LVGSPL2 -- Highest leverage sample selection function for matrix D.
%
%   Returns index of n samples selected from D in ix.
%
% See also "Chemometrics", Sharaf, Illman, Kowalski (1986) Wiley.
% pp 240-241.
% Note: This method uses sum of squares to find spl with highest
% variance instead of calc inv(hat matrix).
%
% [ix]=lvgspl2(D,n);
[r,c]=size(D);  % get dimension of data matrix
ix=zeros(n,1);  % allocate storage for spl selection index

%
% mean correct the data first
%
m=mean(D);
D=D-m(ones(1,r),:);

for i=1:n
	H=sum((D.^2)');  % calc variance of spls
	[x,idx]=max(H);  % spl selected has max variance
	ix(i)=idx;
	z=D(idx,:);
%
% remove selected spl and calc component of data orthogonal
% to it.
%
	for j=1:r;
		dotprodz = z * z';
  dotprod2 = z * D(j,:)';
%	next line calc's the portion of D(j,:) orthogonal to z
		D(j,:) = D(j,:) - dotprod2 ./ dotprodz .* z;
	end;
end;
