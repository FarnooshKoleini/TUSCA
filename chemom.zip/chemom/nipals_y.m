function [W,P,Q,R,beta]=nipals_y(X,Y,A)		% A = number of PLS latent vectors to be computed
% NIPALS_Y -- do NIPLS deflation of y w/ PLS model of X
convcrit=1e-10;								% beta=PLS regression coefficients.
for i=1:A,									% convergence criteria for the NIPALS algorithm.
	u=Y(:,find(std(Y)==max(std(Y))));	
	diff=1;									% assigning the y-variables with the largest variance % to u_initial.
	while (diff > convcrit),	
		u0=u;	
		w=X'*u/(u'*u);	
		w=w/(sqrt(sum(w.^2)));				% compute w
		r=w;								% normalizing w to unity.
		if i>1,								% compute r via equation (30) so that the score
			for j=1:i-1,					% vector, t, can be computed directly from the
				r=r-(P(:,j)'*w)*R(:,j);		% original X).
			end	
		end	
		t=X*r;								% compute t
		q=Y'*t/ (t'*t);						% compute q
		u=Y*q/(q'*q);						% compute u
		diff=(sqrt(sum((u0).^2)))/(sqrt(sum(u.^2)));	
	end  									% compute X-loadings
	p=X'*t/(t�*t);							% storing loadings and weights
	W=[W w];	
	R=[R r];	
	P=[P p];	
	Q=[Q q];	
	T=[T t];	
	U=[U u];	
											% only Y block is deflated.
	Y=Y-t*q';	
	end										% compute the regression coefficients.
beta=R*Q';	
end	