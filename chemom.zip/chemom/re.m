function [err]=RE(a);
% RE -- Malinowski's RE using the first 12 factors.  
% Note: #rows in a must be less than #columns.
% err=RE(a)
nfac=min(size(a)) - 1 ;
% if nfac > 12, 
%   nfac = 12; 
% end;
err=zeros(nfac,1);
[r,c]=size(a);
s=svd(a',0);
Trace_of_a=sum(s.^2);
ssq=Trace_of_a;
for i=1:nfac
  ssq=ssq-s(i)^2;
  err(i)=sqrt(ssq/((r-i)*(c-i)));
end;
