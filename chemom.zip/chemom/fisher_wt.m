function [f_wt]=fisher_wt(set_a,set_b);
% FISHER_WT - calc Fisher wts for cols of set_a and set_b w/ best discrim
%
% The largest fisher weight corresponds to the column of set_a and set_b that 
% has the largest difference.
%
%>inputs
%  set_a & b - The training set where rows are spectra and columns are wavelength
%
%>outputs
% f_wt - The fisher weights for the columns of set_a and set_b. 
%
%f_wt = fisher_wt(set_a,set_b);

[a,aa]=size(set_a);
[b,bb]=size(set_b);
if aa ~= bb, % checks demensions of variables.
   error('The columns in set_a must equal the columns in set_b')
end;
f_wt=zeros(1,aa); %initializes f_wt.
[mcset_a,mset_a]=meancorr(set_a); % mean correction of variables.
[mcset_b,mset_b]=meancorr(set_b);
num=abs(mset_a-mset_b); %numerator for the fisher weight equation.
sqmcset_a=(mcset_a).^2;
sqmcset_b=(mcset_b).^2;
sum_sqtrn=sum(sqmcset_a);% sum of squares for variables
sum_sqrej=sum(sqmcset_b);
den=((sum_sqtrn/a)+(sum_sqrej/b)); %denominator for the fisher weights equation.
f_wt=((num)./(den)); %calculation of fisher weights.

