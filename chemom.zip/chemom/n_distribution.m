function y = n_distribution(x);
%
% calculate the normal distribution function of x for plotting.
% note:  p values are obtained from the integral of this function.

y = 1/(sqrt(2*pi))*exp(-(x.^2)/2);

