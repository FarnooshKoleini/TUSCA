function [besti,re,ie,ind,bi,bf] = maltest(data,lamda,sumlamda,scalopt,alpha,doplots);
% MALTEST -- Malinowski's eigenvalue/error functions and F-test
%	[besti,re,ie,ind,bi,bf] = maltest(data,lamda,sumlamda,scalopt,alpha,doplots);
%	Inputs:
%		data		data matrix
%		lamda		vector of eigenvalues (if present, don't calculate from data)
%		sumlamda		total variance = sum of eigenvalues
%		scalopt		scaling option (see scaleoptions)
%		alpha		probability value for F test (e.g., 0.05 or 5%)
%		doplots		0 = don't 1 = do show plots
%	Outputs:
%		besti		Compromise estimate, based on bi and bf
%		re		Real Error vector
%		ie		Imbedded Error vector
%		ind		Indicator function vector
%		bi		estimate of optimal number of PCs based on IND
%		bf		estimate of optimal number of PCs based on F-test

%		Error tests:	Malinkowski & Howery, NY: Wiley, 1980, pp. 72-86
%		F test:	Malinowski, J. Chemom., 3:49-60 (1988)
%		F test Errata: Malinowski, J. Chemom., 4:102 (1990)

%	� 1991 Infometrix

%	Routines from Infometrix Matlab library:
%		fprob

if alpha == 0,
	alpha = 0.05;
end

[nrows,ncols] = size(data);
if lamda==0, doscat=1; end
%check if nr>nc...
if nrows > ncols,	
	nr = nrows; nc = ncols;
	if doscat, scat = data' * data;	end
else
	nr = ncols; nc = nrows;
	if doscat, scat = data * data';	end
end
%Note: nc is smaller dimension
if doscat,
	lamda = -sort(-eig(scat));
else
	%lamda = -sort(-lamda);
end

if scalopt == 1 | scalopt == 5,
	meancent = 1;
end

if meancent,
	nfac = nc - 2;
else
	nfac = nc - 1;
end
if length(lamda)<nfac, nfac = length(lamda); end
%if meancent, nfac = nfac - 1;end
re = zeros(nfac,1);
ie = re;
ind = re;
F = re;

%sumlamda = sum(lamda);

for nf = 1:nfac,	
%	disp([nf sumlamda lamda(nf)]);
	sumlamda = sumlamda - lamda(nf);


%	Real Error:
	if meancent, 
		df = nr * (nc - nf - 1);
	else
		df = nr * (nc - nf);
	end
	re(nf) = sqrt(sumlamda / df);

%	Imbedded Error:
	if meancent,
		df = nr * nc * (nc - nf - 1);
	else
		df = nr * nc * (nc - nf);
	end
	ie(nf) = sqrt(nf * sumlamda / df);

%	Indicator Function:
	if meancent,
		ind(nf) = re(nf) / ((nc - nf - 1)*(nc - nf - 1));
	else
		ind(nf) = re(nf) / ((nc - nf)*(nc - nf));
	end

%	F statistic:
	rg = (nf+1):nc;
	dfnum = sum((nr - rg + 1) .* (nc - rg + 1));
	dfden = (nr - nf + 1) * (nc - nf + 1);	
	F(nf) = (dfnum / dfden) * (lamda(nf) / sumlamda) * (nc - nf);
%	F(nf) = (dfnum / dfden) * (lamda(nf) / sumlamda);	%corrected in Errata

	if meancent,
		avalue(nf) = fprob(F(nf),1,nc-nf-1);
	else
		avalue(nf) = fprob(F(nf),1,nc-nf);		
	end
end	%for i

[dummy,bi] = min(ind);
goodf = find(avalue < (alpha));
if length(goodf) > 0,
	[dummy,bf] = max(goodf);
else
	bf = nfac;
end

%Compromise on which result to use:
if bi == 1,	%implies IND function is not reliable
	if bf > (nc - 2),	%but neither is F; not a likely case
		besti = bi;
	else	
		besti = bf;
	end
else	%i.e., if bi > 1
	if bf > 15,	%implies F statistic is probably not reliable
		besti = bi;
	else	%too hard to call which is better; so round down their mean
		besti = floor(mean([bi bf]));
	end
end

if doplots,
	clg
	subplot(221);
	plot(lamda);	title('Eigenvalues');
	plot([re ie]);	title('RE & IE');
	plot(ind);	title('IND Function');
	hold; plot(bi,ind(bi),'bo'); hold off
	axis([0 nfac 0 max([avalue alpha+0.01])]); 
	plot(avalue);	title('F-test');
	hold;
	plot(1:nfac,alpha*ones(1,nfac),'--b');
	plot(bf,avalue(bf),'bo');
	hold off;
end
