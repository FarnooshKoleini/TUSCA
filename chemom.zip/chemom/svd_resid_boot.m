function D_boot = svd_resid_boot(D,k,N);
% D_boot = svd_resid_boot(D,k,N);
%
% bootstrap a data matrix using a K-factor PCA model
%
% Fitted data values extract measurement error, thus resids are 
% size corrected by 1 / ((1-k/n)(1-K/m))^1/2
%
% j rows of size corrected residuals are sampled with replacement
% and averaged together to form the new residual.
% The order in which they are drawn is assumed to be immaterial(exchangeability)
% with respect to rows.

% This technique is described in Faber and Kowalski, J. Chemom, 11 (1997), 181-238.
% and also in N. M. Faber, Quantifying the effect of measurement errors on the
% uncertainty in bilinear model predictions: a small simulation study,
% Anal. Chim. Acta, 439 (2001), 193-201.

[n,m] = size(D);
[u,s,v] = svdt(k,D);                % calc k-factor PCA model

R = D - u*s*v';                     % calc resid matrix
R = R * 1/sqrt((1-k/n)*(1-k/m));    % size adjusted residuals

Uidx = ceil(n*(1:N)/N);
D_boot = u(Uidx,:)*s*v';

for i = 1:m
    idx = ceil(n*rand(N,1));        % generate pseudo-random matrix, uniform distr.
    D_boot(:,i) = D_boot(:,i) + R(idx,i);     % get random resid spectra
end;

