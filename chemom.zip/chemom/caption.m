function caption(x,y,lab); 
% CAPTION -- subroutine for pcr
r=length(x);
  for i=1:r
      text(x(i),y(i),[lab sprintf('%g',i)]);
  end
