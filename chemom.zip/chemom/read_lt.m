function [a,wv,c,spl_name]=read_lt(fn);
%  READ_LT -- matlab function for reading ascii LT NIR files.
%
%  [a,wv,c,spl_name]=read_lt('filename');
inp=fopen(fn,'rt');
if inp < 0
  error(['---> File ' fn ' not found.']);
end;

fgetl(inp);								% get first line and throw away
nscans=fscanf(inp,'%g',1);
fscanf(inp,'%s',1);
start_wv=fscanf(inp,'%g',1);
fscanf(inp,'%s',2);
stop_wv=fscanf(inp,'%g',1);
fscanf(inp,'%s',2);
step_wv=fscanf(inp,'%g',1);
fgetl(inp);

disp(sprintf('Reading %g spectra (wvln range = %g:%g:%g).',nscans,start_wv,step_wv,stop_wv));

wv=start_wv:step_wv:stop_wv;
npoints=length(wv);

spl_name=zeros(nscans,40);
c=zeros(nscans,1);
a=zeros(nscans,npoints);

%
% loop for reading sample names
%

for i=1:nscans
	fgetl(inp);		% get blank line
	s=fgetl(inp);	% get spl name
	if length(s) > 40, s=s(1:40); end;
	disp(sprintf('%s',s));
	spl_name(i,:)=sprintf('%40s',s);
	c(i)=fscanf(inp,'%g',1); fgetl(inp);
	x=fscanf(inp,'%g',2*npoints); fgetl(inp);
	a(i,:)=x(2:2:2*npoints)';
end;

fclose(inp);
