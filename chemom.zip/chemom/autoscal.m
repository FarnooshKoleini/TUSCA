function [y,m,s]=autoscal(x);
% AUTOSCAL - Mean center and standardize columns of a matrix.
%
% [y,m,s]=autoscal(x);
%   or
% [y]=autoscal(x);
%
% See also: UNSCALE, MEANCORR, SCALE
[r,c]=size(x);
m=mean(x);
s=std(x);

y=(x-m(ones(1,r),:)) ./ s(ones(1,r),:);
