function [ix]=detspl(D,k,n);
% DETSPL -- sample selection for regression (maximize determinant)
% [ix]=detspl(D,k,n);
%
% Highest scatter sample selection function for matrix D.
%
%   Returns index of n samples selected from D in ix.
%   Argument k specifies number of principal components to use.
%
% See "Detection of Multivariate Outliers..." unpublished work
% N.K. Shah and P.J. Gemperline.
%

[r,c]=size(D);     % get dimension of data matrix
ratio=zeros(r,1);  % allocate storage for ratio
ix=zeros(n,1);     % allocate storage for spl selection index

%
% mean correct the data first
%
m=mean(D);
D=D-m(ones(1,r),:);

%
% Note: for MLR subst. substitute selected 
% wavelengths for pc scores.
%

[v,s,u]=svd(D',0);       % get pc scores (NIPLS algorithm would
                        % save compute time here)
[u,s,v]=trim(k,u,s,v);  % only retain k factors
sc=u*s;                 % calc scores
S=det(sc'*sc ./ (r-1)); % calc determinant of full scatter matrix

for i=1:r
	sc_red=sc;
 sc_red(i,:)=[];        % delete ith row of scores
 sc_red=meancorr(sc_red); % mean center the reduced scores matrix
	Sa=det(sc_red'*sc_red ./ (r-2)); % calc determinant of reduced scatter matrix
 ratio(i)=Sa./S;        % calc test ratio
end;

% sort ratio.  "outliers" are observations with smallest scatter ratios

[y,iy]=sort(ratio);
ix=iy(1:n);

end;
