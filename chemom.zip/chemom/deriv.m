editfunction [y]=deriv(x,n);
% DERIV - Smooth and take derivatives of columns (Identical to DERIVATIVE)
%
% [y]=deriv(x,n);
%
% Function to take the first derivative and smooth columns in a 
% matrix using the 3-point binomial filter.  n is the number of 
% times to apply the filter.
if nargin < 2,
    n = 1;
end;
[r,c]=size(x);
if r<c,
    x=x';
    [r,c]=size(x);
end;    
[y]=derv(x,r,c);
for i=1:n
  [y]=smth(y,r);
end;
