function mat2pir();
% MAT2PIR -- function to export matlab data to Pirrouette
disp(' ');
disp('This matlab function tries to export spectral data from a matlab *.mat');
disp('file into a series of ascii files that can be imported by Pirouette.');
%

%
% get input file
%
dir *.mat
fn=input('Enter file name to process: ','s');
eval(sprintf('load %s',fn),'error(''File not found.'')');

%
% get output vars
%
export_data = [];
whos

disp('Enter names of variables to be exported.')
export_spectra=input('Name of var containing spectra, one per row, <return> for none: ','s');
tx=sprintf('export_spec=%s;',export_spectra);
if ~isempty(export_spectra)
  eval(tx,'error(''Cannot find variable.'')');
else
  export_spec = [];
end;

export_concent=input('Name of var containing concentrations, <return> for none: ','s');
tx=sprintf('export_conc=%s;',export_concent);
if ~isempty(export_concent)
  eval(tx,'error(''Cannot find variable.'')');
else
  export_conc = [];
end;

[sr,sc]=size(export_spec);
[cr,cc]=size(export_conc);

if sr~=0 & cr~=0 & sr~=cr,
  error(sprintf('Number of rows in %s must match number of rows in %s',export_spectra,export_concent));
end;

%
% export derivative spectra?
%
if ~isempty(export_spec),
  dv=input('Do you want to export derivative spectra? [1=y,0=n]: ');
  if dv==1,
    export_spec=deriv(export_spec',1)';
  end;
end;

export_data = [export_conc export_spec]';

sr = max([sr cr]);
nvars = cc + sc;

%
% test length of output rows
%
max_len = 32784;
%max_len = 48;
tx=sprintf('%e ',export_data(1,:));
if length(tx) > max_len
  nseq = ceil(length(tx)/max_len);
  s_r = ceil(sr/nseq);
else
  nseq = 1;
  s_r = sr;
end;

disp(sprintf('\nYour output will be split into %g file(s) so that each row contains',nseq));
disp('less than 32768 characters (Pirouette limitation).');

fn=input('Enter root name for file sequence (6 chars max): ','s');

current_spec = 1; 

for i=1:nseq
  seq_fn = sprintf('%s%g',fn,i,'.dat');
  disp(sprintf('Creating file %s.',seq_fn));
  fid=fopen(seq_fn,'wt');
  if fid < 1
    error(sprintf('Could not create file %s.',seq_fn));
  end;

  if (sr - current_spec + 1) >= sr,
    stop_spec = current_spec + s_r - 1;
  else
    stop_spec = sr;
  end;
  
  n_s = stop_spec-current_spec + 1;
  fprintf(fid,'#d %gx%g\n',nvars,n_s);
  fprintf(fid,'#r'); 
  fprintf(fid,' spl%g',current_spec:stop_spec); fprintf(fid,'\n');
  for j = 1:nvars;
	fprintf(fid,'%e ',export_data(j,current_spec:stop_spec));
	fprintf(fid,'\n');
  end;
  fclose(fid);
  current_spec = stop_spec + 1;
end;










