function [yhat,bhat,rhat]=asym_lsq(x,y,p)
% asym_lsq -- compute asymmetric least squares, 
%              e.g., down-weight negative deviations.
% inputs
%    x = dependent var
%    y = independent var
%    p = weighting factor, p = 0.5 gives unweighted lsq.
%    p < 0.5 downweights neg deviations
%    p > 0.5 downweights positive deviations
% 
% outputs:
%   yhat, bhat, rhat, intercept = estimated y, slope(s), residuals,
%   intercept
%
% use:
%[yh,bh,rh,ih]=asym_lsq(x,y,p);

% copyright 2009 Paul J. Gemperline, East Carolina University

[r,c]=size(x);
[ry,cy]=size(y);
if cy > 1, error('asym_lsq: y must be a column vector'); end;
if r ~= ry, error('asym_lsq: number of columns in x and y must be the same.'); end;

xaug = [ones(r,1) x];
w = ones(r,1);
w_old = zeros(r,1);
W=spdiags(w,0,r,r); % create sparse diagonal matrix, W (save lots 'o memory)
%
% iterative loop to calc weighted lsq
%
iter = 1;
while any(w ~= w_old) && iter < 20;
    bhat = inv(xaug' * W * xaug) * xaug' * W * y;
    yhat = xaug * bhat;
    rhat = y - yhat;
    %
    % calc asymmetric weights
    % For r > 0, w = p.  For r < 0, w = 1 - p
    %
    w_old = w;
    w = p*(rhat>0)+(1-p)*(rhat<=0);
    W=spdiags(w,0,r,r);
    iter = iter + 1;
end;
