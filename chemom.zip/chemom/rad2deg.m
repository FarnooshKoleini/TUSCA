function [deg] = rad2deg(rad);
% RAD2DEG -- convert radians to degrees
deg = rad/(2*pi)*360;
