function [x]=svd_inv(y,nfac);
% SVD_INV -- compute left or right pseudo inverse w/ svd and nfac factors.

[n,m]=size(y);

[u,s,v]=svd(y);			% compute svd & trim unwanted factors
u=u(:,1:nfac);
s=s(1:nfac,1:nfac);
v=v(:,1:nfac);

x = v * diag(1./diag(s)) * u';
