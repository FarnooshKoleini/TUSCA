function [d,pr,idx] = mahald(uv,uvt,k,sort_opt);
% MAHALD - calculate the Mahalanobis Distances of samples. 
%
% Function to calculate the Mahalanobis Distances of samples, given v 
% where v is a matrix of column-wise variables.  The training set, v, is 
% used to estimate distances for the test set, vt.
%
% The variable k specifies that k principal component scores are to be used.
% k=0 specifies that raw variables should be used instead.
% Sort_opt=1 returns the distances and probabilities sorted low to high.
%
% The samples' distances from the centroid are returned in d.  The 
% probability density (Hotelling's T-squared) for the distance is given in pr.
% The original sample number is given in idx.
%
% [d,pr,idx] = mahald(v,vt,k,sort_opt);

% COPYRIGHT, 1994.  Un-authorized use prohibited.
% Paul J. Gemperline
% Department of Chemistry
% East Carolina University
% Greenville, NC 27858
% 919-757-6767

[r,c]=size(uv);
[rt,ct]=size(uvt);

[uv,m]=meancorr(uv);		% always use meancorrected data
uvt=uvt-m(ones(1,rt),:);

if nargin ~=4		
  error('wrong number of input vars.');
end;

if k==0,			% use raw variables
  v=uv;
  vt=uvt;
  k=c;
else				% calc princ. components
  [uu,ss,vv]=svd(uv);
  [uu,ss,vv]=trim(k,uu,ss,vv);
  vt=uvt*vv;
  v=uu*ss;
end;

s=inv((v' * v)./(r-1));		% calc inv var-covar matrix

d=(vt * s) .* vt;		% calc distances for test data
[rd,rc]=size(d);
if rc > 1,
	d=sqrt(sum(d')');
else
	d=sqrt(d);
end;

if sort_opt == 1 		% sort 'em
  [d,idx]=sort(d);
end;

pr=1-hot_t(k,r,d);		% calc prob level.

% 12/7/95:
%
% see Ch 6, pp 232-233, J & W.
% Degrees of freedom for the test should be p & n-p when one spl is being
% compared w/ mean of n.
%
% This version and the use of hot_t is correct.			

