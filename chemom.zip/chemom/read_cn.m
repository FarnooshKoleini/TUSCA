function [c,constit_name]=read_cn(fn,nconstit);
%  READ_CN -- read NIR NSAS constituent files.
%  Works for spectra transferred from pc to rs/6000 via binary ftp.
%
%  [c,constit_name]=read_cn('filename',nconstit);
%        or
%  [a,spl_name]=read_cn;

%  Copyright Paul J. Gemperline, 2000
%  gemperlinep@mail.ecu.edu

if nargin==0,
   [fn,pt]=uigetfile('*.cn','Select NSAS *.cn file');
   fn = fullfile(pt,fn);
   nconstit = str2num(char(inputdlg('Enter num. constituents...')));
end

inp=fopen(fn,'r','ieee-le');

constit_name=zeros(nconstit,12);

header=fread(inp,384,'char');
for i=1:nconstit
   constit_name(1,:)=setstr(header(((i-1)*12)+1:i*12)');
end;

%
% loop for reading sample names
%
c=[];
temp=fread(inp,32,'float32');
while ~feof(inp)
  c=[c; temp(1:nconstit)'];
  temp=fread(inp,32,'float32');
end;

