function [spl,t,w,c,a]=read_lkb(fn);
%  READ_LKB -- reads a total absorbance chromatogram from lkb *.cat files.
%
%  Use read_lkb_cat to get a data matrix.
%
% [spl,t,w,c,a]=read_lkb(fn);

inp=fopen(fn,'r','l');

% calc size of file
fseek(inp,0,1);
byte_count=ftell(inp);
num_blocks=(byte_count-4096)/6144;
frewind(inp);

k=fread(inp,4096,'char')';	% get the spl name etc.

spec_per_block=k(83)+256*k(84);
spec_size=k(85)+256*k(86);
int_time=(k(89)+256*k(90))./10;
start_time=k(91)+256*k(92);
stop_time=k(93)+256*k(94);
step_time=(k(95)+256*k(96))./10;
start_lamb=k(97)+256*k(98);
stop_lamb=k(99)+256*k(100);
step_lamb=k(101)+256*k(102);

k(200)=32;
spl=setstr(k([1:10 200 11:18 200 19:33 200 34:73]));

num_spec = num_blocks * spec_per_block;
a = zeros(num_spec,spec_size-1);

stop_time = start_time + (num_spec * step_time) - step_time;
t = start_time:step_time:stop_time;
w = start_lamb:step_lamb:stop_lamb;

spec_no=0;

for i=1:num_blocks
  buf=fread(inp,3072,'int16');
  for j=1:spec_per_block
    spec_no=spec_no+1;
    start_ix=((j-1)*spec_size)+1;
    a(spec_no,:)=buf(start_ix:start_ix+spec_size-2)';
  end;
end;

a = a * 0.305 ./ 4096.0;

c=sum(a');

fclose(inp);

