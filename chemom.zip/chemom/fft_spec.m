function y=fft_spec(x);
% FFT_SPEC -- calc fft of spectra (rows), all real coef.
%
% y = fft_spec(x);

[r,c] = size(x);
if c~=1, 				% do FFT on rows
  x2 = [x zeros(r,1) x(:,c:-1:2)]';
  y = real(fft(x2))';
  y = y(:,1:c+1);
else					% do FFT on col vector
  x2 = [x' 0 x(r:-1:2)']';
  y = real(fft(x2));
  y = y(1:r+1);
end;
