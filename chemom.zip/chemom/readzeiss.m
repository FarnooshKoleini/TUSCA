function readzeiss()

% readzeiss.m 
% Reads ASCII output from tec5USA spectrometer software
% Creates a MATLAB file containing the spectral data
% matrix "a" and the wavelength vector "wv"

% ReadZeiss - Beta 1 - Created by John D. Blanton - September 09, 2008

format long e

%-------------------------- Setup --------------------------%
success = 0;                                                % function success flag
  
%------------------------ Open Files -----------------------%

[PathName, GroupFileNamesChronoSorted, Group_t0, Group_t, NamesStr, SerialDateNums, FileNames] = getinput();

for h = 1 : length(GroupFileNamesChronoSorted)
    FileNamesChronoSorted = GroupFileNamesChronoSorted{h};
    t0 = Group_t0{h};
    t = Group_t{h};
    for i = 1 : length(FileNamesChronoSorted)
        [header, data, footer] = readsinglefile([PathName FileNamesChronoSorted{i}]);
        [col_group_labels,... 
            ncol_group_labels,... 
            group_width, ...
            ngroups,... 
            col_labels,... 
            data] = parser(header, data, FileNamesChronoSorted{i});
        if group_width == 0
                % SINGLE GROUP CONDITION - SUPPORT FOR THIS TO BE ADDED LATER
        else
            for i = 1 : ncol_group_labels
                current_data_col_mult = (i - 1);
                current_col_group_label = strrep(col_group_labels{i}, ' ', '_');
                for j = 1 : group_width
                    current_data_col = (current_data_col_mult * group_width) + j;
                    current_col_label = col_labels{j};
                    combined_name = [current_col_group_label '.' current_col_label];
                    zdata = ['data(:, ' num2str(current_data_col) ');'];
                    if exist(current_col_group_label);
                        s = ['fieldtest = isfield(' current_col_group_label ', ''' current_col_label ''');'];
                        eval(s);                                                    % Is col_label a field of col_group?
                        if fieldtest                                                % if the current_col_label IS A FIELD of the current_col_group_label
                            s = ['[null, combined_name_nc] = size(' combined_name ');'];
                            eval(s);                                                % find out how many columns are in that field
                            col_idx = combined_name_nc + 1;                         % define col_idx as a new column to be added to the field
                            target = [combined_name '(:,' num2str(col_idx) ')'];    
                            s = [target ' = ' zdata];
                            eval(s);                                                % store data in the new column
                        else                                                        % If the current_col_label IS NOT A FIELD of the group
                            s = [combined_name ' = ' zdata]; 
                            eval(s);                                                % store data in new field
                        end
                    else                                                            % If the GROUP DOESN'T EXIST
                        s = [combined_name ' = ' zdata];
                        eval(s);                                                    % store data in new field of new group
                    end
                end
            end
        end
    end
    %-------------------- Output to .mat file ------------------%
    clear FileNamesChronoSorted col_group_labels col_idx col_labels combined_name combined_name_nc...
    current_col_group_label current_col_label current_data_col current_data_col_mult data fieldtest...
    group_width header i j ncol_group_labels null target zdata s PathName;
    savename = NameStr(GroupIdx{h}(1));
    while success == 0                                          % prompt user for filename until file is saved
        % savename = input('\n \n File name for MATLAB export (filename) : ', 's');
        % savename = NameStr(GroupIdx{h}(1));
        eval(['savefile = ''' savename '.mat'';'])              % append '.mat' extention to filename
        fid = fopen((savefile), 'r');                           % attempt to open file
        if fid == -1                                            % IF FILE DOESN'T EXIST...
            clear fid
            save (savefile);                                       % ...create it...
            fprintf(['\nSUCCESS : ' NameStr(GroupIdx{h}(1)) ' data saved to ' savefile '\n'])   % ...display success message...
            success = 1;                                            % ...and flag success
        else                                                    % IF FILE DOES EXIST...
            fclose(fid);                                            % ...close it...
            clear fid
            fprintf('\nERROR : File already exists!\n')             % ...and display error message
            savename = input('\n \n Choose alternate filename for MATLAB export of ' NameStr(GroupIdx{h}(1)) ' data (filename) : ', 's');
        end
    end
end

%--------------------------------------------------------------------------------------------------------%
%   HELPER FUNCTION : getinput                                                                           %
%--------------------------------------------------------------------------------------------------------%

function [PathName, GroupFileNamesChronoSorted, Group_t0, Group_t, NamesStr, SerialDateNums, FileNames, GroupIdx] = getinput()

%-------- Build list of files to open and timestamps -------%
FilterSpec = {'*.txt', 'MultiSPEC PRO ASCII File'};         % define possible input file types
DialogTitle = 'Select ASCII Data Files to Read';            % define 'File>Open' Dialog box title
[FileNames, PathName, FilterIndex] = uigetfile(FilterSpec, DialogTitle, 'MultiSelect', 'on');



%====================================== IF MULTIPLE FILES TO READ ======================================%
if iscell(FileNames);         
%---- Create Text Array and Time Vectors from Filenames ----%      
    for i = 1 : length(FileNames)
        CurrentFileName = FileNames{i};                     % pull a filename to parse from the list
        delims = strfind(CurrentFileName, '_');             % locate delimiters in the filename
        NamesStr{i} = CurrentFileName( 1 : (delims(end-1) - 1) );  % store text portion of filename
        DateTimeStr{i} = CurrentFileName( (delims(end-1) + 1) : (delims(end) + 8) );
        DateTimeStr{i} = strrep(DateTimeStr{i}, '_', '');   % remove delimiter separating date and time
        DateTimeStr{i} = [DateTimeStr{i} '0'];              % append a "0": centiseconds --> milliseconds
        SerialDateNums(i) = datenum(DateTimeStr{i}, 'ddmmyyyyHHMMSSFFF');
        DateTimeVecs(i,:) = datevec(SerialDateNums(i));     % build matrix of date vectors
    end

%--------------- Create Group Indices of Files -------------%    
    GroupCount = 0;
    UnassignedIdx = [ 1 : length(NamesStr) ];
    while ~isempty(UnassignedIdx)
        GroupCount = GroupCount + 1;                                          % update the running tally of groups
        TF = strcmp(NamesStr{min(UnassignedIdx)}, NamesStr(UnassignedIdx));   % test whether each unassigned name is equal to the first
        GroupIdx{GroupCount} = UnassignedIdx(find(TF==1));                    % store indices of 'positives' in group index
        UnassignedIdx = UnassignedIdx(find(TF==0));                           % update the index of unassigned names
    end
    
    for i = 1 : GroupCount
        GroupSerialDateNums{i} = SerialDateNums(GroupIdx{i});
        GroupFileNames{i} = {FileNames{GroupIdx{i}}};
        [GroupSerialDateNumsSorted{i}, GroupChronoIdx{i}] = sort(GroupSerialDateNums{i});
        for j = 1 : length(GroupChronoIdx{i})
            GroupDateTimeVecsChronoSorted{i}(j,:) = DateTimeVecs((GroupChronoIdx{i}(j)), :);
            GroupFileNamesChronoSorted{i}{j} = GroupFileNames{i}{GroupChronoIdx{i}(j)};
            %GroupDateTimeVecsChronoSorted{i}(j,:) = GroupDateTimeVecs{i}((GroupChronoIdx{i}(j)), :);
        end
        Group_t0(i) = GroupSerialDateNumsSorted{i}(1);
        Group_t{i} = 0;
        for j = 2 : length(GroupSerialDateNumsSorted{i})
            Group_t{i}(j) = etime(GroupDateTimeVecsChronoSorted{i}(j,:), GroupDateTimeVecsChronoSorted{i}(1,:));
        end
    end
% if iscell(FileNames);                                       %======== IF MULTIPLE FILES TO READ ========%
%     for i = 1 : length(FileNames)
%         CurrentFileName = FileNames{i};                     % pull a filename to parse from the list
%         delims = strfind(CurrentFileName, '_');             % locate delimiters in the filename
%         DateTimeStr{i} = CurrentFileName( (delims(end-1) + 1) : (delims(end) + 8) );
%         DateTimeStr{i} = strrep(DateTimeStr{i}, '_', '');   % remove delimiter separating date and time
%         DateTimeStr{i} = [DateTimeStr{i} '0'];              % append a "0": centiseconds --> milliseconds
%         SerialDateNums(i) = datenum(DateTimeStr{i}, 'ddmmyyyyHHMMSSFFF');
%         DateTimeVecs(i,:) = datevec(SerialDateNums(i));     % build matrix of date vectors
%     end
% 
%     [SerialDateNumsSorted, ChronoIdx] = sort(SerialDateNums);  % Sort Serial Date Number vector
%     for i = 1 : length(ChronoIdx)
%         FileNamesChronoSorted{i} = FileNames{ChronoIdx(i)};     % Sort filename list by chronological order
%         DateTimeVecsChronoSorted(i,:) = DateTimeVecs((ChronoIdx(i)),:);
%     end
% 
%     t0 = SerialDateNumsSorted(1);                           % Define t0 by its clock time (Serial Date Number)
%     
%     t(1) = 0;                                               % Build elapsed time (seconds) vector "t"
%     for i = 2 : length(SerialDateNumsSorted)
%         t(i) = etime(DateTimeVecsChronoSorted(i,:), DateTimeVecsChronoSorted(1,:));
%     end
else                                                        %======== IF ONLY ONE FILE TO READ =========%
    delims = strfind(FileNames, '_');                           % locate delimiters in the filename
    if length(delims) > 2
        DateTimeStr = FileNames( (delims(end-1) + 1) : (delims(end) + 8) );
        DateTimeStr = strrep(DateTimeStr, '_', '');             % remove delimiter separating date and time
        DateTimeStr = [DateTimeStr '0'];                        % append a "0": centiseconds --> milliseconds
        SerialDateNums = datenum(DateTimeStr, 'ddmmyyyyHHMMSSFFF');   % Serial Date Number
        t = SerialDateNums;
        t0 = t;
        FileNamesChronoSorted = FileNames;
        Group_t{1} = t; 
        Group_t0{1} = t0;
        GroupFileNamesChronoSorted{1} = FileNamesChronoSorted;
    else
        % ! ! ! ! ! ! ! ! ! TIME CANNOT BE READ FROM FILENAME, USER MUST INPUT ! ! ! ! ! ! ! ! ! ! ! ! 
    end
        
end

return

%--------------------------------------------------------------------------------------------------------%
%   HELPER FUNCTION : readsinglefile                                                                     %
%--------------------------------------------------------------------------------------------------------%

function [header, data, footer] = readsinglefile(filetoread)

%-------------------------- Setup --------------------------%
fid = fopen(filetoread, 'r');                               % open file in read-only mode
line = 'a';                                                 % preset variable "line" to type "char"
d = 1;                                                      % initial line number for numeric data matrix                                  
f = 1;                                                      % initial line number for footer cell array                           
h = 1;                                                      % initial line number for header cell array                       

%--------- Extract data matrix, header, and footer ---------%
while (~feof(fid))                                          % until End of File (EOF) is reached...
    line = fgetl(fid);                                          % read a line from the ASCII file
    numline = str2num(line);                                    % attempt to create numeric vector from line
    if ~isempty(numline)                                        % ======= IF THE LINE IS NUMERIC DATA =======
        if exist('data')                                           % IF the numeric matrix is present... 
            data(d, :) = numline;                                     % store the line in the numeric matrix    
            d = d + 1;                                                % update the index of the next line number
        else                                                       % IF the numeric matrix has not been created
            data = zeros(1000, length(numline));                      % preallocate the numeric data matrix
            data(d, :) = numline;                                     % store the line in the numeric matrix
            d = d + 1;                                                % update the index of the next line number
        end
    elseif exist('data')                                        % ======= IF LINE IS TEXT AFTER THE DATA =======
        footer{f} = line;                                           % store the line in the footer cell array
        f = f + 1;                                                  % update the index of the next line number
    else                                                        % ======= IF LINE IS TEXT BEFORE THE DATA =======
        header{h} = line;                                           % store the line in the header cell array
        h = h + 1;                                                  % update the index of the next line number
    end
end

fclose(fid);                                                

if exist('data')
    data = data(1:d-1, :);                                          % trim numeric data matrix to appropriate size
else
    data = 0;
    % % % %  THIS IS A REFERENCE MEASUREMENT CONTAINING NO DATA - SUPPORT TO BE ADDED LATER ! !  % % % % %
end

if ~exist('footer')
    footer = 0;
end

return

%--------------------------------------------------------------------------------------------------------%
%   HELPER FUNCTION : parser                                                                             %
%--------------------------------------------------------------------------------------------------------%

function     [col_group_labels, ncol_group_labels, col_labels, wv_col_idx, data] = parser(header, data, FileName)
    
%-------------------- Parse text header --------------------%
last_txt_line = length(header);
col_labels = textscan(header{last_txt_line}, '%s',...
                                'delimiter', '\t',...
                                'multipledelimsasone', 1);
col_labels = col_labels{1};
[ncol_labels, null] = size(col_labels);
wv_col_idx = strmatch('Wavelength', col_labels);

%-------------------- Parse numeric data -------------------%
col_group_labels = textscan(header{(last_txt_line - 1)}, '%s',...       % ...get the group names
                                            'delimiter', '\t',...
                                            'multipledelimsasone', 1);
col_group_labels = col_group_labels{1};
[ncol_group_labels, null] = size(col_group_labels);


[rdata, cdata] = size(data);                            % dimensions of complete numeric data matrix

if cdata ~= ncol_labels
    ErrorStr = ['ERROR READING ' FileName ' : UNSUPPORTED FILE FORMAT : Data columns absent for some column labels (Reference data?)'];
    error(ErrorStr);
    % % % % % AUTOMATIC REFERENCE FILE DETECTION AND EXCLUSION NOT YET IMPLEMENTED!!!! % % % % % % 
end


% ngroups = length(wv_col_idx);
% 
% %-------------------- Parse numeric data -------------------%
% if ngroups > 1                                                              % IF THERE ARE MULTIPLE GROUPS 
%     col_group_labels = textscan(header{(last_txt_line - 1)}, '%s',...       % ...get the group names
%                                                 'delimiter', '\t',...
%                                                 'multipledelimsasone', 1);
%     col_group_labels = col_group_labels{1};
%     [ncol_group_labels, null] = size(col_group_labels);
%     group_width = ncol_labels / ncol_group_labels;
% else                                                                        % IF THERE IS ONLY ONE GROUP
%     [rdata, cdata] = size(data);                            % dimensions of complete numeric data matrix
%     wv = data(:, 1);                                        % wavelength vector
%     a = data(:, 2:cdata);                                   % spectral data matrix
%     col_group_labels = wv;                                  % use col_group_labels variable to output wv
%     ncol_group_labels = a;                                  % use ncol_group_labels varialbe to output a
%     group_width = 0;                                        % zero group_width will flag one group condition
% end

return