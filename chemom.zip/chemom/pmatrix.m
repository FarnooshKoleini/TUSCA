function [p,chat,ctesthat]=pmatrix(nvars,colnum,a,c,atest,ctest);
% PMATRIX -- P-matrix calibration.
% The matrices a and atest contain the calibration spectra and
% test spectra respectively in rows.
% The number of wavelengths to use and the column numbers must be
% supplied by the user.
% The matrices c and ctest contain the concentrations of the components
% in the calibration and test data sets respectively.
%
% [P,chat,ctesthat]=pmatrix(nvars,colnum,a,c,atest,ctest)
clc
echo on
asub=a(:,colnum);
asubtest=atest(:,colnum);
p=inv(asub'*asub)*asub'*c;
chat=asub*p;
[r,m]=size(a);
SEC=sqrt(sum((c-chat).^2)./(r-nvars))
ctesthat=asubtest*p;
[r,m]=size(atest);
SEP=sqrt(sum((ctest-ctesthat).^2)./r)
