function [prob] = t_dist(f,t);
% T_DIST -- probability two sets of data are different.
%
% [prob] = t_dist(f,t)
%
% A one tailed probabilty that two sets of data are significantly
% different where t is the student's t value and f is the degrees
% of freedom (i.e. f = #mem1 + #mem2 - 2).
%
% Written by Nichole Boyer on 6/28/93.
% Revised on 12/19/93.

[x] = f./(f + t.^2);

[alpha] = betainc(x,f/2,1/2);
[prob] = 1 - alpha./2;
