function sx = scale(x,means,stds)
% SCALE -- autoscale a matrix.
% Where a is the matrix to be scaled and m and s are the mean
% and standard deviation vectors, repspectively.
%
% a=scale(a,m,s);
% or
% a = scale(a,m);
% 
% a=(a-m(ones(1,r),:)) ./ s(ones(1,r),:);
[m,n] = size(x);
if nargin == 3
  sx = (x-means(ones(m,1),:))./stds(ones(m,1),:);
else
  sx = (x-means(ones(m,1),:));
end
