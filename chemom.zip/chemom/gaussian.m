function [x,y] = gaussian(start,stop,n,mean,sdev);
% GAUSSIAN -- generate a gaussian distribution 
% x will be linear spaced n-vector of values from start to stop
% y=f(x) will contain the distribution
%
% [x,y] = gaussian(start,stop,n,mean,sdev);
x=linspace(start,stop,n);
y=1./(sqrt(2*pi)*sdev)*exp(-(((x-mean)./sdev).^2)/2);
