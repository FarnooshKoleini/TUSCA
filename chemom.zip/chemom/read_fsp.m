function [wv,x]=read_fsp(fname,n);
%READ_FSP -- Read multiple Galactic *.fsp files
%
% [wv,x]=read_fsp(fname,n);
%           or
% [wv,x]=read_fp;
%
% Function to read sequentially numbered files from Galactic's GRAMS/32 *.FSP 
% file export format.  Files must be named in sequential order starting from 1
% with a root name of 4 characters.
%
% Example: acnn0001.fsp, acnn0002.fsp,...
%
% fname: root file name.
%     n: number of files.
%
% See also READ_FP for reading single files

%  Copyright Paul J. Gemperline, 2000
%  gemperlinep@mail.ecu.edu

if nargin==0,
   [fname,pt]=uigetfile('*.fsp','Select FIRST GRAMS/32 *.fsp file');
   n = str2num(char(inputdlg('Enter num. files...')));
end;
fname = fname(1:4);

% initialize
i = 1;
fnm = sprintf('%s000%g',fname,i);
fprintf(1,'Reading %s.\n',fnm);
fn = fullfile(pt,fnm);
[wv,y] =  read_fp(fn);

% allocate storage
x = zeros(n,length(y));
x(1,:) = y;

for i = 2:n
  if i < 10,
      fnm = sprintf('%s000%g',fname,i);
  elseif i < 100,
      fnm = sprintf('%s00%g',fname,i);
  elseif i < 1000,
      fnm = sprintf('%s0%g',fname,i);
  elseif i < 10000,
      fnm = sprintf('%s%g',fname,i);
  else
      error('too many spectra');
  end;
  fprintf(1,'Reading %s.\n',fnm);
  fn = fullfile(pt,fnm);
  [wv,x(i,:)] = read_fp(fn);
end;
