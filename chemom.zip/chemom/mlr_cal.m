function [chat,SEC,ix,b]=mlr(a1,c1,intercept,ix);
% MLR_CAL -- MLR calibration, non-interactive.
%
% a1:        calibration spectra spectra in rows.
% c1:        cal concentration data in rows.
% intercept: 1/0, include non-zero intercept in model.
% wv:        plotting index for spectra (optional)
% ix:        columns of vars to use in mlr (optional, if missing
%            mouse clicks used to select vars).
%
% c1p:      predicted concentrations.
% SEC:      figures of merit for cal set.
% ix:       vars selected w/ mouse clicks.
%
% For the final model, the matrix b  contains the MLR regression 
% coefficients for the model:  cp=a(:,ix)*b.
%
% See also: MLR MLR_CAL  STEP_MLR  MLR_DIAG  BOOT_MLR
%
% [c1p,SEC,ix,b]=mlr(a1,c1,intercept,ix);

if nargin < 4,
  error ('MLR - Wrong number of parameters.');
end

%
% get wavelengths
%
[ar,ac] = size(a1);

nfac = length(ix);
a=a1(:,ix);
c=c1;

[ar,ac]=size(a);
[cr,ncomp]=size(c);

%
% Augment a and atest w/ column of ones if non-zero intercept requested.
%
if intercept == 1, 
	a = [ones(ar,1) a];
	nfac = nfac + 1;
end

%
% Calculate b, SEC, SEP 
%
SEC=zeros(1,ncomp);

b=a\c;
chat = a * b;
df = ar - nfac;

if df == 0,
  SEC=zeros(1,ncomp);
else
  SEC = sqrt(sum((c - chat).^2) / df);
end
