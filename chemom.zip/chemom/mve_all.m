function [rd1,pr1,rd2,pr2] = mve_all(x,k,cut);
% MVE_ALL -- Calc robust distances of k PCA scores by the projection method.
%
%          [rd1,pr1,rd2,pr2] = mve_all(x,k,cut);
%
%          x is a data matrix to be examined. rd1 is a vector of
%          robust distances calculated by the function, RDPROJM,
%          The probability density (Hotelling's T^2 statistic) for
%          the distance, rd1 is given in pr1. Using pr1, the outliers
%          (pr1 <= cut) are excluded using weighting (if Pr > cut
%          then Wt = 1, if Pr <= cut then Wt = 0). And the distances,
%          rd2 are recalculated as a classical Mahalanobis distances.
%          k is the number of principal components.

[rt ct] = size(x);
[u s v] = svd(x);
[u s v] = trim(k, u, s, v);
xts = u(:,1:k);

[rd1] = rdprojm(xts);			% Calculates RD w/o Training

[pr1] = 1 - hot_t(k,rt,rd1);	% Calculates Probability

rc = 0;
for i=1:rt
  if pr1(i) > cut				% Takes Observations except Outliers
     rc = rc + 1;
     trid(rc) = i;
  end
end

% Calculates Mahalanobis Distances

xtrn = x(trid,:);				% Takes Training data set

[r c] = size(xtrn);

[xtrn m] = meancorr(xtrn);		% Mean-Correction
x = x - m(ones(1,rt),:);

[uu ss vv] = svd(xtrn);
[uu ss vv] = trim(k,uu,ss,vv);
vt = x*vv*inv(ss);
v = uu(:,1:k);

s = inv((v' * v)./(r-1));		% Inverse var-covar matrix

rd2 = (vt * s) .* vt;			% Mahalanobis distances
rd2 = sqrt(sum(rd2')');

pr2 = 1 - hot_t(k,r,rd2);		% Calculates Probability

end
