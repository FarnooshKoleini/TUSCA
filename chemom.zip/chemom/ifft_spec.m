function y=ifft_spec(x);
% IFFT_SPEC -- calc inverse fft of spectra (rows), all real coef.
%
% y = ifft_spec(x);

[r,c] = size(x);
if c~=1, 				% do inv FFT on rows
  x2 = [x x(:,c-1:-1:2)]';
  y = real(ifft(x2))';
  y = y(:,1:c-1);
else					% do inv FFT on col vector
  x2 = [x' x(r-1:-1:1)']';
  y = real(ifft(x2));
  y = y(1:r-1);
end;
