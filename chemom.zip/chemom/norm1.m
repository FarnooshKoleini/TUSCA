function sx = norm1(x)
% norm1 -- scale columns in a matrix to max = 1.
%
% sx=scale(x);
% 

[m,n] = size(x);
mx = max(x);
sx = x./mx(ones(m,1),:);
