function [a,t,wv,start_time]=read_z(fn)
% READ_Z -- read Zeiss data files.
%
%  [a,t,wv,start_time]=read_z('filename');
%       

if nargin < 1,
    error('Read_z: File indentifier string required.')
end;

f = dir(fn);
nfiles = length(f);
if nfiles < 1,
    error('Read_z: No matching files found.');
end;

% open first file to calc length
inp=fopen(f(1).name,'r');

for j = 1:4 % read the header
    s = fgetl(inp);
    if ~ischar(s), % if s is not of type char we have an error, this statement must return some characters
        fclose(inp);
        error('Read_z: Error reading spectrum 1: %s.',f(1).name);
    end
end;

x = fscanf(inp,'%g %g',[2, inf]);
% test for errors reading first file
[r,c] = size(x);    % get size of x
if r ~= 2 || c < 1,
    fclose(inp);
    error('Read_z: Error reading spectrum 1: %s.',f(1).name);
end

wv = x(1,:);
npts = length(x);
fclose(inp);

% allocate storage for speed
a = zeros(nfiles,npts);

for i = 1:nfiles
    fname = f(i).name;
    delims = strfind(fname, '_');             % locate delimiters in the filename
    DateTimeStr = fname( (delims(end-1) + 1) : (delims(end) + 8) );
    DateTimeStr = strrep(DateTimeStr, '_', '');   % remove delimiter separating date and time
    t(i) = datenum(DateTimeStr(1:14), 'ddmmyyyyHHMMSS')* 24 * 3600; % convert day/mo/yr/hr/min/sec part
    z =sscanf(DateTimeStr(15:16),'%g')./100; % convert millisecond part
    t(i) = t(i) + z;      % add msec to secs
    
    inp=fopen(fname,'r');

    for j = 1:4 % read the header
        s = fgetl(inp);
        if ~ischar(s), % if s is not of type char we have an error, this statement must return some characters
            fclose(inp);
            error('Read_z: Error reading spectrum %g: %s.',i,f(i).name);
        end
    end;

    x = fscanf(inp,'%g %g',[2, inf]);
    
    % test for errors reading file
    [r,c] = size(x);    % get size of x
    if r ~= 2 || c ~= npts,
        warning('Read_z - error reading spectrum %g: %s.',i,fname);
    else
        a(i,:) = x(2,:);
    end
    fclose(inp);
end;

% calc elapsed time

start_time = t(1); % save start time
t = (t-t(1));   % calc elapsed time, in seconds

% sort the data in order of increasing time in case read_z got 'em in wrong
% order

[t,idx]=sort(t); % sort times
a = a(idx,:); % use sort index to sort a;





