function [c_hat,c_csv,sec,rmsecv,b] = plscv(a,c,nuse,mean_corr,var_scale,nfac,pub_flag);
% PLSCV -- leave one out PLS cross validation
%
% PLS calibration.  Algorithm by Lorber, Wangen and Kowalski in
% J. Chemometrics 1, 19-31, 1987.
%
% The matrix a contains the calibration spectra. PLS is performed for one 
% through nfact factors using leave-one-out cross validation.
%
% The variables mean_corr and  var_scale are 1/0 parameters used to 
% indicate preprocessing steps.  
%
% c_hat: predicted conc
% c_csv: leave-one-out predictions
%
% [c_hat,c_csv,sec,rmsecv,b] = plscv(a,c,nuse,mean_correct,variance_scale,nfac,pub_flag);

if nargin < 7,
   pub_flag = 0;
end;
if nargin <6 6,
   error ('PLSCV - Wrong number of parameters.');
end;

%
% get global model
%
[Nsamp,Nconstit] = size(c);
if nfac > Nsamp - 3, nfac = Nsamp - 3; end;

[c_hat,ctemp,sec,SEP,b] = plsf(a,c,a(1,:),c(1,:),nuse,mean_corr,var_scale,nfac);

idx = 2:Nsamp;
i = 1;
[ctemp,c_csv(i,:),x,SEP] = plsf(a(idx,:),c(idx,:),a(i,:),c(i,:),nuse,mean_corr,var_scale,nfac);
rmsecv = SEP.^2;
for i = 2:Nsamp
   fprintf(1,'.');
   idx = setdiff(1:Nsamp,i);
   [ctemp,c_csv(i,:),x,SEP] = plsf(a(idx,:),c(idx,:),a(i,:),c(i,:),nuse,mean_corr,var_scale,nfac);
   rmsecv = rmsecv + SEP.^2;
end;
rmsecv = sqrt(rmsecv/Nsamp);
fprintf('\n');

for i = 1:Nconstit
   %
   % Dump relative error
   %
   l=ones(nfac,1);
   str=sprintf('No. factors   SEC      RMSECV  for component %g',i);
   disp(str);
   disp([(1:nfac)' sec(:,i) rmsecv(:,i)]);
   
   %
   % Plot the results for each component.
   %
   disp('Paused, hit <return> for plot.');
   pause
   
   %
   % SEC & RMSECV
   %
   semilogy(sec(:,i));
   hold on;
   semilogy(sec(:,i),'x');
   semilogy(rmsecv(:,i),'g');
   semilogy(rmsecv(:,i),'og');
   hold off;
   title(sprintf('Plot of SEC (x) and RMSECV (o) for component %g',i));
   xlabel('Number of factors');
   ylabel('Error')
   if pub_flag, pub_std(sprintf('sec%g',i)); end;
   
   %
   % Plot the regression coefficients
   %
   pause
   plot(b(:,i));
   title(sprintf('Plot of regression coefficients for component %g',i));
   ylabel('Magnitude');
   xlabel('Wavelength vars.');
   if pub_flag, pub_std(sprintf('regr_vec%g',i)); end;
   
   %
   %  Plot calibration curves
   %
   pause
   plot(c(:,i),c_hat(:,i),'x',c(:,i),c_csv(:,i),'o');
   caption(c(:,i),c_hat(:,i),'   ');
   title(sprintf('Results for component %g.  (x) c-hat. (o) c-csv.',i));
   ylabel('Estimated concentration');
   xlabel('Actual concentration');
   if pub_flag, pub_std(sprintf('c_hat%g',i)); end;

   %
   %  Plot component residuals
   %
   pause
   plot(c(:,i),c_hat(:,i)-c(:,i),'x',c(:,i),c_csv(:,i)-c(:,i),'o');
   caption(c(:,i),c_hat(:,i),'   ');
   title(sprintf('Residuals for component %g.  (x) c-hat. (o) c-csv.',i));
   ylabel('Actual-Predicted');
   xlabel('Actual concentration');
   if pub_flag, pub_std(sprintf('resid%g',i)); end;
end