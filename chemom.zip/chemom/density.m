function [d]=density(n,T);
% calc density of organic liquid according to C. L. Yaws, 
% works for: butanol, (more to be added) 
% 
% use (T in Kelvins): 
% d = density('name',T);

% Thermodynamic and
% Physical Property  Data, Gulf Publ, Houston, TX 1992

switch lower(n);
    case('butanol')
        A=0.2818; B=0.259; Tc=561.4;
    otherwise
        error('Unknown substance');
end;

% t=T+273.15;

d = A * B.^(-(1-T/Tc).^(2/7));

