function [W] = wfunc(RES,funcno,param,scale);
% WFUNC - Weighting functions for robust regression
%
% Send:
%    RES    - Residuals vector
%    funcno - required weighting function
%                      1. Huber's t function
%                      2. Ramsay's E function
%                      3. Andrew's wave function
%                      4. Tukey's biweight
%    param  - function parameter
%    scale  - robust estimate of scale
%
% Returns:
%    W      - residual weightings for use in WGTLS
%
% M J Chlond - Dec 94
% m.chlond@uclan.ac.uk
%
%W = wfunc(RES,funcno,param,scale)

RES = RES/scale;
n = length(RES);

if funcno == 1			% Huber's t function
    for i =1:n
        if abs(RES(i)) <= param;
            W(i) = 1;
        else
            W(i) = param/abs(RES(i));
        end
    end
end

if funcno == 2			% Ramsay's E function
    for i =1:n
        if RES(i) == 0;
            W(i) = 1;
        else
            W(i)=exp(-param*abs(RES(i)));  
        end
    end    
end

if funcno == 3			% Andrew's wave function
    for i =1:n
        if abs(RES(i)) > pi*param
            W(i) = 0;
        elseif RES(i) == 0
            W(i) = 1;
        else
            W(i) = sin(RES(i)/param)/(RES(i)/param) ;
        end
    end
end

if funcno == 4			% Tukey's biweight
    for i =1:n
        if abs(RES(i)) > param
            W(i) = 0;
        elseif RES(i) == 0
            W(i) = 1;
        else
            W(i) = (1-(RES(i)/param)^2)^2 ;
        end
    end
end

return
