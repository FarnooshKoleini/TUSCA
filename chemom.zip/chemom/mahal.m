function [d] = mahal(userv,k);
% MAHAL -- calculate Mahalanobis Distances of samples.
% Given v and k; where v is a matrix of column-wise variables and
% k is the number of columns to be used in the calculation.  The
% samples' distances from the centroid are returned in d.
% function [d] = mahal(v,k);
v=userv(:,1:k);
m=mean(v);
[r,c]=size(v);
t=ones(r,1);
m=t*m;
mv=v-m;
v=inv((mv' * mv)./(r-1));
d=(mv * v) .* mv;
d=sum(d')';
