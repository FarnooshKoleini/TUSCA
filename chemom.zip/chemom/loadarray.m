function [wave,abs,scans]=loadarray(filename,lower,upper);
% LOADARRAY -- loads NIR array from txt files
%
% [wave,abs,scans]=loadarray('filename',lower,upper);
%
% Filename should be the non-numeric base portion of the filename.
% It must be given in single quotes: 'filename'.

% Lower and upper are optional.  Lower defaults to 0 and upper defaults to 9999.
% If lower and upper are not specified then loadarray will start at 0 and read 
% sequential files to the end.
%
%%  Version 1.1 24Jan2002

if nargin==0,
   error(['Must specify at least a filename base IN SINGLE QUOTES(!).']);
end;

if nargin==1,
   lower=0;
   upper=9999;
end

if nargin==2,
	upper=9999;
end

if nargin==3,
   if upper<lower,
      error(['Upper value must be greater than lower value.']);
      end;
end;

num=lower;
abs=[];
while num<upper+1,
	fid=0;
	fid=fopen(sprintf('%s%d.txt',filename,num),'r');
   if fid == -1
      break
	end
   fclose(fid);
   abs=[abs,dlmread(sprintf('%s%d.txt',filename,num),'\t',0,1,[0 1 255 1])];
   num=num+1;
end
scans=(lower:num-1);
wave=dlmread(sprintf('%s%d.txt',filename,lower),'\t',0,0,[0 0 255 0]);

