function a=unscale(a,m,s);
% UNSCALE -- un-autoscale a matrix.
%
% a=unscale(a,m,s)
%
% a=scale(a,m,s);
% Where a is the matrix to be scaled and m and s are the mean
% and standard deviation vectors, repspectively.
%
[r,c]=size(a);

a = a .* s(ones(1,r),:) + m(ones(1,r),:);
