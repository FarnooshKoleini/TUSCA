%
% tdistribution -- script to compute a family of curves for the Student's t-distribution 
% at n=3 to 10.  The distribution curves are plotted.
clear x;
clear y;
x=-5:0.05:5;
x=x';
p = [2 3 5 30]
%for n=3:10;
for n=1:30;
y(:,n)=gamma((n+1)/2)./(sqrt(n*pi).*gamma(n/2).*(1+x.^2./n).^(n/2+1/2));
end;
plot(x,y);
