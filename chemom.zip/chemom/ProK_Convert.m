function [fname, pname] = prok_convert(sp,w,t);
% Function for converting MATLAB spectral data to an ASCII tab delimited
% file for ProK II
% 
% [fname, pname] = prok_convert(sp,w,t);

[fname, pname] = uiputfile('*.txt', 'Save matlab spectral data to ProK II format');
if isequal(fname,0) | isequal(pname,0)
   disp('Canceled.');
   return;
end;

fn = fullfile(pname, fname);


fid = fopen(fn,'w');
n_spec = length(t);  % get the number of spectra
n_lam = length(w); % get the number of wavelengths
fprintf(fid,'\t'); % write empty location
% write wavelengths
for i=1:n_lam
    fprintf(fid,'%f',w(i));
    fprintf(fid,'\t');
end
fprintf(fid,'\r\n');
% write times and data
for i=1:n_spec
    fprintf(fid,'%f',t(i)); % write time (converted to minutes to match HEL units)
    fprintf(fid,'\t');
    % write data
    for j=1:n_lam
        fprintf(fid,'%f',sp(i,j));
        fprintf(fid,'\t');
    end
    fprintf(fid,'\r\n');
end
fclose(fid);