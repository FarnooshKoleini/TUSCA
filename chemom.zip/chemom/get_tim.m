function [etime]=get_tim3(nm);
% GET_TIM -- Gets elapsed time in seconds from NSAS spl names. 
%            It does not give error after midnight, nnor in leap years.
%
% [etime]=get_tim(spl_name);
[r,c]=size(nm);                         % get the size of the nm matrix
t1=str2num(nm(:,12:13));			    % get hours
t2=str2num(nm(:,15:16));		      	% get minutes
t3=str2num(nm(:,18:19));		       	% get seconds
day=str2num(nm(:,24:25));               % get days
month=str2num(nm(:,21:22));             % get month
year=str2num(nm(:,27:30));              % get days
y=year(1);                              % Fix the year
m=month(1);                             % Fix the month
d=day(1);                               % Fix the day
time0=(3600*t1(1)) + (60*t2(1)) + t3(1);% Fix the time

yb=1972:4:2200;
yt=yb-y;
leap=99;
if any (yt==0),                         % If y is a leap-year, leap=0
    leap=0;
end;

m31=[1 3 5 7 8 10 12];
mt=m31-m;
month31=99;
if any (mt==0), 
        month31=0;                      % If m is a 31 days month, month31=0
end;
   
for i=1:r
    if (month(i)==m); 
           etime(i) = 3600*(t1(i)+24*(day(i)-d)) + (60*t2(i)) + t3(i)- time0;
       
   elseif ((month(i)~=m) & (month31==0));
       etime(i) = 3600*(t1(i)+24*(day(i)+31-d)) + (60*t2(i)) + t3(i)- time0;
       
   elseif ((month(i)~=m) & (month31~=0) & (m~=2));
       etime(i) = 3600*(t1(i)+24*(day(i)+30-d)) + (60*t2(i)) + t3(i)- time0;
       
   elseif ((month(i)~=m) & (m==2) & (leap~=0));
       etime(i) = 3600*(t1(i)+24*(day(i)+28-d)) + (60*t2(i)) + t3(i)- time0;
       
   elseif ((month(i)~=m) & (m==2) & (leap==0));
       etime(i) = 3600*(t1(i)+24*(day(i)+29-d)) + (60*t2(i)) + t3(i)- time0;
   end
end
etime=etime';
