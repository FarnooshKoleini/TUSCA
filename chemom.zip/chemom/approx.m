function [xapprox,iapprox]=approx(target,x);
% approx -- find approx value and indices of scalars 'target' in x.
%
% use:
%[xapprox,iapprox] = approx(target,x);
%
% copyright 2007, Paul J. Gemperline, East Carolina Universtiy, Greenville,
% NC

if nargin ~=2, error('approx -- Two input arguments required.'); end;

I = length(target);
xapprox(1:I)=zeros;
iapprox(1:I)=zeros;

for i = 1:I;
    [xapprox(i),iapprox(i)] = min(abs(x(:)-target(i)));
    xapprox(i) = target(i) - xapprox(i);
end;



