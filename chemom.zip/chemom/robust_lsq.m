function [COEF,FITS,RES,w] = robust(Y,X,funcno,param)
% ROBUST_LSQ - Robust regression using iteratively reweighted least squares
%
% Send:
%    y,x - Data for analysis with response in y
%    funcno - required weighting function (default = 1)
%        1. Huber's t function (default)
%        2. Ramsay's E function
%        3. Andrew's wave function
%        4. Tukey's biweight
%    param  - function parameter (default = 1)
%
%Returns:
%   COEF   - Coefficients for robust fits
%
% M J Chlond - Dec 94
% m.chlond@uclan.ac.uk
%
% [b,yhat,resid] = robust_lsq(y,x,funcno,param)
% 
% to visualize the robust regression try:
% plot(y,x,'o'); hold on; plot(yhat,x); hold off;

if nargin < 4, param = 1; end;
if nargin < 3, funcno = 1; end;

[n,m] = size(X);
W = ones(n,1);
maxc = 1;

[COEF,FITS,RES]=wgtls(Y,X,W);
scale = median(abs(RES-median(RES)))/.6745;

while maxc > .001
    PCOEF = COEF;
    w = wfunc(RES,funcno,param,scale);
    [COEF,FITS,RES]=wgtls(Y,X,w);
    maxc = max( abs(COEF-PCOEF) ./ abs(PCOEF) );
end

return
