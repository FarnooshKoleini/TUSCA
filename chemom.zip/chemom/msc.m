function [normx, avex, coef] = msc(x,ave)
%[normx,avex,coef] = msc(x,ave)
%
% MSC -- Multiple Scatter Correction routine Written by Bob Pranis, 3M 
% routine to perform MSC on the array (each row constitutes a spectrum)
% For the calibration set the form is  [normx,avex]=msc(x);
% Where   'x' is the original calibration set n samples (rows) by m variables (col)
%         'normx' is the returned normalized data set
%         'avex' is the average spectrum for all the calibration samples
% For the unknowns the form is   normx=msc(x,ave);
% Where   'x' and 'normx' are defined above and 'ave' is the same as 'avex'

if nargin==1								% Check if calibration
	ave=mean(x)';							% Yes, then average set
end
x=x';
[m,n]=size(x);
normx=zeros(m,n);						% Make matrix to hold normed data
coef=zeros(2,n);
for i=1:n										% For each sample
	xfit=[x(:,i),ones(m,1)];	
	coef(:,i)=xfit\ave;						% Regress against average
	normx(:,i)=xfit*coef(:,i);			% Norm values
end
normx=normx';
if nargout>1								% Check if calibration
	avex=ave;									% Yes, then return average spectrum also
end
