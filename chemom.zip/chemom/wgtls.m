function [COEF,FITS,RES] = wgtls(Y,X,W);
% WGTLS - Weighted least squares
%
% Send:
%	    Y  - Response variable
%	    X  - Predictor variables
%       W  - Weights
%
% Returns:
%       COEF - Coefficients for weighted least squares
%	    FITS - Fitted values
%	    RES  - Residuals
%
% M J Chlond - Dec 94
% m.chlond@uclan.ac.uk
%
%[COEF,FITS,RES] = wgtls(Y,X,W)

n = length(Y);
X = [ones(n,1) X];
W = diag(W);

COEF = inv(X'*W*X)*X'*W*Y;
FITS = X*COEF;
RES  = Y-FITS;

return
