function [p, Results] = nglm4(Fun, p, Options, varargin)
% NGLM4 - Optimizer based on Newton-Gauss Levenberg-Marquardt method

if nargin > 0
    argin   = 'varargin{1}';
    if nargin > 1
        for i = 2:length(varargin)
            argin = [argin, ',varargin{', num2str(i), '}'];
        end
    end
end

if isempty(Options)
    % *********************************************************************
    Options = optset();
    % *********************************************************************
end

ssq_old     = 1e50;
ssq_osc     = ssq_old;
mp          = Options.mp0;
mp_osc      = 0;
It          = 0;

while It <= Options.MaxIt
    
    % *********************************************************************
    [r0, ssq, df, C] = eval(strcat('Fun(p,', argin, ')'));
    % *********************************************************************
    
    % Calculation of the convergence criterion
    conv_crit = (ssq_old-ssq)/ssq_old;
    
    if Options.Display
        fprintf(1, 'It = %i/%i, ssq = %1.5e, conv = %1.5e, mp = %1.5e \n', It, Options.MaxIt, ssq, conv_crit, mp);
        for i = 1:length(p)
            fprintf(1, '\t p(%i) = %1.5e \n', i, p(i));
        end
    end
    
    % Calculation of sigR
    sigR      = sqrt(ssq/df);
    
    if abs(conv_crit) <= Options.Conv % Convergence criterion met
        if mp == 0
            % Convergence reached by Newton-Gauss method
            % Fill the structure 'Results'
            Results.df        = df;
            Results.Flag      = 'Converged';
            Results.H         = H;
            Results.It        = It;
            Results.mp        = mp;
            Results.p         = p;
            Results.sigp      = sigR*sqrt(diag(invH));
            Results.sigR      = sigR;
            Results.ssq       = ssq;
            break
        else
            % Convergence reached by Levenberg-Marquardt modification
            mp      = Options.mp0;
            r0_old  = r0;
            It      = It + 1;
            
            % Check for oscillations
            osc_conv = (ssq_osc-ssq)/ssq_osc;
            if abs(osc_conv) <= Options.Conv
                mp_osc = mp_osc + 1;
            else
                mp_osc = 0;
            end
            ssq_osc = ssq;
        end
        
    elseif conv_crit > Options.Conv % Convergence
        
        % Decrease Marquardt parameter (if needed)
        mp      = mp/Options.mp_dec;
        ssq_old = ssq;
        r0_old  = r0;
        It      = It + 1;
        
        % Calculation of the Jacobian
        J = zeros(length(r0), length(p));
        for i = 1:length(p)
            % Calculate shift for the i-th optimised parameter
            if p(i) == 0
                if length(Options.Deriv) >= i
                    Shift = Options.Deriv(i);
                else
                    Shift = Options.Deriv(1);
                end
            else
                if length(Options.Deriv) >= i
                    Shift = p(i)*Options.Deriv(i);
                else
                    Shift = p(i)*Options.Deriv(1);
                end
            end
            
            % Apply shift on the i-th optimised parameter
            p(i) = p(i) + Shift;
            
            % *************************************************************
            r = eval(strcat('Fun(p,', argin, ')'));
            % *************************************************************
            
            % Remove shift on the i-th optimised parameter
            p(i) = p(i) - Shift;
            
            % Calculate the i-th column of the Jacobian
            J(:, i) = (r - r0)/Shift;
        end

    elseif conv_crit < -Options.Conv % Divergence
        if mp == 0
            % Newton-Gauss method so far
            mp = Options.mp_div;
        else
            % Levenberg-Marquardt modification so far
            mp = mp*Options.mp_inc;
        end
        
        % Remove shift vector
        p = p - dp;
    end
    
    % Calculate the normalised Hessian
    % *********************************************************************
    H      = NormH(J'*J); % Local function
    % *********************************************************************
    
    % Calculate the inverted Hessian
    % *********************************************************************
    invH   = NormH(inv(H), J'*J); % Local function
    % *********************************************************************
    
    % Calculate the shift vector
    J_mp   = [J; mp*eye(length(p))];
    r0_mp  = [r0_old; zeros(length(p), 1)];
    dp     = -J_mp\r0_mp;
    
    % Check upper and lower bounds
    if ~isempty(Options.Bounds)
        bl     = logical(p + dp < Options.Bounds(:,1));
        bh     = logical(p + dp > Options.Bounds(:,2));
        dp(bl) = (Options.Bounds(bl, 1) - p(bl, 1))/2;
        dp(bh) = (Options.Bounds(bh, 2) - p(bh, 1))/2;
    end
    
    if mp_osc >= Options.mp_osc
        % Break because Convergence with oscillation around the minimum
        % Fill the structure 'Results'
        Results.df        = df;
        Results.Flag      = 'Converged with oscillations';
        Results.H         = H;
        Results.It        = It;
        Results.mp        = mp;
        Results.p         = p + dp;
        Results.sigp      = sigR*sqrt(diag(invH));
        Results.sigR      = sigR;
        Results.ssq       = ssq;
        break;
    end
    
    if It > Options.MaxIt
        % Break because maximum number of iterations reached
        % Fill the structure 'Results'
        Results.df        = df;
        Results.Flag      = 'Did not converge';
        Results.H         = H;
        Results.It        = It;
        Results.mp        = mp;
        Results.p         = p + dp;
        Results.sigp      = sigR*sqrt(diag(invH));
        Results.sigR      = sigR;
        Results.ssq       = ssq;
        break;
    end
    
    % Apply the shift vector
    p = p + dp;
end

% =========================================================================
function [nJtJ] = NormH(JtJ1, JtJ2)
% Written by Y.-M. Neuhold (Uni Basel), January 1997

nJtJ = [];
if nargin == 1
    n = size(JtJ1,1);
    for i = 1:n
        for j = 1:n
            nJtJ(i,j) = JtJ1(i,j) / sqrt(JtJ1(i,i) * JtJ1(j,j));
        end
    end
elseif nargin == 2
    n = size(JtJ1,1);
    for i = 1:n
        for j = 1:n
            nJtJ(i,j) = JtJ1(i,j) / sqrt(JtJ2(i,i) * JtJ2(j,j));
        end
    end
end