function [t] = t_crit(pr,df);
% T_CRIT -- Compute critical values of Student's t distribution, one-tailed.
% t = t_crit(pr,df);
%
% Where pr is the one-tailed probability & df is the degrees of freedom.

% COPYRIGHT, 1996.  Un-authorized use prohibited.
% Paul J. Gemperline
% Department of Chemistry
% East Carolina University
% Greenville, NC 27858
% 919-328-6767
% chgemper@ecuvax.cis.ecu.edu

fopts=optimset('TolX',1e-6,'Display','off');

str=sprintf('((1-%g)-t_dist(%g,x)).^2',pr,df);

if df == 1,
  t = fminbnd(str,1,70,fopts);
else
  t = fminbnd(str,1,10,fopts);
end;


