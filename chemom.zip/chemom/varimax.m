function [rot,simp,H2,T,angle] = varimax(raw);
%VARIMAX -- Performs Varimax rotation on a set of eigenvectors 
% (loadings): rot=raw*T with raw factors scaled by 
% Communalities. Convergence is reached when Simplicity no 
% longer increases.
%
%Use: 
%   [rot,simp,H2,T,angle] = varimaxr(raw);
%
%Input:
%   raw     Input set of eigenvectors to be rotated (NVars * NComps)
%
%Output:
%   rot     Output set of rotated eigenvectors
%   simp    Simplicity
%   H2      Communalities
%   T       The final rotation matrix
%   angle   Rotation angles for each p-q pair of factors
%
%       (c) 1991 Infometrix
%       Scott Ramos
%       Infometrix, Inc.
%       2200 Sixth, Suite 833, Seattle, WA 98121
%       Telephone: (206) 441-4696

% Based on the approach described in 'Modern Factor Analysis',
% by Harry H. Harman (Chicago:University of Chicago Press,1976)
% Ch. 13

% Procedures called:
% rad2deg

%       (c) 1991 Infometrix
%       Scott Ramos
%       Infometrix, Inc.
%       2200 Sixth, Suite 833, Seattle, WA 98121
%       Telephone: (206) 441-4696

%*************************************

[nvars,nc] = size(raw);
if nc<2,
        error('Input data must have at least 2 columns');
        break
end

%Initializations:
num = nc * (nc-1) / 2;  %number of pairings in a cycle
angle = zeros(num,1);

T = eye(nc);    %size of final transformation matrix
simp = 0;
done = 0;
count = 1;
tol = 0.01;

while ~done,
   count = count + 1;
   pairct = 0;

%Compute the communalities 'H2' (h-squared):
   H2 = sum(raw' .\2)';
   H = sqrt(H2);

%Note:
%Some applications use the 'factor loadings' instead of the eigenvectors as
% loadings as is used here. These are derived from:
%                       eigvec * sqrt(eigval)
% where the eigenvalues are obtaind from the covariance matrix, rather than
% from the data matrix as is done in this method (i.e., from the squares of
% the singular values from SVD).
%[shortcut scale factor when data are autoscaled:
%               (ev from SVD) / (numSam-1) = ev from EIG (of covariance matrix)]

%Normalize the loadings:
% [Future versions will substitute different forms of Varimax here]
   raw = raw ./ H(:,ones(1,nc));

%Loop through the possible pairs, p & q:
%  p = 1,2,...,m-1; q = p+1,p+2,...,m
   for p = 1:(nc-1),
      for q = (p+1):nc,
         pairct = pairct + 1;
         ap = raw(:,p);
         aq = raw(:,q);

%Store the intermediate terms:
         uj = ap .* ap - aq .* aq;
         vj = 2 * ap .* aq;
         A = sum(uj);
         B = sum(vj);
         C = sum(uj .* uj - vj .* vj);
         D = 2 * sum(uj .* vj);
         E = D - 2 * A * B / nvars;
         F = C - (A*A - B*B) / nvars;
         G = sqrt(E*E + F*F);

%Find the angle of rotation p:
         cos4p = F / G;
         cos2p = sqrt((1 + cos4p) / 2);
         cos_p = sqrt((1 + cos2p) / 2);
         sin_p = sqrt((1 - cos2p) / 2);
         if E<0,
            sin_p = -sin_p;
         end
         angle(pairct) = angle(pairct) + rad2deg(acos(cos_p));

%Calculate the transformation matrix:
         Tfor2 = [cos_p -sin_p;sin_p cos_p];
         temp = eye(nc); % Store in matrix of correct size
         temp([p q],[p q]) = Tfor2;
         T = T * temp;   %accumulate each result into the master matrix

%Rotate the two factors and update the working matrix 'raw':
         PairRot = [ap aq] * Tfor2;
         raw(:,[p q]) = PairRot;

      end     %for q
   end     %for p

%Compute the 'Simplicity':
   term1 = sum(raw .\4);
   term2 = sum(raw .\2) .\2;
   simp(count) = nvars * sum(term1') - sum(term2');

%Remove the normalization:
   raw = raw .* H(:,ones(1,nc));

%for j = 1:nvars,
%       raw(j,:) = raw(j,:) * H(j);
%end

%Check if necessary to repeat the iterations:
   if (simp(count)-simp(count-1) < tol) | (count>5),
      done = 1;
   end
end;    %while

simp = simp(2:count);
rot = raw;
H2 = sum(rot' .\2)';

