function z=bsln_asym_lsq(y,lambda,p,ix,interactive,f1,f2)
% bsln_asym_lsq -- estimate baseline using asymmetric least squares
%
% y:      Matrrix of spectra (in rows) to be smoothed
% lambda: lsq smoothness penalty (try 1E2 to 1E5)
% p:      asymmetric factor (try 1e-3 to 1e-9)
% ix:     valley locations. Baseline will be forced to fit these points
%
% optional interactive mode
% set interactive=1
% f1, f2:       handles to figures
%
% z=bsln_asym_lsq(y,lambda,p)
% or
% z=bsln_asym_lsq(y,lambda,p,1,f1,f2)  % interactive mode

[r,c]=size(y);
z=zeros(r,c);
D=diff(speye(c),2);
w=ones(c,1);
wold=zeros(c,1);

if nargin < 5,
    interactive = 0;
end;

for i = 1:r      % repeat for each row (spectrum) in y
    yy=y(i,:)';
    for it=1:10
        W=spdiags(w,0,c,c);
        C=chol(W+lambda*D'*D);
        zz=C\(C'\(w.*yy));
        w=p*(yy>zz)+(1-p)*(yy<zz);
        w(ix) = 1-p;
        if interactive == 1,
            figure(f1);plot(w,'--');
            hold on; plot(yy); plot(zz,'r'); hold off;
            figure(f2); hist(yy-zz,c/5);
            disp('Paused, hit <Enter> to resume');
            pause;
        end

        if sum(wold-w) == 0,
            break,5
        else
            wold=w;
        end
    end
    z(i,:)=zz';
end
