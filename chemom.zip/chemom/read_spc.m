function [wv,x]=read_spc(fname,n);
%READ_spc -- Read multiple Galactic *.spc files
%
% [wv,x]=read_spc(fname,n);
%           or
% [wv,x]=read_spc;
%
% Function to read sequentially numbered files from Galactic's GRAMS/32 *.spc 
% file format.  Files must be named in sequential order starting from 1
% with a root name of 4 characters.
%
% Example: acnn0001.spc, acnn0002.spc,...
%
% fname: root file name.
%     n: number of files.
%
% See also READ_SP for reading single files and LOADSPC for loading multi files

if nargin==0,
   [fname,pt]=uigetfile('*.spc','Select FIRST GRAMS/32 *.spc file');
   %  n = str2num(char(inputdlg('Enter num. files...')));
   n = 9999;
end;
fname = fname(1:length(fname)-10);

% initialize

i = 1;
fnm = sprintf('%s00000%g',fname,i);
fprintf(1,'Reading %s.\n',fnm);
fn = fullfile(pt,fnm);
[wv,y] =  read_sp(fn);

for i = 2:n
   if i < 10,
      fnm = sprintf('%s00000%g',fname,i);
   elseif i < 100,
      fnm = sprintf('%s0000%g',fname,i);
   elseif i < 1000,
      fnm = sprintf('%s000%g',fname,i);
   elseif i < 10000,
      fnm = sprintf('%s00%g',fname,i);
   else
      error('too many spectra');
   end;
   fn = fullfile(pt,fnm);
   if exist(strcat(fn,'.spc')) ~= 2,  
      break
   end
end;

n = i - 1;

% allocate storage
x = zeros(length(y),n);
x(:,1) = y;

for i = 2:n
   if i < 10,
      fnm = sprintf('%s00000%g',fname,i);
   elseif i < 100,
      fnm = sprintf('%s0000%g',fname,i);
   elseif i < 1000,
      fnm = sprintf('%s000%g',fname,i);
   elseif i < 10000,
      fnm = sprintf('%s00%g',fname,i);
   else
      error('too many spectra');
   end;
   fn = fullfile(pt,fnm);
   fprintf(1,'Reading %s.\n',fnm);
   [wv,x(:,i)] = read_sp(fn);
end;
x = x';
