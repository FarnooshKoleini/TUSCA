% ECU chemometrics toolbox
% 
% AUTOSCAL      Mean center and standardize columns of a matrix.
% BASCOR        baseline offset correction (non-interactive)
% BASE_POLY     Fit polynomial baseline corrections to data (non-interactive).
% BOOT_MLR      bootstrap step-wise variable selection for MLR
% BOOTSTRAP     script example showing bootstrap est. of the mean & std dev.
%
% CHI_CRIT      Compute critical values chi-squared-distribution
% CHIDIST       Plots curves for the chi-sq distr. at n=3 to 10 degrees of freedom.
% CHISQR        Calc prob. level for chi-squared distr.
% CHROMAT       generate a simulated k-component spectro-chromatogram data matrix
%
% DERIV         Smooth and take derivatives of columns (Identical to DERIVATIVE)
% DETSPL        sample selection for regression (maximize determinant)
%
% DIRL          list contents of a directory, one per line.
%
% EFA           evolving factor analysis w/ power method
% EFA_RE        evolving factor analysis, returns malinowski RE, not e'vals
% EFA_SCOR      compute k efa scores in forward direction
% EFA_SVD       evolving factor analysis
%
% ERFP          returns the area (e.g., prob) under the normal curve from 0 to x.
% F_CRIT        Compute critical values of Fisher's F-distribution
% F_DIST        probability of the F distribution.
% FDISTRIBUTION Scriipt roduces a family of curves for the F distribution 
% FFT_SPEC      calc fft of spectra (rows), all real coef.
% FIBONACCI     compute the Fibonacci sequence to k
% FIND_PK       find peak maxima in col vectors of c
% FISHER_WT     calc Fisher wts for cols of set_a and set_b w/ best discrim
% FIX_LAG       adjust a time-dependent measured profile for a first-order measurement lag
%
% GAUSSIAN      generate a gaussian distribution 
% GET_TIM       Gets elapsed time in seconds from NSAS spl names. 
%
% HHSPL         Honigs/Hieftje sample selection function for matrix D.
% HOT_T         Hotelling's T, prob that sample is different from training set.
%
% IFFT_SPEC     calc inverse fft of spectra (rows), all real coef.
% INTERP        Resample data at a higher rate using lowpass interpolation.
% KEEP          Keep workspace vars and clear rest.  Complement to "clear" command. 
% KMATRIX       K-matrix calibration.
%
% LOADMAT       set path and read MAT data files.
% LKB           plots a chromatogram for an lkb data set.  
% LOWESS        locally weighted regression scatterplot smoothing.
% LVGSPL        Highest leverage sample selection function for matrix D.
% LVGSPL2       Highest leverage sample selection function for matrix D.
%
% MAHAL         calculate Mahalanobis Distances of samples.
% MAHALCSV      Mahalnobis distances with leave-n-out cross validation.
% MAHALD        calculate the Mahalanobis Distances of samples. 
% MAJ_AXIS_REGR script demo of reduced major axis regression
% MALTEST       Malinowski's eigenvalue/error functions and F-test
% MAT2PIR       function to export matlab data to Pirrouette
% MEANCORR      mean correct columns of a matrix.
%
% MLR           MLR calibration, interactive var selection.
% MLR_CAL       MLR calibration, non-interactive.
% mlr_csv       MLR cross validation.
% MLR_DIAG      calc statistical diagnostics for MLR regression.
% MSC           Multiple Scatter Correction routine Written by Bob Pranis, 3M 
%
% MVE_ALL       Calc robust distances of k PCA scores by the projection method.
% MVE_TRN       Calc robust distance of trn & tst set by the proj. method w/ k PCA scores.
%
% NIPALS_Y      do NIPLS deflation of y w/ PLS model of X
% NORMALIZE     normalize columns of a data matrix
%
% OSCCALC       Calculates orthogonal signal correction
% PARAFAC2      Build PARAFAC model w/ small slab-wise deviations.
% PCR           pcr calibr. w/ train and optional test data.
% PCRF          pcr calibr. w/ train & opt. test data, non-interactive vers.
% PLSF          non-interactive vers. of PLSR.
% PLSR          PLS calibration.  Algorithm by Lorber, Wangen and Kowalski in
% PMATRIX       P-matrix calibration.
% POWER_PCA    calc a few e'vals and e'vects using power mtd (SVD is more accurate!)
%
% RAD2DEG       convert radians to degrees
% RE            Malinowski's RE using the first 12 factors.  
% RE_ANAL       calculates Malinowski's RE, REV and other stats
% RDPROJM       calc robust distances of rows in x by Rousseeuw's method
%
% READ_CDI      Read single or multiple CDI data files
% READ_CN       read NIR NSAS constituent files.
% READ_DA       read NIR NSAS data files.
% READ_FDA      read NIR NSAS data files.
% READ_FP       Read Galactic *.fsp file export format
% READ_FSP      Read multiple Galactic *.fsp files
% READ_HEL      Read HEL *.dat files
% READ_hm       Read Hamamatsu *.txt file format
% READ_LKB      reads a total absorbance chromatogram from lkb *.cat files.
% READ_LT       matlab function for reading ascii LT NIR files.
% READ_PRS_NAMES read PRS sample name data files.
% READ_SP       Read Galactic *.spc file format
% READ_spc      Read multiple Galactic *.spc files
% READ_JCAMP -- Function to read several variants of jcamp-dx files.  
% SPCLOAD       loads an SPC file or some portion thereof
%
% RE_ANAL       calculates Malinowski's RE, REV and other stats
% RESIDD        residual variance analysis of training & test sets
% REV           calculate Malinowski's reduced e'values & F-ratios
% ROBUST_LSQ    Robust regression using iteratively reweighted least squares
%
% SCALE         autoscale a matrix.
% SELECT_NFAC   Est. number of factors w/ robust LSQ fit of RE plots
% SMOOTH        smooth columns in a matrix using the 3-point binomial filter.  
% SORT_EIG      compute e'vals & e'vecs sorted in deceding order.
% STEP_MLR      step-wise variable selection for MLR
%
% SVD_INV       compute left or right pseudo inverse w/ svd and nfac factors.
% SVDT          trimmed SVD of matrix a.
% D_boot        svd_resid_boot(D,k,N);
%
% T_CRIT        Compute critical values of Student's t distribution, one-tailed.
% T_DIST        probability two sets of data are different.
% tdistribution script to compute a family of curves for the Student's t-distribution 
% TEST_FIB       checks property of Fibonacci triples
% TIMENUM       converts time of day strings to seconds past midnight
% TRIM          trim the results from the svd to k factors.
%
% UNSCALE       un-autoscale a matrix.
% VARIMAX       Performs Varimax rotation on a set of eigenvectors 
%
% WAITDLG       wait for dialog box h to be dismissed.
% WAVED         Calc max wavelength distance and probability.
% WFUNC         Weighting functions for robust regression
% WGTLS         Weighted least squares
% WVLGTH_SEL    select optimum pair of wvlns for MLR calibration and prediction.
