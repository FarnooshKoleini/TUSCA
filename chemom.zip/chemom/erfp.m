function pr=erfp(x);
% ERFP -- returns the area (e.g., prob) under the normal curve from 0 to x.
%
% pr=erfp(x);
pr=gamma(0.5,(x.^2)/2);
