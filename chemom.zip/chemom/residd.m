function [d,pr,r_tst,so,idx] = residd(uv,uvt,k,sort_opt);
% RESIDD - residual variance analysis of training & test sets
%
% [d,pr,idx] = residd(v,vt,k,sort_opt);
%
% Function to calculate the residual variance distance of samples, given v 
% where v is a matrix of column-wise variables.  The training set, v, is 
% used to estimate distances for the test set, vt.
%
% sort_opt=1 returns the distances sorted from low to high.  The variable 
% k specifies that k principal component scores are to be used.
%
% The samples' residual distances are returned in d.  The 
% probability density (F-distribution) for the distance is given in pr.
% The original sample number is given in idx.

[r,c]=size(uv);
[rt,ct]=size(uvt);

if r == rt,
    if all(uv==uvt),
        train_set=1;
    else
        train_set=0;
    end;
else
    train_set = 0;
end;

[uv,m]=meancorr(uv);		% always use meancorrected data
uvt=uvt-m(ones(1,rt),:);

if nargin ~= 4
  error('4 input variables required.');
end;

[uu,ss,vv]=svd(uv);
[uu,ss,vv]=trim(k,uu,ss,vv);
ut=uvt*vv*inv(ss);

r_trn = uv - uu * ss * vv';		% calc train set resid variance.
df = 1 ./ (c * (1 - (k/r) - (1/r)));
r_trn = (sum(r_trn'.^2) * df)';
so = sum(r_trn)/r;

if train_set
  r_tst = r_trn;
else
  r_tst = uvt - ut * ss * vv';		% calc test set resid variance.
  r_tst = (sum(r_tst'.^2)./c)';
end;

d_sqr = r_tst ./ so;			% calc distances.
d = sqrt(d_sqr);

if sort_opt == 1 			% sort 'em
  [d,idx] = sort(d);
end;

pr=zeros(size(d));

pr = 1 - f_dist(1,r-k-1,d);

