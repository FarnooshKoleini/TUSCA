function [dist]=maj_axis_fun(b);
% MAJ_AXIS_FUN -- subroutine loss function for major axis regression
global xdata ydata xaug yaug
dist=sum((ydata-xaug*b).^2/(1 + b(2).^2));
