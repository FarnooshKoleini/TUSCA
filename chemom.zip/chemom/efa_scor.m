function [uefa]=efa_scor(a,k);
% EFA_SCOR -- compute k efa scores in forward direction
% [uefa]=efa_scor(a,k);

[n,m]=size(a);
uefa=zeros(n,k);

[u,s,v]=svdt(k,a(1:k,:));

% test sign of max elements in v, swap sign if needed.
vold=v;

uefa(1:k,:)=u(1:k,:)*s;

for i=k+1:n
   [u s v]=svdt(k,a(1:i,:));
   % test sign of max elements in v, swap sign if needed.
   idx=find(sum(vold.*v) < 0);
   v(:,idx)=-v(:,idx);
   vold = v;
   u(:,idx)=-u(:,idx);
   uefa(i,:)=u(i,:)*s;
   fprintf(1,'.');
end;
fprintf(1,'\n');