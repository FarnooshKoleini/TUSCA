function [prob]=chisqr(x,df);
% CHISQR - Calc prob. level for chi-squared distr.
%
% [prob]=chisqr(x,df);
%
% Function to calculate the probability level for the chi-squared
% distribution:  [Prob]=chisqr(x,df) where prob is the probability
% level, x is the value of chisquared and df is the degrees of freedom..

% prob=gamma(df/2,x/2);
prob=gammainc(x/2,df/2);
