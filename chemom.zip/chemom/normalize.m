function [y]=normalize(a);
% NORMALIZE -- normalize columns of a data matrix
%
%[y]=normalize(a)
n=sqrt(sum(a.^2));
[r,c]=size(a);
y=a ./ n(ones(1,r),:);
