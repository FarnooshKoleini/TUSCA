function [y]=derv(x,r,c);
% DERV - subroutine for smoothed derivatives.  See DERIVATIVE or DERIV
  y = zeros(r,c);
  y(2:r-1,:) = (x(3:r,:) - x(1:r-2,:))*0.5;    % calc centered differences
  y(1,:) = x(2,:) - x(1,:);         % calc fwd diff for the left edge
  y(r,:) = x(r,:) - x(r-1,:);       % calc rev diff for the right edge
