function [chat,ctesthat,SEC,SEP,ix,b]=mlr(a1,c1,a2,c2,intercept,wv,ix);
% MLR -- MLR calibration, interactive var selection.
%
% a1, a2:    calibration spectra and test spectra respectively in rows.
% c1 & c2:   cal and test concentration data respectively in rows.
% intercept: 1/0, include non-zero intercept in model.
% wv:        plotting index for spectra (optional)
% ix:        columns of vars to use in mlr (optional, if missing
%            mouse clicks used to select vars).
%
% c1p, c2p:  predicted concentrations.
% SEC, SEP:  figures of merit for cal & test set respectively.
% ix:        vars selected w/ mouse clicks.
%
% For the final model, the matrix b  contains the MLR regression 
% coefficients for the model:  cp=a(:,ix)*b.
%
% See also: MLR MLR_CAL  STEP_MLR  MLR_DIAG  BOOT_MLR
%
% [c1p,c2p,SEC,SEP,ix,b]=mlr(a1,c1,a2,c2,intercept,wv,ix);

if nargin < 5,
    error ('MLR - Wrong number of parameters.');
end
echo on

if isempty(c2), sep_flag = 0; else sep_flag = 1; end;
if isempty(a2), tst_flag = 0; else tst_flag = 1; end;

%
% get wavelengths
%
[ar,ac] = size(a1);
if nargin < 6,
    wv=1:ac;
end;

repeat = 1;
while repeat ==1,
    
    if nargin < 7,
        plot(wv,a1);  
        disp('Select wavelengths with mouse clicks.'); 
        disp('Hit RETURN to end.')
        [ix,iy]=ginput;
        nfac=length(ix);
        for i=1:nfac
            [w,ix(i)]=min(abs(wv-ix(i)));
        end;
        iy = iy';
    else
        nfac=length(ix);
    end;
    
    disp(' ')
    disp('   Selected wavelengths')
    disp('    wvln        index')
    disp('============ ============ ')
    for i=1:nfac
        iy(i)=wv(ix(i));
        disp(sprintf('%9.2f    %7.0f',iy(i),ix(i)));
    end;
    
    a=a1(:,ix);
    atest=a2(:,ix);
    c=c1;
    ctest=c2;
    
    [ar,ac]=size(a);
    [art,act]=size(atest);
    [cr,ncomp]=size(c);
    
    %
    % Augment a and atest w/ column of ones if non-zero intercept requested.
    %
    if intercept == 1, 
        a = [ones(ar,1) a];
        atest = [ones(art,1) atest];
        iy = [0 iy];
        nfac = nfac + 1;
    end
    
    %
    % Calculate b, SEC, SEP 
    %
    SEC=zeros(1,ncomp);
    SEP=zeros(1,ncomp);
    
    b=a\c;
    chat = a * b;
    df = ar - nfac;
    
    if df == 0,
        SEC=zeros(1,ncomp);
    else
        SEC = sqrt(sum((c - chat).^2) / df);
    end
    
    ctesthat = atest * b;
    if sep_flag == 1,
        SEP=sqrt(sum((ctest - ctesthat).^2) / art);
    else
        SEP(1:length(SEC))=nan;
    end;
    
    for j = 1:ncomp
        disp(' ');
        disp(sprintf('  Regression coefficients for constituent %g.',j));
        disp('    wvln           b')
        disp('============ ============ ')
        for i=1:nfac
            disp(sprintf('%9.2f    %12g',iy(i),b(i,j)));
        end;
    end;
    
    %
    % Dump relative error
    %
    disp(' ');
    disp('Constit.     SEC        SEP');
    disp('========  =========  =========');
    for i = 1:ncomp
        disp(sprintf('%4g      %9.3d  %9.3d',i,SEC(i),SEP(i)));
    end;
    
    disp(' ')
    if nargin == 7, 
        repeat = 0;
    else
        repeat=input('Try again (1=yes/0=no) [1]: ');
        if isempty(repeat), repeat=1; end;
    end; 
end;

%
%  Plot calibration curves
%
for i = 1:ncomp
    if sep_flag == 1,
        figure(1);
        plot(c(:,i),chat(:,i),'x',ctest(:,i),ctesthat(:,i),'o'); 
    else
        figure(2); plot(ctesthat(:,i),'x');
        figure(1); plot(c(:,i),chat(:,i),'x'); 
    end;
    title(sprintf('Results for component %g.  (x) calibr. (o) test.',i));
    ylabel('Estimated concentration');
    xlabel('Actual concentration');
    pause;
end
%
%  Plot component residuals
%
for j=1:ncomp
    if sep_flag == 1,
        plot(chat(:,j),c(:,j)-chat(:,j),'x',ctesthat(:,j),ctest(:,j)-ctesthat(:,j),'o');
    else
        plot(chat(:,j),c(:,j)-chat(:,j),'x');
    end
    title(sprintf('Plot of residuals for component %g.  (x) calibr. (o) test.',j));
    xlabel(sprintf('Predicted concentration of component %g',j));
    ylabel(sprintf('Residuals for component %g',j));
    pause;
end
