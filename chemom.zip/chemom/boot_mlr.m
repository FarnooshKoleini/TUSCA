function [boot,vars] = boot_mlr(x,y,pr_ent,pr_del,N,f);
% BOOT_MLR -- bootstrap step-wise variable selection for MLR
%
% N random calibration subsets of size f (fraction) are used to 
% determine the best x vars for mlr calibraiton of y.
% The random subsets are returned to the pool of samples before 
% the new subset is selected.
%
% INPUTS:
%      x: predictors (n x m)
%      y: predicted variable (n x 1)
% pr_del: prob. level for variable deletion steps (0.05 = default)
% pr_ent: prob. level for variable addition steps (0.01 = default)
%      N: number of bootstrap trials. (default = 10)
%      f: fraction of samples to be used for a subset (default = 0.5)
%   Note: For convergence, pr_del > pr_ent
%
% OUTPUTS:
%     boot(i): sorted regressions, best first
% boot(i).ssr: sum of squared residuals for ith bootstrap regression
% boot(i).idx: list of variables selected for ith bootstrap regression
%    var(:,1): list of vars
%    var(:,2): frequency of occurance
%    var(:,3): frequency of occurance w/ neighbors
% 
% See also: MLR MLR_CAL  STEP_MLR  MLR_DIAG  BOOT_MLR
%
% [boot,vars] = boot_mlr(x,y,pr_ent,pr_del,N,f);

% -- error checking --
if nargin < 6,
	f = 0.5;
end;
if nargin < 5,
	N = 10;
end;
if nargin < 4,
	pr_del = 0.05;
end;
if nargin < 3,
	pr_ent = 0.01;
end;

[nx,mx]=size(x);
[ny,my]=size(y);

if nx ~= ny,
	error('BOOTSTRAP_MLR: x and y must have same number of rows.');
end;
if my ~= 1,
	error('BOOTSTRAP_MLR: y must have one column.');
end;
if ny < 2,
	error('BOOTSTRAP_MLR: y must have more than 2 rows.');
end;

% -- Initialization --

nboot = round(ny*f);	% calc integer size of bootstrap sample

% -- main loop --

for i=1:N;							% main loop
	r=rand(ny,1); [r,ix]=sort(r);	% get rand vector
	ix = ix(1:nboot);					
	fprintf('\n\nBootstrap sample %g.',i);
	[boot(i).idx,boot(i).ssr] = step_mlr(x(ix,:),y(ix));
end;

% -- sort & print regressions --

ssr_all = cat(1,boot.ssr);			% get selected vars in one big vector
[ssr_all, best] = sort(ssr_all);	% sort regressions in best order
boot(1:N) = boot(best);				% re-order

fprintf('\n\nSorted regressions, best to worst.');
fprintf('\n   SSR            selected variables (0=intercept)');
for i = 1:N							% print 'em
	fprintf('\n%10g        0  ',boot(i).ssr); 
	fprintf('%g ',boot(i).idx);
end

% -- tabulate numer times a variable is used --

ix = cat(2,boot.idx);
iu = unique(ix);
iu = sort(iu);
for i = 1:length(iu);
	n_iu(i) = sum(iu(i)==ix);
end;

vars = zeros(mx,3);
vars(:,1) = (1:mx)';	% record the vars
vars(iu,2) = n_iu';		% record the count
fprintf('\n\nVar  Times used\n===  ==========');
fprintf('\n%3g      %g',vars(iu,1:2)');
fprintf('\n');

% tabulate number of times vars and neighbor vars are used

for i = 2:mx-1
	vars(i,3) = sum(vars(i-1:i+1,2));
end
vars(1,3) = sum(vars(1:2,2));		% sum endpoints differently
vars(end,3) = sum(vars(end-1:end,2));		% sum endpoints differently
fprintf('\n\nVar  Neighbors used\n===  =============');
fprintf('\n%3g      %g',vars(iu,[1 3])');
fprintf('\n');

bar(vars(:,2:3));
legend('Var','With neighbors');
ylabel('Num. times var used.'); xlabel('Variable number');
