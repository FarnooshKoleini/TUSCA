function ss=ssq(x);
ss = sum(sum(x.^2));
