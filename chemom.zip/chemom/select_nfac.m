function k=select_nfac(x);
% SELECT_NFAC - Est. number of factors w/ robust LSQ fit of RE plots
%
% k=select_nfac(x);

% [f,err] = rev(x);
err = re(x);
logre = log10(err);
n = length(err);

[b,yhat,r,w] = robust_lsq(logre,(1:n)',4,1); % use Tukey's robust bisquare regr.
semilogy(err,'o'); hold on; 			% plot the robust regr. results
semilogy(10.^yhat,'r-');
ylabel('Malinowski''s RE')
xlabel('Number of factors')

idx = find(logre > yhat);				% get list of values GT robust estimate
k = find(idx(2:end)-idx(1:end-1) >1);   % last in list is taken to be nfactors
k=k(1);
semilogy(err(idx(1:k)),'ro'); 	% and plot 'em
hold off;
