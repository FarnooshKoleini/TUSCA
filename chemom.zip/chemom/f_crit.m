function [f] = f_crit(pr,df1,df2);
% F_CRIT -- Compute critical values of Fisher's F-distribution
% f = f_crit(pr,df1,df2);
%
% Where pr is the one-tailed probability & df1, df2 are the degrees of freedom.

% COPYRIGHT, 1996.  Un-authorized use prohibited.
% Paul J. Gemperline
% Department of Chemistry
% East Carolina University
% Greenville, NC 27858
% 919-328-6767
% chgemper@ecuvax.cis.ecu.edu

fopts(2)=1e-4;
fopts(3)=1e-4;

str=sprintf('((1-%g)-f_dist(%g,%g,sqrt(x))).^2',pr,df1,df2);

% if df2 == 1,
%   f = fmin(str,1,10000,fopts);
% elseif df2 == 2,
%   f = fmin(str,1,100,fopts);
% else
%   f = fmin(str,1,28,fopts);
% end;
 


if df2 == 1,
  f = fminbnd(str,1,10000);
elseif df2 == 2,
  f = fminbnd(str,1,100);
else
  f = fminbnd(str,1,28);
end;
 

