function [wvln_idx,sep,sec,secc2,sepp2]=wvlgth_sel(acal,ccal,atst,ctst,w)
% WVLGTH_SEL -- select optimum pair of wvlns for MLR calibration and prediction.
% 
%>inputs
% acal:      set of calibration spectra.
% ccal:      set of calibration concentrations.
% atst:      set of test spectra.
% ctst:      set of test concentrations.
% w:         wavelengths (for plotting)
%
%>outputs
% wvln_idx:  The wavelengths selected.  
% sec:       sec value for selected wavlengths.
% sep:       sep value for selected wavlengths. 
% secc2:     matrix containing all sec's generated.
% sepp2:     matrix containing all sep's generated.
%
%[wvln_idx,sep,sec,secc2,sepp2]=wvlgth_sel3(acal,ccal,atst,ctst,w);
 
nz=1
[xw,yw]=size(w);
[xacal,yacal]=size(acal);
[xccal,yccal]=size(ccal);
a=[acal;atst];
c=[ccal;ctst];
[sa,sa2]=size(a);
[sc,sc2]=size(c);
wv1=[1:yw];
wv2=[1:yw];
[gn1]=length(wv1);
[gn2]=length(wv2);
sepp=zeros(1,4);
sep2=[];

% test every possible combination using the whole wavelength range.

for j=1:gn1-1,
   for i=j+1:gn2,
         wv_idx = [wv1(1,j) wv2(1,i)];
         k = length(wv_idx);
         x = [ones(xacal,1) acal(:,wv_idx)];

         % For component one:
         b_hat_w = [ones(xacal,1) acal(:,wv_idx)] \ ccal(:,1);
         
         % Estimate the concentration of all samples:
         % For component one:
         c_hat_w = [ones(sa,1) a(:,wv_idx)] * b_hat_w;
         % Calculate the concentration residuals for component one:
         c_err_w = c_hat_w - c(:,1);
         % Calculate the standard error of calibration and prediction.
         sec_w = sqrt(sum(c_err_w([1:xccal],1).^2)/(xccal-k-1));
         % Calculate the standard error of prediction.
         sep_w = sqrt(sum(c_err_w([xccal+1:end],1).^2)/(sc-xccal));
         % collect all the sec, sep
         secc2(j,i)=sec_w;
         sepp2(j,i)=sep_w;
         sepp(i,:)=[j i sec_w sep_w];
   end;
   secp=(sepp(:,4).^2 + sepp(:,3).^2);
   [yy,bb]=min(secp);
   sep2=[sep2;sepp(bb,:)];
   nz=nz+1 
end;

% take summary of sec and sep, find the optimum wavelength according to the smallest value

% enlarge the difference by taking the square
seccp=(sep2(:,4).^2 + sep2(:,3).^2);
[yy,bb]=min(seccp);
secp2=[sep2(bb,:)];

wvln_idx = [secp2(:,1) secp2(:,2)];

% using the optimum wavelength to compute the calibration
x = [ones(xacal,1) acal(:,wvln_idx)];
b_hat_w = [ones(xacal,1) acal(:,wvln_idx)] \ ccal(:,1);
c_hat_w = [ones(sa,1) a(:,wvln_idx)] * b_hat_w;
c_err_w = c_hat_w - c(:,1);
sec= sqrt(sum(c_err_w([1:xccal],1).^2)/(xccal-k-1));
sep= sqrt(sum(c_err_w([xccal+1:end],1).^2)/(sc-xccal));


