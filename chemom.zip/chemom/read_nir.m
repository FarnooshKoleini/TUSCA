function [wv,x]=read_nir;
%READ_spc -- Read multiple Galactic *.spc files
%
% [wv,x]=read_spc;
%
% Function to read sequentially numbered NIR spetral files in *.txt 
% file format.  Files must be named in sequential order starting from 1
% with a root name of 4 characters.
%
% Example: dmap1.txt, dmap2.txt,...
%
% rootname: root file name.
%        n: number of files.
%

[fname,pt] = uigetfile('*.txt','Select FIRST NIR *.txt file'); % dialog box to select file
if isequal(fname,0)|isequal(pt,0)
   disp('File not found');
   wv=[];x=[]; return;
end;

fprintf(1,'Reading %s.\n',fname);
[wv,y] = read_txt(fullfile(pt,fname));    % read the first file.
[dummy,fname,ext] = fileparts(fname);     % get name and extension
fname = fname(1:end-1);                   % get the root name

% count the files in the data set

for i=1:9999  
   fnm = sprintf('%s%g%s',fname,i,ext);   % generate next file name in series
   fn = fullfile(pt,fnm);
   if exist(fn) ~= 2,                     % does it exist?
      break
   end;
end; 
n = i - 1;                                % n is number of files to read

% allocate storage

x = zeros(length(y),n);
x(:,1) = y;

for i = 2:n
   fnm = sprintf('%s%g%s',fname,i,ext);   % generate next file name in series
   fprintf(1,'Reading %s.\n',fnm);
   fn = fullfile(pt,fnm);
   [wv,x(:,i)] =  read_txt(fn);
end;
x = x';

%
% private function
function [wv,y] = read_txt(fn);
x = load(fn);
wv = x(:,1);
y = x(:,2);