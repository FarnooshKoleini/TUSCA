function [x,d,stp_idx,y]=read_HEL(hfn,lfn);
% read_HEL -- read HEL data files.
%
%  [x,d,stp_idx,y]=read_HEL('HEL filename.dat','log filename.txt');
%        or
%  [x,d,stp_idx,y]=read_HEL;
%
%  log file name is needed to sync Intelliform data with HEL data. Skip otherwise.
%
%  x is a structured variable w/ stepwise data
%  d is the whole data array
%  stp_idx is the location of new steps
%  y is structured variable w/ intelliform data

%  Copyright Paul J. Gemperline, 2001
%  gemperlinep@mail.ecu.edu

true = 1;
false = 0;
x.nsteps = 0;
read_step = false;
read_data = false;

%
% open HEL file for reading
%
if nargin == 0,
   [hfn,pt] = uigetfile('*.dat','Select HEL *.dat file');
   if hfn == 0,
       return;
   end;
   hfn = fullfile(pt,hfn);
end
inp=fopen(hfn,'rt');  % open for read-only access, text mode

%
% open Log file for reading
%
skip_log = false;
if nargin < 2,
   [lfn,pt] = uigetfile('*.txt','Select HEL log *.txt file or <enter> to skip.');
   if lfn == 0,
       skip_log = true;
   else
       lfn = fullfile(pt,lfn);
   end;
end;

if skip_log == false;
    linp=fopen(lfn,'rt');  % open for read-only access, text mode
    ln = fgetl(linp);
    idx = findstr(ln,' ');   % parse time
    x.file_time = ln(idx(1)+1:idx(3)-1);
    x.start_time = timenum(x.file_time);
 else
    x.file_time = 0;
    x.start_time = 0;
end;

%
% read header and get file description
%
for i=1:11  % read header
    l(i) = {fgetl(inp)};
end;
%
% parse date and time
%
s=char(l(4));
x.file_date = datenum(s(8:12));

idx = findstr(s,'Time : ')+7;
s=s(idx:end);
x.stop_time = timenum(s);
x.file_descr = [char(l(2)) '   Time : ',x.file_time,' to ' s];

%
% read one line at a time, watch for step start/stop
%
while ~feof(inp),
    l = fgetl(inp);
    %
    % start reading next step
    %
    if ~isempty(findstr(l,'Step Name')) | ~isempty(findstr(l,'Time (mins)|')),
       read_step = true;
       x.nsteps = x.nsteps + 1;
       st = x.nsteps;
       x.step(st).name = l(16:end);
%
% if there are not multiple steps, then process header line early
%
       if ~isempty(findstr(l,'Time (mins)|')),
          x.step(st).name = 'None';
          read_data = true;
          row = 0;
          idx=[0 findstr(l,'|') length(l)];
          x.ncols = length(idx)-2;
          for j = 1:x.ncols;
             x.col_label(j) = {l(idx(j)+1:idx(j+1)-1)};
          end;
       end;
       
    end;
    %
    % start reading data block of next step
    %
    while read_step == true,
        while read_data == false,
            l = fgetl(inp);
            if ~isempty(findstr(l,'Time (mins)|')),
                read_data = true;
                row = 0;
                idx=[0 findstr(l,'|') length(l)];
                x.ncols = length(idx)-2;
                for j = 1:x.ncols;
                    x.col_label(j) = {l(idx(j)+1:idx(j+1)-1)};
                end;
            end;
        end;
        %
        % read data rows
        %
        while read_data == true
           
            y = fscanf(inp,'%g',x.ncols);
            if ~isempty(y),
                row = row + 1;
                x.step(st).dat(row,:) = y;
            else
                read_data = false;
                read_step = false;
            end;
        end;
    end;
end;
fclose(inp);

d = [];
stp_idx(1) = 1;
for i = 1:x.nsteps
    d = [d; x.step(i).dat];
    [r,c] = size(d);
    stp_idx(i+1) = r+1;
end;

% adjust inteliform time and HEL time
[fn,pt] = uigetfile('*.mat','Select intelliFORM export *.mat file');
if fn == 0,
   y=[];
   return;
end;
fn = fullfile(pt,fn);
y = load(fn);  % read the file

%
% test to make sure the intelliform export was specified.
%
if ~isfield(y,'currtime')
    warning('CALORIM_MATCH -- %s is not an exported intelliFORM file.',fn)
    return
end;
if ~isfield(y,'cp')
    warning('CALORIM_MATCH -- %s does not contain CP results.',fn)
    return
end;

dt = (timenum(y.szstarttime) - x.start_time)/60;    % calc time diff between HEL and I-FORM
d(:,1) = d(:,1) - dt;

%make overlay plots
figure(2);
[ax,h1,h2]=plotyy(d(:,1),d(:,2:3),d(:,1),d(:,4));
ylabel('Temperature, ^oC');
h=get(ax(2),'ylabel');
set(h,'string','Power');
title(x.file_descr);
xlabel(x.col_label(1));
h=get(ax(1),'ylabel');
