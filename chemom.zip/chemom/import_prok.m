function [k,,E,dH,t,c,wv,sp,c_calc] = import_prok;
% import_prok -- read prok result file into matlab
%
% [t,c,wv,sp,c_calc] = import_prok;
%

if nargin==0,
   [fn,pt]=uigetfile('*.txt','Select ProK result file');
   fn = fullfile(pt,fn);
end
inp=fopen(fn,'r');

% read file one line at a time, look num files
s = fgetl(inp);
while isempty(findstr(s,'Number of Data Files:'));
    s = fgetl(inp);
end;
nf = sscanf(s,'%f');

for i = 1:nf
% read file one line at a time, look for header lines
s = fgetl(inp);
while isempty(findstr(s,'Time\Species'));
    s = fgetl(inp);
end;

% read file, look for conc profile
s = fgetl(inp);
i=1;
while length(s) > 10,
    x=sscanf(s,'%f');
    t(i)=x(1); c(i,:)=x(2:end)';
    s = fgetl(inp);
    i=i+1;
end;

% read file one line at a time, look for header lines
s = fgetl(inp);
while isempty(findstr(s,'Species\Lambda'));
    s = fgetl(inp);
end;
[x,z,z,nx]=sscanf(s,'%s',1); wv=sscanf(s(nx:end),'%f');

% read file, look for spectral profile
s = fgetl(inp);
i=1;
while length(s) > 10,
    [x,z,z,nx] = sscanf(s,'%s',1); sp(i,:) = sscanf(s(nx:end),'%f')';
    s = fgetl(inp);
    i=i+1;
end;
