function [prob] = hot_t(p,n,d);
% HOT_T -- Hotelling's T, prob that sample is different from training set.
%
% [prob] = hot_t(p,n,d);
%
% A T^2 probability that the data is different from the training set.
% The test is based on d^2 where d is the Mahalanobis distance.  The
% number of factors is given by p; and the number of training samples
% is given by n.
%

% COPYRIGHT, 1994.  Un-authorized use prohibited.
% Written by Nichole Boyer on 12/19/93.
% Department of Chemistry
% East Carolina University
% Greenville, NC 27858
% 919-757-6767

x2=[(d.^2).*(n-p)]./[(n-1)*p];
x=sqrt(x2);
[prob]=f_dist(p,n-p,x);
