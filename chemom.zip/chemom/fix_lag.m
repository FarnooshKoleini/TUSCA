function Yest = fix_lag(Ymeas,dt,tau);
% FIX_LAG -- adjust a time-dependent measured profile for a first-order measurement lag
%
% Ymeas  measured profile at equally spaced intervals
% dt     measurement time interval
% tau    lag time constant, i.e., the time needed to reach 68.2% of measured value
%
% Yest = fix_lag(Ymeas,dt,tau); 
% 

dY_dt = gradient(Ymeas,dt);  % could also use savgol(Ymeas,3,2,1)./dt, numerically identical

Yest = tau* dY_dt + Ymeas;