function [y,b]=bascor(x,start,stop);
% BASCOR -- baseline offset correction (non-interactive)
% [y,b]=bascor(x,start,stop);
%
% x = matrix that you wish to correct;
% start = index of wavelength to begin
% stop = index of wavelength to end
%
% y = matrix of corrected spectra
% b = vector of row means of the selected range
% see BASLNCOR for interactive version.

b=mean(x(:,start:stop)')';
[r,col]=size(x);
y = x - b(:,ones(col,1));
