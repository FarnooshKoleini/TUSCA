function sub_a=lkb(t,w,a);
% LKB -- plots a chromatogram for an lkb data set.  
% The user can expand portions of it using the mouse.  Spectra in a sub_range can
% be plotted.
% 
% Two clicks on the mouse defines the subset range for plotting.
%
% Typing 'ss', 'cc' or 'mm' in a subrange cause the spectra to be plotted.
% 'cc' gives a contour plot.  'mm' gives a mesh plot.
%
% A double click resets the plot.
%
% The ENTER or RETURN key terminates the function and returns the selected
% sub-matrix in the optional output variable sub_a.
%
%  sub_a=lkb(t,w,a);

disp('Click desired end points of chromatogram to expand plot.');
disp('Type <ss> to mark range of spectra in sub-matrix.');
disp('Type <mm> to mark range of spectra for mesh plot.');
disp('Type <cc> to mark range of spectra for contour plot.');
disp('Double click mouse to reset plot.');
disp('Hit ENTER or RETURN to end.');

if nargin ~= 3,
  error('Not enough input arguments.');
end;

figure(1);
c=sum(a');
plot(t,c);

[x,y,key]=ginput(2);

while (length(x)==2),

  if (key(1)==13 | key(2)==13),				% if return key
    return;
  end;

  [z,ix(1)]=min(abs(t-x(1)));				% get index
  [z,ix(2)]=min(abs(t-x(2)));
  if ix(1) > ix(2),
    temp=ix(2);
    ix(2)=ix(1);
    ix(1)=temp;
  end;

  sub_a=a(ix(1):ix(2),:);
  disp(sprintf('Start = %5.2f.  Time = %g.  Total abs = %g',ix(1),t(ix(1)),c(ix(1))));
  disp(sprintf(' Stop = %5.2f.  Time = %g.  Total abs = %g',ix(2),t(ix(2)),c(ix(2))));

  if (key(1)==1 & key(2)==1), 				% plot chromatogram
    if ix(1) == ix(2),
      plot(t,c);
    else
      plot(t(ix(1):ix(2)),c(ix(1):ix(2)));
    end;
    ylabel('Absorbance');
    xlabel('Time(s)');
  end;

  if (key(1)==115 | key(2)==115), 			% plot spectra
    figure(2);
    plot(w,a(ix(1):ix(2),:),'-');
    ylabel('Absorbance');
    xlabel('Wavength (nm)');
    figure(1);
  end;

  if (key(1)==109 | key(2)==109),  			% plot mesh
    figure(2);
    mesh(w,t(ix(1):ix(2)),a(ix(1):ix(2),:));
    xlabel('Wavelength (nm)');
    ylabel('Time (s)');
    figure(1);
  end;

  if (key(1)==99 | key(2)==99),  			% plot contour
    figure(2);
    contour(w,t(ix(1):ix(2)),a(ix(1):ix(2),:),20);
    xlabel('Wavelength (nm)');
    ylabel('Time (s)');
    figure(1);
  end;

  figure(1);
  [x,y,key]=ginput(2);
end;
