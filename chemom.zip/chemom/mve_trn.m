function [rd1,pr1,rd2,pr2] = mve_trn3(xtr,xts,k,cut);
% MVE_TRN   Calc robust distance of trn & tst set by the proj. method w/ k PCA scores.
%
%          [rd1,pr1,rd2,pr2] = mve_trn3(xtr,xts,k,cut);
%
%          xtr and xts are training & test set, respectively. rd1
%          is a vector of robust distances calculated by the
%          function, RDPROJM. The probability density
%          for the distance, rd1 is given in pr1. Using pr1, the
%          outliers (Pr <= cut) are excluded from the training set,
%          using weighting (if Pr > cut then Wt = 1, if Pr <= cut
%          then Wt = 0). The test set distances, rd2, are calculated as
%          classical Mahalanobis distances using the cleaned training set.
%          k is the number of principal components.

[r c] = size(xtr);
[u s v] = svd(xtr);
[u s v] = trim(k, u, s, v);
x = u(:,1:k);

[rd1] = rdprojm(x);				% Calculates RD w/o Training

[pr1] = 1 - hot_t(k,r,rd1);		% Calculates Probability

rc = 0;
for i=1:r
  if pr1(i) > cut				% Takes Observations except Outliers
     rc = rc + 1;
     trid(rc) = i;
  end
end

% Calculates Mahalanobis Distances

[rt ct] = size(xts);

xtrn = xtr(trid,:);				% Takes Training data set

[r c] = size(xtrn);

[xtrn m] = meancorr(xtrn);		% Mean-Correction
xts = xts - m(ones(1,rt),:);

[uu ss vv] = svd(xtrn);
[uu ss vv] = trim(k,uu,ss,vv);
vt = xts*vv*inv(ss);
v = uu(:,1:k);

s = inv((v' * v)./(r-1));		% Inverse var-covar matrix

rd2 = (vt * s) .* vt;			% Distances for Test data
rd2 = sqrt(sum(rd2')');

pr2 = 1 - hot_t(k,r,rd2);		% Calculates Probability

end
