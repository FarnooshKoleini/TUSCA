function [t,w,a,a_corr]=density_correct(cpd_name,data,Tref);
% DENSITY_CORRECT -- correct NIR spectra for temperature dependent density change
%
% inputs:
% cpd_name = name of compound to be corrected (see density.m for avail list)
% data = structure of spectra and HEL data exported by guipro kinetic fit
% Tref = ref temperature for corrected spectra (default = 298 K)
%
% use:
% [t,w,a,a_corr]=density_correct('butanol',data,298);
% or
% [t,w,a,a_corr]=density_correct('butanol',data);

if ~isstruct(data);
    error('Export data from Guipro kinetic model first.');
end;

if nargin < 3,
    Tref = 298;
end;

t=data.t;   % extract needed vars
w=data.w;
a=data.Y;
[r,c]=size(a);

% get interpolated temperature and calc density profile

Tr_i = interp1(data.hel.time-data.hel.t_offset,data.hel.Tr,data.t);
d=density(cpd_name,Tr_i);

d_ref=density(cpd_name,Tref);

a_corr = scale(a',zeros(r,1)',d'/d_ref)';
 
fi; colorlin(round(r*1.2)); plot(w,a);
fi; colorlin(round(r*1.2)); plot(w,a_corr);
