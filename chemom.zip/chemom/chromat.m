function [a,c,e]=chromat(n,m,k,means,sdevs);
% CHROMAT -- generate a simulated k-component spectro-chromatogram data matrix
% Dimensions of a are nxm.  The matrices c and e are the 
% concentration profiles (nxk) and spectra (kxm) respectively.
% Try:
% n=25;
% m=15;
% k=3;
% means=[11,13,17];
% sdevs=[2,2,2];
%
% [a,c,e]=chromat(n,m,k,means,sdevs);
for i=1:k
   [x,c(i,:)] = gaussian(1,n,n,means(i),sdevs(i));
end
c=c';
e=rand(k,m);
a=c*e;

