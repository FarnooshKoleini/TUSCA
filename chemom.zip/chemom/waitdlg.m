function waitdlg(h)
% WAITDLG -- wait for dialog box h to be dismissed.
%
% h is a handle to the dialog box
% This function is necessary for compatability between matlab vers. 4.2 and 5.0
v=version;
if v(1)=='4',
  while gcf==h, pause(0.1); end;
else
  uiwait(h)
end
