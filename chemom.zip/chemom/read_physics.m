function [wv,x,nm]=read_physics;
%READ_physics -- Read multiple physics *.dat files
%
% [wv,x]=read_physics(fname,n);
%           or
% [wv,x]=read_physics;
%
d=dir('*.dat');
wv = zeros(1,1024);
x = zeros(length(d),1024);

fprintf(1,'Reading:\n');
for i=1:length(d);
    nm{i} = d(i).name;
    fprintf(1,'  %s\n',d(i).name);
    z=load(d(i).name);
    x(i,:)=z(:,2)';
end;
wv=z(:,1)';
nm=char(nm');