function [wv,x]=read_fp(fname);
%READ_FP -- Read Galactic *.fsp file export format
%
% [wv,x]=read_fp(fname);
%           or
% [wv,x]=read_fp;
%
% Function to read a single spectrum from Galactic's GRAMS/32 *.FSP 
% file export format.
% 
% See also READ_FSP for reading multiple files

if nargin==0,
   [fn,pt]=uigetfile('*.fsp','Select GRAMS/32 *.fsp file');
   fname = fullfile(pt,fn);
end

if isempty(findstr(fname,'.fsp')) & isempty(findstr(fname,'.FSP')),
  fname = strcat(fname,'.fsp');
end;

% open the file in binary format, read-only, little-endian IEEE machine format 
[fid,err_msg]=fopen(fname,'r','l');

if fid < 0,
  error(sprintf('READ_FP -- Error, file %s not found.',fname));
end;

% read header
npts = fread(fid,1,'float32');
first_wv = fread(fid,1,'float32');
last_wv = fread(fid,1,'float32');
wv_type = fread(fid,1,'float32');
x_type = fread(fid,1,'float32');
resolution = fread(fid,1,'float32');

wv = linspace(first_wv,last_wv,npts);

% read spectrum
x = fread(fid,npts,'float32')';

% close the file
fclose(fid);
