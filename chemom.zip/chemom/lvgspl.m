function [ix]=lvgspl(D,k,n);
% LVGSPL -- Highest leverage sample selection function for matrix D.
%
%   Returns index of n samples selected from D in ix.
%   Argument k specifies number of principal components to use.
%
% See Anal. Chem. v 63, pp 2750-2756 (1991).
% See also "Chemometrics", Sharaf, Illman, Kowalski (1986) Wiley.
% pp 240-241.
%
% Note: PC scores have to be calc'd every iteration to avoid
% inverting nearly singular hat matrix.
%
% [ix]=lvgspl(D,k,n);

[r,c]=size(D);  % get dimension of data matrix
ix=zeros(n,1);  % allocate storage for spl selection index

%
% mean correct the data first
%
m=mean(D);
D=D-m(ones(1,r),:);

%
% Note: for MLR subst. substitute selected 
% wavelengths for pc scores.
%

for i=1:n
 disp(sprintf('Selecting spl %g.',i));
	[v,s,u]=svd(D',0);       % get pc scores (NIPLS algorithm would
																									% save compute time here)
	[u,s,v]=trim(k,u,s,v);  % only retain k factors
	sc=u*s;                 % calc scores

	H=sc*inv(sc'*sc)*sc';  % calc hat matrix (e.g. Mahalnobis dist.)
	[x,idx]=max(diag(H));  % spl selected is max diagonal of H
	ix(i)=idx;
	z=D(idx,:);
%
% remove selected spl and calc component of data orthogonal
% to it.
%
	for j=1:r;
		dotprodz = z * z';
  dotprod2 = z * D(j,:)';
%	next line calc's the portion of D(j,:) orthogonal to z
		D(j,:) = D(j,:) - dotprod2 ./ dotprodz .* z;
	end;
end;
