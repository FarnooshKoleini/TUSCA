function [ys]=lowess(x,y,span,strip);
% LOWESS -- locally weighted regression scatterplot smoothing.
%
% [ys]=lowess(x,y,span,strip);
%
% Smooth columns in y using locally weighted regression scatterplot
% smoothing.  Computational intensive.  Cleveland (1979).
%
% span = fraction of data to use for the smoothing window (default = 0.20)
% if span = 0, then strip pts is used for size of smoothing window.

if nargin < 3
  span = 0.20;
elseif nargin < 2
  error('lowess - x and y data needed');
end;

if (span < 0) | (span >=1)
  error('lowess - span must be between 0 and 1.');
end;

[r,c]=size(y); [rx, cx]=size(x);
if r ~= rx
  error('lowess - x and y must have same number of rows.');
end;

if r < 3
  error('lowess - not enough rows in y.');
end;

if span ~= 0,
  strip = r * span;
end;

s = ceil(strip/2);

if 2*s > r 
  error('lowess - window size is too large');
end;

if 2*s <= 2
  s = 2;
  disp('lowess - warning, window size is too small, reset to 2.');
end;

% allocate storage and initialize endpoints
ys=zeros(size(y));

% find x neighborhood

for i=1:c				% loop over each column in y.
  for j=1:r				% loop over each row

% find index of the local neigborhood

    strip = j-s:j+s;
	strip = strip(find(strip > 0 & strip <= r));

% find extreme pt.
	
    ss = x(strip) - x(j);
    ms = max(abs(ss))';

% calc vector of neighborhood weights

	u = abs(ss)/ms;
	w = (1.00 - u.^3).^3;				% trimean weights
	
% calc weighted LS estimate of Yi

	xu = x(strip);  xum = mean(xu);  xumw = (w .* (xu - xum));
	yu = y(strip,i);  yum = mean(yu);  yumw = (w .* (yu - yum));
	
if sum(xumw.^2)==0, disp('B'), end;
	pinv_x = xumw' ./ sum(xumw.^2);
	b = pinv_x * yumw;
	
% est. smooth value

	strip_ndx = find(j==strip);			% only est. midpoint	
	ys(j,i) = (xumw(strip_ndx) * b) + yum;	% w always = 1 at midpoint
  end

% calc residuals & robust wts

  resid = y(:,i) - ys(:,i);

  for j=1:r				% loop over each row

% find index of the local neigborhood

    strip = j-s:j+s;
	strip = strip(find(strip > 0 & strip <= r));

% find median absolute residual, MAD & weights.
	
    MAD = median(abs(resid(strip)));
	if MAD == 0,
	  u = zeros(size(strip))';
	else
	  u = resid(strip)/(6*MAD);
	  idx=find(u>1);
	  u(idx)=ones(size(idx));
	end;
	w = (1.00 - u.^2).^2;				% bisquare weights

% find extreme pt.
	
    ss = x(strip) - x(j);
    ms = max(abs(ss))';

% calc vector of neighborhood weights

	u = abs(ss)/ms;
	w = w .* ((1.00 - u.^3).^3);		% bisqr * trimean weights
	
% calc weighted LS estimate of Yi

	xu = x(strip);  xum = mean(xu);  xumw = (w .* (xu - xum));
	yu = y(strip,i);  yum = mean(yu);  yumw = (w .* (yu - yum));
	
%	if sum(xumw.^2)==0, disp('B'), end;
	pinv_x = xumw' ./ sum(xumw.^2);
	b = pinv_x * yumw;
	
% est. smooth value

	strip_ndx = find(j==strip);			% only est. midpoint	
	ys(j,i) = (xumw(strip_ndx) * b) + yum;	% w always = 1 at midpoint
  end
end;
 
