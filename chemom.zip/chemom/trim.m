function [u,s,v]=trim(k,ui,si,vi);
% TRIM -- trim the results from the svd to k factors.
%
%  [u,s,v]=trim(k,u,s,v);
u=ui(:,1:k);
s=si(1:k,1:k);
v=vi(:,1:k);
