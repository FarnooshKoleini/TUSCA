function [ix]=hhspl(D,n);
% HHSPL -- Honigs/Hieftje sample selection function for matrix D.
%
%   Returns index of samples selected from D in ix.
%   Optional argument, n specifies number sampls to select.
%
% See Anal. Chem. v 57, pp 2299-2303 (1985).
% Note: this method is just Gauss-Jordan Elimination with
% full pivoting.  For excellent ref see Numerical Reccipes
% by Press, et. al. pp 24-29.
%
% [ix]=HHspl(D,n);
[r,c]=size(D);  % get dimension of data matrix
if nargin == 1,
	n=r;
end;
ix=zeros(n,1);  % allocate storage for spl selection index

%
% mean correct the data first
%
m=mean(D);
D=D-m(ones(1,r),:);

%
% init loop;
%
for i = 1:n;
%
% 1) ix(i)=row in D with maximum absorbance, z=max abs value
% 2) iz=column in D with max absrobance
%
	[y,iy]=max(abs(D));
	[z,iz]=max(y);
	ix(i)=iy(iz);
 piv=ix(i);

%	disp(sprintf('Row, col in D with max absorbance=%g: %g,%g',z,piv,iz));
	Scale_coef=D(:,iz)./D(piv,iz);  % calc column vector of scale coefs
	D=D-Scale_coef*D(piv,:);        % scale each row and subtract

end;

