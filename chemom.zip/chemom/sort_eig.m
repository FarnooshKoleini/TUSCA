function [v,d]=sort_eig(a);
% SORT_EIG -- compute e'vals & e'vecs sorted in deceding order.
%
% subroutine to calculate the eigenvectors, v, and eigenvalues, d,
% of the matrix, a.  The eigenvalues and eigenvectors are sorted
% in decending order.
%
% [v,d]=sort_eig(a)

[v,d]=eig(a);
eval=diag(d);	% get e'vals into a vector
[y,index]=sort(-abs(eval));	% sort e'vals in decending order
v=v(:,index);	% re-arrange eigenvectors in proper order
d=diag(eval(index));	% sort vector of e'vals and build diagonal matrix 
