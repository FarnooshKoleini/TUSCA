function [prob] = f_dist(l,m,d);
% F_DIST -- probability of the F distribution.
%
% [prob] = f_dist(df1,df2,d)
%
% Where d^2 is the f value with df1 and df2 being the degrees of freedom.
% The distance may be a Mahalnobis distance.
%
% WARNING: use 1 - f_dist(v1,v2,sqrt(F)) to reproduce std. tables.

x=d.^2;
x1=m./[m + (l.*x)];
x2=l./[l + (m./x)];
j=betainc(x1,m/2,l/2);
k=betainc(x2,l/2,m/2);
alpha2=j + 1 - k;
alpha=alpha2./2;
prob=1-alpha;
