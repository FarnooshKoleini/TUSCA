function [ipk]=find_pk(cc,thr,wdth);
% FIND_PK -- find peak maxima in col vectors of c
%
% thr: noise threshold multiplier. Default is 2.
% wdth: approx peak width at half-ht.  Must be odd.  Default is 5.
%
% ipk=find_pk(c,thr,wdth); 
%% display:
% plot(c); hold on; plot(ipk,c(ipk),'ro'); hold off;
%
% ipk=find_pk(abs(x));plot(f,x); hold on; plot(f(ipk),x(ipk),'ro'); hold off;

% extend vector to treat endpoints

cc=cc(:);
c = [cc([1 1],:); cc; cc([end end],:)];
[nc,nr]=size(c);

if nargin < 3, wdth = 5; end;
if nargin < 2, thr = 2; end;

if rem(wdth,2) == 0, wdth = wdth + 1; end;
hf_w = ceil(wdth/2);

dc=savgol(c',wdth,3,1)';			% calc first deriv.
i=hf_w:nc-hf_w;                 			% ignore ends of chromatogram
maxdc = median(median(abs(dc(i-1,:)-dc(i,:))));       % get robust slope thresholds

ipk = find(dc(i,:) > 0 & dc(i+1,:) < 0 & ...    % find all zero crossings
           dc(i-hf_w+1,:) > dc(i+1,:) &...      % front half must be 2pts wide
		   dc(i+hf_w,:) < dc(i,:) ...           % back half must 2pts wide
		   & ((dc(i-hf_w+1,:)-dc(i,:)) > thr*maxdc...	% left ht thresh
		   | (dc(i,:)-dc(i+hf_w,:)) > thr*maxdc))...	% right ht threshold
		    +hf_w;
ipk = ipk - 2;
