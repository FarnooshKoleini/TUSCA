function [ev_fwd,ev_rev] = efa(a,nfactors,direction,plot_flag);
% EFA -- evolving factor analysis w/ power method
% function to do evolving factor analysis, foward and reverse directions.
%
% [ev_fwd,ev_rev] = efa(a,nfactors,direction,plot_flag);
%
% optional:
%   nfactors (default = 5)
%   direction (1=fwd, 2=rev, 3=both, defaul=3);
%   plot_flag: (0=none, 1=plot, default=0);

if nargin < 4,
	plot_flag = 0;
end
if nargin < 3,
	direction = 3; 
end;
if nargin < 2,
	nfactors = 5; 
end;

[r,c]=size(a);
minf=min(r,c);
ev_fwd = zeros(nfactors,r);
ev_rev = zeros(nfactors,r);
k = nfactors;

z=a*a';				% calc covar matrix.
uf = ones(1,k); ur = uf;	% init evects
ev_fwd(1,1) = z(1,1);
ev_rev(1,r) = z(r,r);

% fprintf(1,'Processing rows...\n');

for i=2:r
% 	fprintf(1,' %3.0f',i); if rem(i,18) == 0, fprintf(1, '\n'); end;
	
	idxf = 1:i;
	idxr = r-i+1:r;
	
	if direction ~=2,
		% re-use last iteration evect to speed up power_pca
		[ev_fwd(:,i),uf] = power_pca(z(idxf,idxf),k,[uf; uf(i-1,:)]);
% 		ev_fwd(:,i) = power_pca(z(idxf,idxf),k);
	end;

	if direction ~=1,
		[ev_rev(:,r-i+1),ur] = power_pca(z(idxr,idxr),k,[ur(1,:); ur]);
% 		ev_rev(:,r-i+1) = power_pca(z(idxr,idxr),k);
	end;
end;
% fprintf(1, '\n');
if plot_flag,
	semilogy(ev_fwd'); hold on; plot(ev_rev'); hold off;
end;

function [ev,vn] = power_pca(z,k,v);
% POWER_PCA - calc a few e'vals and e'vects using power mtd (SVD is more accurate!)
%
% z:  var-covar matrix, z = a * a';
% k:  number factors
% v:  initial guess for e'vects (optional, gives slight speed-up)
% tol: e'val tolerance (default = 1e-8)
%
% [ev,vn] = power_pca(z,k,v);


[c,c] = size(z);
nfac = min(c,k);
ev = zeros(k,1);
tol = 1e-8; 
vn = v;

for i = 1:nfac
	vnew = z * vn(:,i);		% est unorm v
	evnew = norm(vnew);		% est eval
	vnew = vnew/evnew;
	while abs(ev(i)-evnew)/evnew > tol,
		ev(i) = evnew;
		vnew = z * vnew;			% est unorm v
		evnew = norm(vnew);		% est eval
		vnew = vnew/evnew;
	end
	ev(i) = evnew;
	vn(:,i) = vnew;
	z = z - vnew * evnew * vnew';
end
