function [y]=derivative(x,n);
% DERIVATIVE - Smooth and take derivatives of columns
%
% [y]=derivative(x,n);
%
% Function to take the first derivative and smooth columns in a 
% matrix using the 3-point binomial filter.  n is the number of 
% times to apply the filter.
[r,c]=size(x);
[y]=derv(x,r,c);
for i=1:n
  [y]=smth(y,r);
end;
