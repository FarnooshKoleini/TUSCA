function [u,s,v]=svdt(k,a);
% SVDT - trimmed SVD of matrix a.
%
% [u,s,v]=svdt(k,a);

[r,c] = size(a);

if c > r,
   [v,s,u] = svd(a',0);		% for c > r this uses less memoryt & time
else
   [u,s,v] = svd(a,0);		% for r > c this is faster
end;

u=u(:,1:k);					% trim to k factors
s=s(1:k,1:k);
v=v(:,1:k);
