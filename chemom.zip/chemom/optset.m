function [Options, x, y] = optset(varargin)
% OPTSET - Create/alter optimization options structure used in the nglm algorithm
% Written by Julien Billeter, February 2011

% Default values
Options.Bounds  = [];
Options.Conv    = 1e-4;
Options.Deriv   = 1e-6;
Options.Display = 1;
Options.MaxIt   = 20;
Options.mp0     = 0;
Options.mp_dec  = 3;
Options.mp_div  = 1;
Options.mp_inc  = 5;
Options.mp_osc  = 3;

% Modify the default values according to the values provided by the user
if nargin > 0
    for i = 1:2:nargin
        [x, y] = size(varargin{i+1});
        if x ~= 0 && y ~= 0
            Value  = '[';
            for m = 1:x
                for n = 1:y
                    Value = [Value, num2str(varargin{i+1}(m, n))];
                    if n ~= y
                        Value = [Value, ','];
                    end
                end
                if m ~= x
                    Value = [Value, ';'];
                else
                    Value = [Value, ']'];
                end
            end
        else
            Value = '[]';
        end
        eval(strcat('Options.', varargin{i}, '=', Value, ';'));
    end
end