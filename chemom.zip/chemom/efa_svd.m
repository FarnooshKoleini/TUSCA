function [ev_fwd,ev_rev,ec] = efa_svd(a,nfactors,direction);
% EFA_SVD -- evolving factor analysis
% function to do evolving factor analysis, foward and reverse directions.
%
% [ev_fwd,ev_rev,ec] = efa_svd(a,nfactors,direction);
%
% ef, er: forward and reverse profiles
%
% optional:
%   nfactors (default = 5)
%   direction (1=fwd, 2=rev, 3=both);

if nargin < 3,
  direction = 3; end;
if nargin < 2,
  nfactors = 5; end;

[r,c]=size(a);
minf=min(r,c);
ev_fwd = zeros(nfactors,r);
ev_rev = zeros(nfactors,r);
% sf = zeros(minf,1);
% sr = zeros(minf,1);

% fprintf(1,'Processing rows...\n');
for i=1:r
%   fprintf(1,' %3.0f',i); if rem(i,18) == 0, fprintf(1, '\n'); end;

  idxf = 1:i;
  idxr = r-i+1:r;

  if direction ~=2,
    sf = svd(a(idxf,:));
  else
    sf = zeros(r,1);
  end;
  if direction ~=1,
    sr = svd(a(idxr,:));
  else
    sr = zeros(r,1);
  end;

  if i >= nfactors,
    ev_fwd(:,i) = sf(1:nfactors).^2;
    ev_rev(:,r-i+1) = sr(1:nfactors).^2;
  else
    ev_fwd(1:i,i) = sf(1:i).^2;
    ev_rev(1:i,r-i+1) = sr(1:i).^2;
  end;
end;
% fprintf(1, '\n');

semilogy(ev_fwd'); hold on; plot(ev_rev'); hold off;
