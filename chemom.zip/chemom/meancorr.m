function [y,m]=meancorr(x);
% MEANCORR -- mean correct columns of a matrix.
% [y,m]=meancorr(x);
m=mean(x);
[r,c]=size(x);

y=x-m(ones(1,r),:);
