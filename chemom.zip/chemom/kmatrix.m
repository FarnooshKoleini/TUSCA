function [k,chat,ctesthat]=kmatrix(a,c,atest,ctest);
% KMATRIX -- K-matrix calibration.
% The matrices a and atest contain the calibration spectra and
% test spectra respectively in rows.
% The matrices c and ctest contain the concentrations of the components
% in the calibration and test data sets respectively.
%
% [k,chat,ctesthat]=kmatrix(a,c,atest,ctest)
clc
k=inv(c'*c)*c'*a;
plot(k');
chat=a*k'*inv(k*k');
[r,m]=size(a);
[m,n]=size(c);
SEC=sqrt(sum((c-chat).^2)./(r-n))
ctesthat=atest*k'*inv(k*k');
[r,m]=size(atest);
SEP=sqrt(sum((ctest-ctesthat).^2)./r)
