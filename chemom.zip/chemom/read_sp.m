function [wv,x]=read_fp(fname);
%READ_SP -- Read Galactic *.spc file format
%
% [wv,x]=read_sp(fname);
%           or
% [wv,x]=read_sp;
%
% Function to read a single spectrum from Galactic's GRAMS/32 *.SPC 
% file format.
% 
% See also READ_SPC for reading multiple files and LOADSPC for loading multi files

if nargin==0,
	[fn,pt]=uigetfile('*.spc','Select GRAMS/32 *.spc file');
	fname = fullfile(pt,fn);
end

if isempty(findstr(fname,'.spc')) & isempty(findstr(fname,'.SPC')),
	fname = strcat(fname,'.spc');
end;

% open the file in binary format, read-only, little-endian IEEE machine format 
[fid,err_msg]=fopen(fname,'r','l');

if fid < 0,
	error(sprintf('READ_SP -- Error, file %s not found.',fname));
end;

ftflgs=fread(fid,1,'char');    %   BYTE   ftflgs; /* Flag bits defined below */
fversn=fread(fid,1,'char');    %   BYTE   fversn; /* 4Bh=> new LSB 1st, 4Ch=> new MSB 1st, 4Dh=> old format */

if fversn~=75;
	warning(['Wrong/Old File Type (' num2str(fversn) ')! Read file into Grams and save as a new file']);
end;

fexper=fread(fid,1,'uint8');    %   BYTE   fexper; /* Reserved for internal use (experiment-1) */
fexp=  fread(fid,1,'schar');    %   char   fexp;   /* Fraction scaling exponent integer (80h=>float) */
fnpts= fread(fid,1,'uint16');   %   DWORD  fnpts;  /* Integer number of points (or TXYXYS directory position) */
fread(fid,1,'uint16');
ffirst=fread(fid,1,'float64');   %   double ffirst; /* Floating X coordinate of first point */
flast= fread(fid,1,'float64');   %   double flast;  /* Floating X coordinate of last point */
fnsub= fread(fid,1,'uint16');    %   DWORD  fnsub;  /* Integer number of subfiles (1 if not TMULTI) */
% 1 1 1 1 2 2 8 8 2 = 26 bytes read to this point

fread(fid,(512-26),'char');  % Read to end of header

fstep=((flast-ffirst)/(fnpts-1));
wv=ffirst:fstep:flast;
subhead=fread(fid,32,'schar');            % Read sub-header (32 bytes)

if subhead(2)~=-128; 
	x = fread(fid,fnpts,'int32');   %Read current subfile (IBM SPC format)
else
	x = fread(fid,fnpts,'float32');   %Read current subfile (float format)
end

if subhead(2)==-128; 
	subhead(2)=32; 
end    		%no adjustments for floating format

% close the file
fclose(fid);
