function y = t_distribution(n,x);
% t_distribution - calculate the t distribbution function of x at degrees of freedom n for plotting.
% note:  p values are obtained from the integral of this function.
%
% y = t_distribution(n,x);

y = gamma((n+1)/2) ./ (sqrt(n.*pi) .* gamma(n/2)) .* (1 + ((x.^2)/n)) .^ (-(n + 1)/2);

