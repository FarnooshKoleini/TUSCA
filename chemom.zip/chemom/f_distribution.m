function y = f_distribution(m,n,x);
%
% calculate the F distribbution function of x at degrees of freedom m, n for plotting.
% note:  p values are obtained from the integral of this function.

y = gamma((m+n)/2) ./ (gamma(m/2) .* gamma(n/2)) .* m.^(m/2) .* n.^(n/2) .* x.^((m-2)/2) .* (n + m.*x).^((-m-n)/2);

