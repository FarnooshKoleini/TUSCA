function [wv,x,nm,time]=read_hmm(rootnm);
%read_hmm -- Read multiple hamamatsu data files
%
% [wv,x,name,time]=read_hmm(rootname);
%
% Function to read sequentially numbered files from GW hamamatsu text files 
% format.  Files must be named in sequential order with a root name
%
% Example: test1.txt, test2.text,...
%
% See also READ_HM for reading single files
%
%  Copyright Paul J. Gemperline, 2002
%  gemperlinep@mail.ecu.edu

% get the list of files
fnm = sprintf('%s*.txt',rootnm);
d = dir(fnm);	% read the disk directory to find find just the files we want
fnm = char(d.name);  % convert the structure to an array of names.
idx_digits = length(rootnm)+1;
n = length(d);
for i = 1:n
    num(i) = str2num(fnm(i,idx_digits:findstr(fnm(i,:),'.')));
end;
[num,idx] = sortrows(num);   % sort the file names in alphabetical order
fnm = fnm(num,:);


if n < 1,
	error(sprintf('READ_HMM -- Error, file %s not found.',fnm));
end;

% read the first file to determine length of spectra
fprintf(1,'Reading %s.\n',fnm(1,:));
[wv,x1,nm1,t1] = read_hm(fnm(1,:));
if wv == -1,		% returns -1 for all vars if file is not found.
	error(sprintf('READ_HMM -- Error reading file %s.',d(1).name));
end;
npts = length(wv);	% determine the length of the spectra

% allocate storage for spectra, etc.
x = zeros(n,npts);  x(1,:) = x1;
nm = {nm1};
time = zeros(n,1);  time(1) = t1;

% read the remaining files
for i = 2:n
	fprintf(1,'Reading %s.\n',fnm(i,:));
	[wv,x(i,:),nm{i},time(i)] =  read_hm(fnm(i,:));
	if time(i) == -1,		% returns -1 for all vars if file is not found.
		error(sprintf('READ_HMM -- Error reading file %s.',fnm(i,:)));
	end;
end;
nm = char(nm);
