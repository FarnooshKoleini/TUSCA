function [area]=red_maj_axis_fun(b);
% RED_MAJ_AXIS_FUN -- loss function for reduced major axis regression
global xdata ydata xaug yaug
area=sum((ydata-xaug*b).^2/abs(b(2)));
