function [triple]=test_fib(fib);
% TEST_FIB -- checks property of Fibonacci triples
%
% [triple]=test_fib(fib);
% Computes fib(i)*fib(i+2) and compares it with fib(i+1)*fib(i+1)

k=length(fib)-2;			% calc length of triple sequence
triple = zeros(k,2);		% initialize to zeros
for i=1:length(fib)-2;
	triple(i,1) = fib(i)*fib(i+2);		% calc f(1)*f(3) 
	triple(i,2) = fib(i+1)*fib(i+1); 	% calc f(2)*f(2)
end

fprintf(1,'%20.0f %20.0f\n',triple');
