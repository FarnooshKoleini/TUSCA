function [a,t,wv,spl_name,fname,pt]=read_da(fn);
% READ_DA -- read NIR NSAS data files.
%
%  [a,t,wv,spl_name,fn,pt]=read_da('filename');
%        or
%  [a,t,wv,spl_name,fn,pt]=read_da;
%
%  Will not work for full Vis/NIR range.
%  Works for spectra transferred from pc to rs/6000 via binary ftp.
%s
%  See read_fda for reading full Vis/NIR range.

%  Copyright Paul J. Gemperline, 2000
%  gemperlinep@mail.ecu.edu

if nargin==0,
   [fname,pt]=uigetfile('*.da','Select NSAS *.da file');
   fn = fullfile(pt,fname);
else
   fname=fn;
   pt=pwd;
end

inp=fopen(fn,'r','ieee-le');

nspec=0;
k=fread(inp,128,'char');
fseek(inp,2944,-1);
%
% loop for reading sample names
%
f_eof=1;   % matlab 7 revision for End_of_file detection
while not(feof(inp)) & f_eof
  nspec=nspec+1;
  da=k(65)+k(66)*256;
  mo=k(67)+k(68)*256;
  yr=k(69)+k(70)*256;
  hr=k(71)+k(72)*256;
  mi=k(73)+k(74)*256;
  se=k(75)+k(76)*256;
  spl_name(nspec,1:30)=[setstr(k(5:14))' sprintf(' %2g:%2g:%2g %2g-%2g-%4g',hr,mi,se,mo,da,yr)];
  k=fread(inp,128,'char');
  if isempty(k)   % in matlab 7 it still reads after eof but returns empty variable
      f_eof=0;
  end
  fseek(inp,(nspec+1)*2944,-1);
end;

frewind(inp);
a=zeros(nspec,700);
for i=1:nspec
  k=fread(inp,2944./4,'float');
  a(i,:)=k(33:732)';
end;
fclose(inp);

t = get_tim(spl_name)/60;
wv = 1100:2:2498;
