function [y]=smth(x,r);
% SMTH -- subroutine for smooth
%
  z=(x(2:r,:) + x(1:r-1,:)) ./ 2;
  y(2:r-1,:)=(z(2:r-1,:) + z(1:r-2,:)) ./ 2;
  y(1,:)=x(1,:);
  y(r,:)=x(r,:);
