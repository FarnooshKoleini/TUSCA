function [Xmst,D] = mst(X,options,ObjLab)
% function [Xmst,D] = mst(X,options,ObjLab)
% 030117 FvdB
% Minimal or Minimum Spanning Tree based on Euclidian distances
% MST in short: use (X)(n x p) to form (n-1) lines to connect (n) objects in the shortest possible way in the (p)
% dimensional variable-space, under the condition 'no closed loops allowed'.
% 
% in: X (objects x variables) data block
%     options (1 x 1) 1: plot mst results if 'variables' is 2 or 3 (default 0 = no plot)
%     ObjLab (objects x n) object labels for plotting
%
% out:Xmst (objects-1 x 2) link set between 'objects' indexed as rows in X
%     D (objects x objects) distance matrix
%
% based on: F.S.Hillier and G.J.Lieberman 'Introduction to operational research' 7(2001)415-420

if (nargin == 0)
   help mst
   return
elseif (nargin == 1)
    options = [0];
end   

[nX,mX] = size(X);
if (mX < 2)
    error('ERROR: "X" must contain at least two variables to compute MST');
end

% activate this line is 'Statistics' toolbox is available, and another distance then Euclidian is
% desired ...
% D = squareform(pdist(X,'cityblock'));
% ... deactivate from here ...
D = zeros(nX,nX);
for a=1:nX-1
    for aa=a+1:nX
        x = X(a,:)-X(aa,:);
        D(a,aa) = sqrt(x*x');
        D(aa,a) = D(a,aa);
    end
end
Dmax = max(max(triu(D,1)))*10;
% ... to here.

%temp = randperm(nX); % starting with random node will lead to the same solution!
%temp = temp(1);
%temp1 = setdiff(1:nX,temp);
%[Dmin,Dwin] = min(D(temp,temp1));
%Xmst(1,:) = [temp temp1(Dwin)];
[Dmin,Dwin] = min(D(1,2:nX));
Xmst(1,:) = [1 Dwin+1];
for a=2:nX-1
    mindist = Dmax;
    Xmstlist = unique(Xmst(:))';
    Xmstnotlist = setdiff(1:nX,Xmstlist);
    for aa=Xmstlist
        [Dmin,Dwin] = min(D(aa,Xmstnotlist));
        if (Dmin < mindist)
            minindex = [aa Xmstnotlist(Dwin)];
            mindist = Dmin;
        end
    end
    Xmst(a,:) = minindex;
end

if options(1)
    if (nargin == 3)
        nO = size(ObjLab,1);
        if (nO ~= nX)
            error('ERROR: number of labels in "ObjLab" must be the same as number of objects in "X"');
        end
    end
    if (mX == 2)
        plot(X(:,1),X(:,2),'.r')
        if (nargin == 3)
            text(X(:,1),X(:,2),ObjLab);
        else
            text(X(:,1),X(:,2),num2str([1:nX]'));
        end
        grid
        hold on
        for a=1:nX-1
            plot([X(Xmst(a,1),1) X(Xmst(a,2),1)],[X(Xmst(a,1),2) X(Xmst(a,2),2)]);
        end
        hold off
        xlabel('D-one');
        ylabel('D-two');
        title('Minimum Spanning Three (MST) for data table');
    elseif (mX == 3)
        plot3(X(:,1),X(:,2),X(:,3),'.r')
        if (nargin == 3)
            text(X(:,1),X(:,2),X(:,3),ObjLab);
        else
            text(X(:,1),X(:,2),X(:,3),num2str([1:nX]'));
        end
        grid
        hold on
        for a=1:nX-1
            plot3([X(Xmst(a,1),1) X(Xmst(a,2),1)],[X(Xmst(a,1),2) X(Xmst(a,2),2)],[X(Xmst(a,1),3) X(Xmst(a,2),3)]);
        end
        hold off
        xlabel('D-one');
        ylabel('D-two');
        zlabel('D-three');
        title('Minimum Spanning Three (MST) for data table');
    else
        disp('WARNING: plotting only possible for two or three variables in "X"');
    end
end
