function [importjcamp]=read_jcamp(fname);
% READ_JCAMP -- Function to read several variants of jcamp-dx files.  
%               Does not support data compression formats.
%
% The following headers are needed in the dx file for proper reading.
% 
% ##TITLE- If there are multiple sets of spectra defined by ##blocks, the 
% second title read will send the program into the internal loop which 
% fills each of the blocks in the structure.  If the second title is not 
% encountered, the program will only read one set of data. 
% 
% ##BLOCKS- Only needed if there are multiple blocks of spectra. The 
% number is used to set up the loop for counting the blocks. 
% 
% ##XYDATA- this is needed to interpret the data.
% 
% ##END-  this is needed to show where the data ends. Any text in the in-
% between ##XYDATA and ##END will cause data to stop being collected.
% 
% <input arguments>
%   fname - This variable when present delivers the filename of the 
%   formatted file which the data is to be extracted from. If the filename 
%   is not supplied, the function will use uigetfile to get the filename and 
%   path.
% 
% <output arguments>
%   x - a self-documenting structure with fieldnames taken from the jcamp 
%   standard file.
% 
% example: [x]=read_jcamp('filename.dx');
 

% Copyright, Eric Cash and Paul J. Gemperline, 1999.
% gemperlinep@mail.ecu.edu

if nargin < 1,
   [nm,path]=uigetfile('*.dx','please select a tab delimited file to load');
   ccxx=[path nm];
   importjcamp.nm=nm;
   importjcamp.path=path;
else
   ccxx=fname;
   nm=fname;
   path=pwd;
   path=[path '\'];
   importjcamp.nm=nm;
   importjcamp.path=path;
end;
if nm ~= 0,
   label(1).field='##JCAMPDX';
   label(2).field='##DATATYPE';
   label(3).field='##BLOCKS';
   label(4).field='##TIME';
   label(5).field='##NPOINTS';
   label(6).field='##FIRSTX';
   label(7).field='##LASTX';
   label(8).field='##XFACTOR';
   label(9).field='##FIRSTY';
   label(10).field='##YFACTOR';
   label(11).field='##XYDATA';
   label(12).field='##ORIGIN';
   label(13).field='##TITLE';
   label(14).field='##MINX';
   label(15).field='##MAXX';
   label(16).field='##MINY';
   label(17).field='##MAXY';
   label(18).field='##XUNITS';
   label(19).field='##YUNITS';
   label(20).field='##END';
   label(21).field='##DELTAX';
   flag.title=0;
   fid=fopen(ccxx,'r');
   x=1;
   while x ~= -1,
      x=fgetl(fid);
      if isempty(x),
         x='emptyline';
      end;
      [bef,aft]=strtok(x,'=');
      idxsiz=find(isspace(bef)>0);
      bef(idxsiz)=[];
      if (strcmp(bef,label(1).field)==1);,
      	importjcamp.version=aft([2:end]);   
      elseif (strcmp(bef,label(2).field)==1);,
         importjcamp.datatype=aft([2:end]);
      elseif (strcmp(bef,label(3).field)==1);,
         importjcamp.blocks=aft([2:end]);
         flag.title=1;
      elseif (strcmp(bef,label(4).field)==1);,
         importjcamp.time=aft([2:end]);
      elseif (strcmp(bef,label(5).field)==1);,
         importjcamp.npoints=aft([2:end]);
      elseif (strcmp(bef,label(6).field)==1);,
         importjcamp.firstx=aft([2:end]);
      elseif (strcmp(bef,label(7).field)==1);,
         importjcamp.lastx=aft([2:end]);
      elseif (strcmp(bef,label(8).field)==1);,
         importjcamp.xfactor=aft([2:end]);
      elseif (strcmp(bef,label(9).field)==1);,
         importjcamp.firsty=aft([2:end]);
      elseif (strcmp(bef,label(10).field)==1);,
         importjcamp.yfactor=aft([2:end]);
      elseif (strcmp(bef,label(11).field)==1);,
         importjcamp.xydata=aft([2:end]);
         x=-1; %flag to tell function to read raw data
      elseif (strcmp(bef,label(12).field)==1);,
         importjcamp.origin=aft([2:end]);
      elseif (strcmp(bef,label(13).field)==1),
         if (flag.title==0),
            importjcamp.title=aft([2:end]);
         else
            importjcamp.block(1).title=aft([2:end]);
            x=-1;
         end;
      elseif (strcmp(bef,label(14).field)==1),
         importjcamp.minx=aft([2:end]);
      elseif (strcmp(bef,label(15).field)==1),
         importjcamp.maxx=aft([2:end]);
      elseif (strcmp(bef,label(16).field)==1),
         importjcamp.miny=aft([2:end]);
      elseif (strcmp(bef,label(17).field)==1),
         importjcamp.maxy=aft([2:end]);
      elseif (strcmp(bef,label(18).field)==1);,
         importjcamp.xunits=aft([2:end]);
      elseif (strcmp(bef,label(19).field)==1);,
         importjcamp.yunits=aft([2:end]);
      elseif (strcmp(bef,label(21).field)==1);,
     		importjcamp.deltax=aft([2:end]);
      end;
   end;
   if (isfield(importjcamp,'block')==1)
      bloc=str2num(importjcamp.blocks);
      
      if isempty(bloc),
         bloc=1;       %error checking for number of blocks.   
      end;
      x=1;  %to offset x=-1 after first run through of code.
      for i=1:bloc,
         while x ~= -1,
      		x=fgetl(fid);
      		if isempty(x),
         		x='emptyline';
      		end;
      		[bef,aft]=strtok(x,'=');
      		idxsiz=find(isspace(bef)>0);
      		bef(idxsiz)=[];
      		if (strcmp(bef,label(1).field)==1);,
      			importjcamp.block(i).version=aft([2:end]);   
      		elseif (strcmp(bef,label(2).field)==1);,
         		importjcamp.block(i).datatype=aft([2:end]);
      		elseif (strcmp(bef,label(4).field)==1);,
         		importjcamp.block(i).time=aft([2:end]);
      		elseif (strcmp(bef,label(5).field)==1);,
         		importjcamp.block(i).npoints=aft([2:end]);
     	   	elseif (strcmp(bef,label(6).field)==1);,
         		importjcamp.block(i).firstx=aft([2:end]);
      		elseif (strcmp(bef,label(7).field)==1);,
         		importjcamp.block(i).lastx=aft([2:end]);
      		elseif (strcmp(bef,label(8).field)==1);,
         		importjcamp.block(i).xfactor=aft([2:end]);
      		elseif (strcmp(bef,label(9).field)==1);,
         		importjcamp.block(i).firsty=aft([2:end]);
      		elseif (strcmp(bef,label(10).field)==1);,
         		importjcamp.block(i).yfactor=aft([2:end]);
      		elseif (strcmp(bef,label(11).field)==1);,
         		importjcamp.block(i).xydata=aft([2:end]);
         		x=-1; %flag to tell function to read raw data
      		elseif (strcmp(bef,label(12).field)==1);,
         		importjcamp.block(i).origin=aft([2:end]);
      		elseif (strcmp(bef,label(13).field)==1),
            	importjcamp.block(i).title=aft([2:end]);
      		elseif (strcmp(bef,label(14).field)==1),
         		importjcamp.block(i).minx=aft([2:end]);
     			elseif (strcmp(bef,label(15).field)==1),
         		importjcamp.block(i).maxx=aft([2:end]);
      		elseif (strcmp(bef,label(16).field)==1),
         		importjcamp.block(i).miny=aft([2:end]);
      		elseif (strcmp(bef,label(17).field)==1),
         		importjcamp.block(i).maxy=aft([2:end]);
      		elseif (strcmp(bef,label(18).field)==1);,
         		importjcamp.block(i).xunits=aft([2:end]);
      		elseif (strcmp(bef,label(19).field)==1);,
               importjcamp.block(i).yunits=aft([2:end]);
            elseif (strcmp(bef,label(21).field)==1);,
     				importjcamp.block(i).deltax=aft([2:end]);   
      		end;
         end;
         tempcount=1;
         xx=1;
         xdatatemp=[];
         importjcamp.block(i).xdata=[];
         importjcamp.block(i).ydata=[];
         xcount=1;
         while(xx ~=-1),
            x=fgetl(fid);
            if (sum(isletter(x)>0)>0),
               xx=-1;   %todo: error checking for ##END.  if no end, user needs to be warned.
              	[bef,aft]=strtok(x,'=');
      			idxsiz=find(isspace(bef)>0);
      			bef(idxsiz)=[];
               if (strcmp(bef,label(20).field)==1);,
                  importjcamp.block(i).endstatement=aft([2:end]);      
               else
                  fprintf(1,'\nAn error was found in block %d.\nThis function does not read jcamp\ncompression techniques such as\nsqz,diff and dup.\nThe offending line is:\n%s\n',i,x)
               end;
            else
               idxforplus=find(x=='+');
            	if ~isempty(idxforplus);
            		x(idxforplus)=' ';   
               end;
               idxforneg=find(x=='-');
               if ~isempty(idxforneg);
               	for ineg=1:(length(idxforneg))-1,
                  	idxforneg(ineg+1)=idxforneg(ineg+1)+ineg;
               	end;
               	for ineg=1:length(idxforneg),
                  	x=[x(1:(idxforneg(ineg))-1) ' ' x(idxforneg(ineg):end)];
               	end;
            	end;
            	xdatatemp=[str2num(x)];
               tempcount=tempcount+1;
               xdtlength=length(xdatatemp);
            	if (xdtlength > 2),
               	if (isfield(importjcamp.block(i),'deltax')==1),
                  	if (~isempty(str2num(importjcamp.block(i).deltax))),
                     	deltax=str2num(importjcamp.block(i).deltax);
                     	importjcamp.block(i).xdata=[importjcamp.block(i).xdata xdatatemp(1)];
                     	for ixdt=1:xdtlength-2,
                     	 	importjcamp.block(i).xdata=[importjcamp.block(i).xdata (xdatatemp(1)+deltax*ixdt)];  
                     	end;
                  	else
                     	importjcamp.block(i).xdata=[importjcamp.block(i).xdata xdatatemp(1)];
                  	end;
               	else
                  	importjcamp.block(i).xdata=[importjcamp.block(i).xdata xdatatemp(1)];
               	end
            	else
               	importjcamp.block(i).xdata=[importjcamp.block(i).xdata xdatatemp(1)];
            	end;
            	importjcamp.block(i).ydata=[importjcamp.block(i).ydata xdatatemp(2:length(xdatatemp))];
               if (xcount == 1);
               	firstx=xdatatemp(1);   
               end
               %xdatatemp=[xdatatemp str2num(x)];
               %tempcount=tempcount+1;
            end;
            xcount=xcount+1;
         end;
         %importjcamp.block(i).data=xdatatemp;
         %importjcamp.block(i).linecount=tempcount-1;
         if (x),   %put check here for different xydata sets.
            %interval=round(length(xdatatemp)/importjcamp.block(i).linecount);
            %idxxpoints=[1:interval:length(xdatatemp)];
            %importjcamp.block(i).ydata=xdatatemp;
            %importjcamp.block(i).ydata([idxxpoints])=[];
            %importjcamp.block(i).xdata=xdatatemp([idxxpoints]);
            if (isfield(importjcamp.block(i),'yfactor')==1),
            	if (~isempty(str2num(importjcamp.block(i).yfactor))),
               	importjcamp.block(i).ydata=importjcamp.block(i).ydata*str2num(importjcamp.block(i).yfactor);
            	end;
         	end;
         	if (isfield(importjcamp.block(i),'xfactor')==1),
            	if (~isempty(str2num(importjcamp.block(i).xfactor))),
               	importjcamp.block(i).xdata=importjcamp.block(i).xdata*str2num(importjcamp.block(i).xfactor);
            	end;
         	end;
         end;
         x=1;  % to offset -1 setting a few lines above.
      end;
   else
      %else read the one block and store it in structure.
      tempcount=1;
      xx=1;
      xdatatemp=[];
      importjcamp.xdata=[];
      importjcamp.ydata=[];
      while(xx ~=-1),
         x=fgetl(fid);
         if (sum(isletter(x)>0)>0),
            xx=-1;   %todo: error checking for ##END.  if no end, user needs to be warned.
            [bef,aft]=strtok(x,'=');
      			idxsiz=find(isspace(bef)>0);
      			bef(idxsiz)=[];
               if (strcmp(bef,label(20).field)==1);,
                  importjcamp.endstatement=aft([2:end]);      
               else
                  fprintf(1,'\nAn error was found while reading data.\nThis function does not read jcamp\ncompression techniques such as\nsqz,diff and dup.\nThe offending line is:\n%s\n',x)
               end;
         else
            idxforplus=find(x=='+');
            if ~isempty(idxforplus);
            	x(idxforplus)=' ';   
            end;
            idxforneg=find(x=='-');
            if ~isempty(idxforneg);
               for i=1:(length(idxforneg))-1,
                  idxforneg(i+1)=idxforneg(i+1)+i;
               end;
               for i=1:length(idxforneg),
                  x=[x(1:(idxforneg(i))-1) ' ' x(idxforneg(i):end)];
               end;
            end;
            xdatatemp=[str2num(x)];
            tempcount=tempcount+1;
            xdtlength=length(xdatatemp);
            if (xdtlength > 2),
               if (isfield(importjcamp,'deltax')==1),
                  if (~isempty(str2num(importjcamp.deltax))),
                     deltax=str2num(importjcamp.deltax);
                     importjcamp.xdata=[importjcamp.xdata xdatatemp(1)];
                     for i=1:xdtlength-2,
                     	 importjcamp.xdata=[importjcamp.xdata (xdatatemp(1)+deltax*i)];  
                     end;
                  else
                     importjcamp.xdata=[importjcamp.xdata xdatatemp(1)];
                  end;
               else
                  importjcamp.xdata=[importjcamp.xdata xdatatemp(1)];
               end
            else
               importjcamp.xdata=[importjcamp.xdata xdatatemp(1)];
            end;
            importjcamp.ydata=[importjcamp.ydata xdatatemp(2:length(xdatatemp))];
         end;
      end;
      if (x),   %put check here for different xydata sets.
         if (isfield(importjcamp,'yfactor')==1),
            if (~isempty(str2num(importjcamp.yfactor))),
               importjcamp.ydata=importjcamp.ydata*str2num(importjcamp.yfactor);
            end;
         end;
         if (isfield(importjcamp,'xfactor')==1),
            if (~isempty(str2num(importjcamp.xfactor))),
               importjcamp.xdata=importjcamp.xdata*str2num(importjcamp.xfactor);
            end;
         end;
      end;
      x=1;  % to offset -1 setting a few lines above.
   end;
   fclose(fid);
end;
