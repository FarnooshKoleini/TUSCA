function [synch,asynch]=two_d_corr_spec(x,p,wv)
%
%two_d_corr_spec --- Noda - Ozaki two dimensional correlation spectroscopy analysis
%
% [synch,asynch]=two_d_corr_spec(x,p,wv);
%
% x - matrix of spectra
% p - plot flag (optional, default = 1)
% wv - plot axis (optional)
%
% synch - Noda's synchronous spectral map (var-covar)
% asynch - Noda's asynchronous spectral map
%
% copyright, 2008. Paul J. Gemperline

[r,c]=size(x);
[xm,m] = meancorr(x);
if nargin < 3, wv = 1:c; end;
if nargin < 2, p = 1; end;

synch = xm'*xm;

h = hilbert_noda(r);
asynch = xm'*h*xm;

if p==1
    subplot(2,2,1);
    contour(wv,wv,synch,20); axis('square');
    subplot(2,2,2);
    contour(wv,wv,asynch,20); axis('square');
    subplot(2,2,3);
    plot(wv,m); axis('square');
    subplot(2,2,4);
    plot(wv,m); axis('square');
end;

% helper function ----------

function z=hilbert_noda(k)
% generate the Hilbert-Noda transform matrix - aid in calculation of
% asynchronous 2-d correlation spectra

z = zeros(k,k);  % Preallocate matrix

s = warning('off','matlab:dividebyzero'); % save state

for m = 1:k,
    z(m,:) = 1./((1:k)-m);
end

z(z == inf) = 0;    % replace div by zero w/ zero

warning(s); % restore state