function [b]=base_poly(a,ix,np);
% BASE_POLY -- Fit polynomial baseline corrections to data (non-interactive).
%
% a:   data matrix or spectra (m*n)
% ix:  index of points used for fitting
% np:  polynomial order  (default=2) 
% b:   baseline corrected data
%
% [b]=base_poly(a,ix,n);   (See bsln_poly for interactive vers)

if nargin<3,    
   np=2;
end;
[nn,m]=size(a);
b=zeros(nn,m);
figure(1); plot(1:m,a); hold on;
for i=1:nn,
    p=polyfit(ix,a(i,ix),np);
    figure(1);
    yy=polyval(p,1:m);
    plot(1:m,yy);
    plot(ix,a(i,ix),'o');
    b(i,:)=a(i,:)-yy;
end;
hold off;
% b=b-min(min(b));
figure(2);plot(1:m,b);
title('Baseline corrected Spectra');
