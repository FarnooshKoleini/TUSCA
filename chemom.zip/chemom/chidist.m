function [y]=chidist(n)
% CHIDIST - Plots curves for the chi-sq distr. at n=3 to 10 degrees of freedom.
x=0.05:0.05:20;
x=x';
y=zeros(400,7);
for n=3:10;
  y(:,n-2)=1/(2^(n/2)*gamma(n/2)).*x .^(n/2-1).*exp(-x/2);
end;
plot(x,y);
