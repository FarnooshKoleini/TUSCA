%
% MAJ_AXIS_REGR -- script demo of reduced major axis regression
%
% Algorithm taken from Systat technical note
%
% reduced major axis regression:
%   Minimize the sum of areas of right triangles 
%   formed by each data point and the estimated line.
%   For y = a + bx the loss function is:
%   Area = (y-((a+bx))^2/(2*abs(b))
%
% major axis regression.
%	  Minimize the sum of the squares of the perpendicular 
%   distance from each point to the desired line.
%   For y = a + bx the loss function is:
%   dist^2 = (y-(a+bx))^2/(1+b^2)

% Egg data from Sokal and Roholf, pg 552, Biometry, vol ?, yr ?
x=[14 17 24 25 27 33 34 37 40 41 42]';
y=[61 37 65 69 54 93 87 89 100 90 97]';
[n,m]=size(x);
hold off;
axis('square');
plot(x,y,'o'), title('Raw data and regression lines');
hold on
range=axis;
axis(range);
xrange=[ones(2,1),range(1:2)'];
yrange=[ones(2,1),range(3:4)'];
clc

% do regular regresion

xaug=[ones(n,1) x];
yaug=[ones(n,1) y];
xdata=x;
ydata=y;

global xdata ydata xaug yaug

% OLS, pred y from x.

bxy = xaug\y
yhat= xrange*bxy;
plot(xrange(:,2),yhat,'b')

% OLS, pred x from y.

byx = yaug\x
xhat = yrange*byx;
plot(xhat,yrange(:,2), 'g');

% major

bm = bxy; %initialize to OLS
bm = fminu('maj_axis_fun',bm)
yhat= xrange*bm;
plot(xrange(:,2),yhat,'y')

% reduced

br = bxy; %reduced
br =  fminu('red_maj_axis_fun',br)
yhat= xrange*br;
plot(xrange(:,2),yhat,'r')

legend('data','OLS, pred y from x','OLS, pred x from y', 'maj axis regr', 'reduced maj axis regr')
