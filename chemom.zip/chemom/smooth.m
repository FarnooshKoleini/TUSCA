function [y]=smooth(x,n);
% SMOOTH -- smooth columns in a matrix using the 3-point binomial filter.  
% n is the number of times to apply the filter.  Repeated aplication gives
% more smoothing.
%
% [y]=smooth(x,n);
[r,c]=size(x);
y=x;
for i=1:n
  [z]=smth(y,r); 
  y=z;
end;
