function [ev_fwd,ev_rev] = efa(a,nfactors,direction);
% EFA_RE -- evolving factor analysis, returns malinowski RE, not e'vals
% function to do evolving factor analysis, foward and reverse directions.
%
% [ev_fwd,ev_rev] = efa(a,nfactors);
%
% optional:
%   nfactors (default = 5)
%   direction (1=fwd, 2=rev, 3=both);

if nargin < 3,
  direction = 3; end;
if nargin < 2,
  nfactors = 5; end;

[r,c]=size(a);
minf=min(r,c);
ev_fwd = zeros(nfactors,r);
ev_rev = zeros(nfactors,r);
% sf = zeros(minf,1);
% sr = zeros(minf,1);

fprintf(1,'Processing rows...\n');
for i=1:r
  fprintf(1,' %3.0f',i); if rem(i,18) == 0, fprintf(1, '\n'); end;

  idxf = 1:i;
  idxr = r-i+1:r;

  if direction ~=2,
    sf = svd(a(idxf,:));
  else
    sf = zeros(r,1);
  end;
  if direction ~=1,
    sr = svd(a(idxr,:));
  else
    sr = zeros(r,1);
  end;

  ev_fwd(:,i) = local_re(sf,i,c,nfactors);
  ev_rev(:,r-i+1) = local_re(sr,i,c,nfactors);
end;
fprintf(1, '\n');

function err = local_re(s,r,c,nfac);
idx = min([nfac,r-1,c-1]);
err=zeros(nfac,1);
Trace_of_a=sum(s.^2);
ssq=Trace_of_a;
for i=1:idx
  err(i)=sqrt(ssq/((r-i)*(c-i)));
  ssq=ssq-s(i)^2;
end;
