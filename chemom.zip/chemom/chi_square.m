function y = chi_square(n,x);
%
% calculate the chi_squared distribbution function of x at degrees of freedom n for plotting.
% note:  p values are obtained from the integral of this function.

k = 2.^(n/2) * gamma(n/2);
y = (1/k) .* x.^((n-2)/2) .* exp(-x/2);

