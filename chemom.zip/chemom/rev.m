function [f,rv]=REV(a);
% REV - calculate Malinowski's reduced e'values & F-ratios
%
%  [f,rv]=REV(a);

[r,c] = size(a);
if c > r,
   s = svd(a',0).^2;	% faster when c > r
else
   s = svd(a,0).^2;		% faster when r > c
end;

ln = length(s);			% initialize
rv = zeros(ln,1);
f = zeros(ln,1);

for i=1:ln
  rv(i)=s(i)/((r-i+1)*(c-i+1));	% calculate the vector of reduced e'vals
end;

% calculate F

for i=1:ln-1
  den=sum(rv(i+1:ln));
  f(i)=(ln-i)*(rv(i)/den);
end;

f(ln)=nan;			% last F-ratio is undefined
