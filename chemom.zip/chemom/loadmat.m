function [path_name]=loadmat();
% LOADMAT -- set path and read MAT data files.
%
%  [path_name]=loadmat;
%

%  Copyright Paul J. Gemperline, 2000
%  gemperlinep@mail.ecu.edu

[fn,pt]=uigetfile('*.mat','Select *.mat file');
cd(pt); disp(pt);
eval(sprintf('load %s',fn))
