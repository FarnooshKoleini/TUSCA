function [F]=ratio_k_munk(Aa, Ar)
%Chun Hsieh
%XXX = ratio_k_munk(sample abs, reference abs)
%Aa = Absorption of the sample
%Ar = Absorption of the reference (ex. 1100 nm)
%Ra = Reflection of the sample at the absorption wavelength
%Rr = Reflection of the sample at the reference wavelength

Ra = 1./(10.^(Aa));
Rr = 1./(10.^(Ar));
F = (((1.-Ra)/(1.-Rr)).^2)*(Rr/Ra);
