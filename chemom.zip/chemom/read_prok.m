function [x]=read_prok(hfn);
% read_prok -- read ProK result text files.
%
%  x=read_prok('prok filename.txt');
%        or
%  x=read_prok;
%
%  log file name is needed to sync Intelliform data with HEL data. Skip otherwise.
%
%  x is a structured variable w/ data

%  Copyright Paul J. Gemperline, 2004
%  gemperlinep@mail.ecu.edu

true = 1;
false = 0;
read_step = false;
read_data = false;

%
% open txt file for reading
%
if nargin == 0,
   [hfn,pt] = uigetfile('*.txt','Select ProK *.txt file');
   if hfn == 0,
       return;
   end;
   hfn = fullfile(pt,hfn);
end
inp=fopen(hfn,'rt');  % open for read-only access, text mode

%
% read one line at a time, watch for start/stop
%

l = fgets(inp);
while isempty(findstr(l,':'))
    l = fgets(inp);
end;

if findstr(l,'Model:');
    i = 1;
    s{i} = fgets(inp);
    while isempty(findstr(s{i},'Time\Species'));
        i = i + 1;
        s{i} = fgets(inp);
    end;
    x.model = [s{1:i-1}]
end


fclose(inp);

