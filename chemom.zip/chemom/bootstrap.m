function bootstrap
% BOOTSTRAP -- script example showing bootstrap est. of the mean & std dev.


n = 20;		% the original sample size
m = 10;		% the bootstrap size
j = 1000; 	% number bootstrap replications

x = randn(n,1);
x_m = mean(x);
x_s = std(x);

[y,ix]=sort(rand(n,j)); 					% create random number indices
x_boot = reshape(x(ix(1:m,1:j)),m,j);		% create m x j bootstrap samples
b = mean(x_boot);							% calculate j bootstrap means
b_m = mean(b);								% calc bootstrap mean
b_s = std(b) * sqrt(n);						% bootstrap est of std. dev.

disp(sprintf('Mean and std. dev. for i=%g random normal deviates:',n));
disp(sprintf('Bootstrap mean and std. dev. for i=%g random normal deviates:',n));
disp(sprintf('Sample    %7.4f  %7.4f',x_m,x_s));
disp(sprintf('Bootstrap %7.4f  %7.4f',b_m,b_s));
disp(sprintf('Expected  %7.4f  %7.4f',0,1));
