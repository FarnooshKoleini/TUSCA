function [n,s,set]=read_prs_names(fn);
%  READ_PRS_NAMES -- read PRS sample name data files.
%
%  n = PRS worksheet sample number.
%  s = Data file name, Data file spl number, Sample ID 
%  set = (T, A, or R) (eg. train, accept, or reject)
%
%  [n,s,set]=read_prs_names('filename');
inp=fopen(fn,'r');
if inp ~= 3
  error(['---> File ' fn ' not found.']);
end;
%
% loop for reading sample names
%
r=1;
while ~feof(inp)
   temp=setstr(fread(inp,93,'char')');
   s(r,:)=temp;
   r=r+1;
end;

n=sscanf(s(:,1:7)','%i');
set=s(:,40);
s=s(:,8:38);

fclose(inp);
