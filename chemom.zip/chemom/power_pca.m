function [ev,vn] = power_pca(z,k,v,tol);
% POWER_PCA - calc a few e'vals and e'vects using power mtd (SVD is more accurate!)
%
% z:  var-covar matrix, z = a * a';
% k:  number factors
% v:  initial guess for e'vects (optional, gives slight speed-up)
% tol: e'val tolerance (default = 1e-8)
%
% [ev,vn] = power_pca(z,k,v);


[c,c] = size(z);
nfac = min(c,k);
ev = zeros(k,1);
if nargin < 4, 
	tol = 1e-8; 
end;
if nargin == 3,
	vn = v;
else
	vn = rand(c,nfac);
end;

maxiter = 20;

for i = 1:nfac
	vnew = z * vn(:,i);		% est unorm v
	evnew = norm(vnew);		% est eval
	vnew = vnew/evnew;
    iter = 0;
    while (abs(ev(i)-evnew)/evnew > tol) & (iter < maxiter),
        iter = iter + 1;
		ev(i) = evnew;
		vnew = z * vnew;			% est unorm v
		evnew = norm(vnew);		% est eval
		vnew = vnew/evnew;
	end
    if iter == maxiter, fprintf('Warning, max iter exceeded on factor %g %g \n',i,iter); end;
	ev(i) = evnew;
	vn(:,i) = vnew;
	z = z - vnew * evnew * vnew';
end
