function [ydata,xdata,zdata,text_info]=load_raman_spc(filename,subs,wlrange);
% LOADSPC -- loads an SPC single file, multi-file, or some portion thereof
%
% [ydata,xdata,zdata]=loadspc;
% [ydata,xdata,zdata]=loadspc('fname');
% [ydata,xdata,zdata]=loadspc('fname',subs);
% [ydata,xdata,zdata]=loadspc('fname',subs,wv_idx);
%
%  Typically xdata=wavelengths, ydata=absorbance values, zdata=time
%
%  Without subs, all subfiles are read.  With subs, only those specified are read.
%  Examples: [1 3 6 8], 1:5, etc.
%  If subs=0 then number of subfiles and points per spectrum are reported.
%  wv_idx is index of wavenumber range to be read in.  Examples: 1:1024, 1:4:1023, etc.
%
%  Version 2.3 7FEB2001

if nargin==0,
    [fn,pt]=uigetfile('*.spc','Select GRAMS/32 *.spc file');
    filename = fullfile(pt,fn);
end

if isempty(findstr(filename,'.spc')) & isempty(findstr(filename,'.SPC')),
    filename = strcat(filename,'.spc');
end;

[f,MESSAGE]=fopen(filename,'r','l'); % open the file in binary format, read-only, little-endian
% IEEE machine format

if f==-1;
    disp([MESSAGE]);
    disp(['Current folder: ' pwd]);
    error(['File does not exist or some other similar error (check directory)']);
end;

ftflgs=fread(f,1,'uchar');    %   BYTE ftflgs
fversn=fread(f,1,'uchar');    %   BYTE fversn 4Bh=> new LSB 1st, 4Ch=> new MSB 1st, 4Dh=> old format

if fversn~=75;
    fclose(f);
    error(['Wrong/Old File Type (' num2str(fversn) ')! Read file into Grams and save as a new file']);
end;

fexper=fread(f,1,'uint8'); %BYTE fexper: instrument technique code
fexp=fread(f,1,'schar'); %char fexp: fraction scaling exponent integer (80h=>float)
fnpts=fread(f,1,'uint32'); %DWORD fnpts: integer number of points
ffirst=fread(f,1,'float64'); %doubleffirst: floating X coordinate of first point,file contains floating X values
flast=fread(f,1,'float64'); %double flast: floating X coordinate of last point,file contains floating X values
fnsub=fread(f,1,'uint16'); %DWORD fnsub: integer number of subfiles (1 if not TMULTI)
% 1 1 1 1 2 2 8 8 2 = 26 bytes read to this point

fread(f,(512-26),'char');  % Read to end of header
if (ftflgs-128)>-1;
    xdata=fread(f,fnpts,'float32')';  % Read fnpts 32 bit floating point X values from X array
else
    fstep=((flast-ffirst)/(fnpts-1));
    xdata=ffirst:fstep:flast; 
end;

if nargin<3;
    wlrange=1:fnpts;
end;

if nargin<2;
    subs=1:fnsub;
else
    if isinf(subs);
        subs=1:fnsub;
    end;
    if max(subs)>fnsub;
        error(['Not that many subfiles']);
    end;
end;

if subs==0;  % Tell user how many are in the file
    disp(['subfiles: ' num2str(fnsub) '  points: ' num2str(fnpts)]);
    ydata=[]; xdata=[]; zdata=[];
    return;
end

totalsubs=length(subs); index=0; oldpercent=0;
totalwls=length(wlrange);

ydata=zeros(totalwls,totalsubs); %set up output arrays
zdata=zeros(1,totalsubs);

for j=1:(max(subs)); % Read sub-header (32 bytes), key vales are subexp: exponent for subfile
    % and subtime: time for subfile
    subflgs=fread(f,1,'int8');
    subexp=fread(f,1,'int8');
    subindx=fread(f,1,'int16');
    subtime=fread(f,1,'float32');
    subnext=fread(f,1,'float32');
    subnois=fread(f,1,'float32');
    subnpts=fread(f,1,'int32');
    subscan=fread(f,1,'int32');
    subwlevel=fread(f,1,'float32');
    subresv=fread(f,4,'char');
    
    if subexp~=-128;
        currentframe=fread(f,fnpts,'int32');  %Read current subfile in IBM SPC format
    else
        currentframe=fread(f,fnpts,'float32');  %Read current subfile in float format
    end
    if subexp==-128;
        subexp=32; %no adjustments for floating point format
    end
    if any(j==subs); %user wants this one?
        index=index+1;
        ydata(:,index)=currentframe(wlrange,:)*(2^subexp)/(2^32); 
        zdata(index)=subtime; %then store it after adjusting for scaling denoted by subexp
    end;
end;
ydata=ydata'; %Invert ydata to be friendly for mesh plots and Intelliform
xdata = xdata(wlrange);
for skip=1:64,
    dummy=fread(f,1,'int8');
end
string_position=1;
string_line=1;
strings{1}=[];
while not(feof(f))
    byte=fread(f,1,'int8');
    if byte>32
        strings{string_line}=[strings{string_line} char(byte)];
    end
    if byte==13
        string_line=string_line+1;
        strings{string_line}=[];
        string_position=1;
    end
    string_position=string_position+1;
end

text_info=strings;
    
%close(f);


% now for the signal intensity attenuation issues in this data....

number_of_vectors=size(ydata,1);
size_of_vector=size(ydata,2);


for vector=1:number_of_vectors,
    difference_vector=[ydata(1,1) diff(ydata(vector,:))]./ydata(vector,:);
    skip_list=9+find(difference_vector(1,10:end-1000)>.35);
    for skips=1:size(skip_list,2),
        correct_position=ydata(vector,skip_list(skips)-1)-(ydata(vector,skip_list(skips)-2)-ydata(vector,skip_list(skips)-1));
        scaling_factor=ydata(vector,skip_list(skips))/correct_position;
        ydata(vector,skip_list(skips):end)=ydata(vector,skip_list(skips):end)./scaling_factor;
    end
end
    
    
