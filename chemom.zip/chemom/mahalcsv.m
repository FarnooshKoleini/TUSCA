function [d,pr] = mahalcsv(u,k,N);
% MAHALCSV -- Mahalnobis distances with leave-n-out cross validation.
%
% Function to calculate the Mahalanobis Distances of samples, given u 
% where u is a matrix of column-wise variables.  The training set, u, is 
% used to estimate distances for N samples left out.  Each N set is left out
% in turn.  If Nspls is not evenly divisible by N then the very last test 
% set will have less than N samples.
%
% The variable k specifies that k principal component scores are to be used.
% k=0 specifies that raw variables should be used instead.
% Sort_opt=1 returns the distances and probabilities sorted low to high.
%
% The samples' distances from the centroid are returned in d.  The 
% probability density (Hotelling's T-squared) for the distance is given in pr.
% The original sample number is given in idx.
%
% [d,pr] = mahalcsv(u,k,N);

% COPYRIGHT, 1997.  Un-authorized use prohibited.
% Paul J. Gemperline
% Department of Chemistry
% East Carolina University
% Greenville, NC 27858
% 919-757-6767

[r,c]=size(u);

d = zeros(r,1); pr =zeros(r,1);

for i=1:N:r
  if i+N > r,
    idx = i:r;
  else
    idx = i:i+N-1;
  end
  
  tst = u(idx,:);
  trn = u;  trn(idx,:)=[];

  [d(idx),pr(idx)]=mahald(trn,tst,k,0);
end;



